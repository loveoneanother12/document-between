# hwp2tex — 한글(HWP/HWPX) · LaTeX · Word(DOCX) 변환기

브라우저 안에서(서버 없이) 다섯 방향으로 변환합니다: 한글→LaTeX, 한글→Word, LaTeX→한글, Word→한글, Word→LaTeX.

## 구조
- `src/cfb.js`   OLE 복합문서 리더 (HWP 5.0 컨테이너)
- `src/hwp5.js`  HWP 5.0 바이너리 → 문서 모델 (문단/수식/그림/표/각주·미주/번호 매기기)
- `src/hwpx.js`  HWPX(OWPML) → 문서 모델
- `src/eqn.js`   한컴 수식 스크립트 → LaTeX (재귀 하강 파서)
- `src/latex.js` 문서 모델 → LaTeX 소스 + 그림 파일 (BMP→PNG 변환 포함)
- `src/mathast.js` 수식 허브: LaTeX 수식 → AST → 한글 수식 스크립트 / Word 수식(OMML), OMML → LaTeX
- `src/latexdoc.js` LaTeX 문서(article 부분집합) → 문서 모델
- `src/hwpxwrite.js` 문서 모델 → HWPX
- `src/docxread.js` DOCX → 문서 모델, `src/docxwrite.js` 문서 모델 → DOCX
- `src/app.js`   브라우저용 진입점 (window.HWP2TEX)
- `web/template.html` 웹앱 UI, `build.mjs` 로 `dist/index.html` 생성
- `bin/hwp2tex.mjs` 커맨드라인 변환기

## 사용
```
npm install
node build.mjs                      # dist/index.html (배포용 단일 파일)
node bin/hwp2tex.mjs 문제.hwp 출력폴더  # CLI (한글→LaTeX)
node test/todocx.mjs 문제.hwp 문제.docx   # 한글→Word
node test/tex2hwpx.mjs main.tex 결과.hwpx  # LaTeX→한글 (같은 폴더의 그림 자동 포함)
node test/docx2hwpx.mjs 문서.docx 결과.hwpx # Word→한글 (+ 결과-tex/ 에 LaTeX)
node test/eq_test.mjs test/eq_cases.txt  # 수식 변환 테스트
```
Cloudflare Pages: `dist/index.html` 하나만 올리면 됩니다 (정적 파일, 빌드 단계 없음).

## 2026-10-23 복원 후 검증 및 변경

`npm ci && npm test && npm run build`로 재현합니다. MathJax 3.2.2를 의존성에 고정했으며 vendor 파일이 없어도 빌드합니다.

- macOS 한컴오피스 한글에서 compatibility.hwpx를 열고 `test/fixtures/hancom-saved.hwpx`로 다른 이름 저장했습니다. 생성본과 한글 저장본의 파싱 결과가 동일합니다. 이 샘플은 수식 6개, 표 1개, 각주 1개, 미주 1개를 포함합니다. 임의의 실사용 문서 전체 호환성을 보장하는 검증은 아닙니다.
- 실제 Microsoft Word에서 합 기호 뒤 빈 입력 상자를 발견했습니다. OMML의 nary/func에 다음 피연산자를 넣도록 고쳤고, 수정본을 Word에서 열어 빈 상자가 사라진 것을 확인했습니다.
- TikZ/PGF 그림과 미지원 사용자 명령에 자리 표시를 남깁니다. 사용자 매크로 실행 및 도형 렌더링은 미구현입니다.
- HWPX 및 DOCX의 명시된 글꼴 이름을 모델과 작성기에 전달합니다. 혼합 언어별 글꼴, 테마/스타일 상속 전체, HWP5 글꼴, 페이지 여백·줄간격·자동 번호 매기기 보존은 아직 미구현입니다.
- OMML의 quad/qquad/enspace/일반 및 얇은 공백을 보존합니다. grow=false인 Word 괄호를 일반 괄호로 옮깁니다. 음수 간격은 경고합니다.
- 모든 모드에서 원본/변환/렌더링 3열을 유지합니다.
- npm test: 회귀 검증 8개 통과. 기존 47개 수식 경고 0개. 문자열 왕복 차이는 한글 1개, OMML 8개이며 완전 동일하다고 주장하지 않습니다.
- 브라우저에서 5방향 파일 선택·변환·다운로드, MathJax 렌더링을 확인했습니다. test/browser*.mjs는 원본 환경의 과거 스크립트로 그대로 보존하며 해당 스크립트의 자동 실행은 하지 않았습니다.

### 다음 순서
1. 실제 대형 문제지와 그림·병합 셀·긴 수식에서 한글/Word 페이지 배치 검증 확대. 원래 문서의 310개 수식 샘플은 이번 첨부에 없습니다.
2. 한글에서 처음 작성한 다양한 원본 HWPX 샘플 추가. 이번 fixture는 변환 결과를 한글에서 재저장한 파일입니다.
3. 선·도형, TikZ, 매크로, WMF/EMF, 글 뒤 배경 그림의 실제 변환 구현.
4. 여백·줄간격·자동 번호와 언어별 글꼴 보존 확대.
5. 나머지 수식 왕복 차이(합 첨자 배치, 악센트, 그룹 표기 등) 분석.
6. 사용자 Cloudflare 배포: dist/index.html. 아직 게시하지 않았습니다.

## 2026-10-23 프론트엔드 개편 — 문서 사이

- 개인 홈페이지의 따뜻한 종이색·녹색·얇은 카드·절제된 모션을 적용했습니다.
- 문서 변환, 수식 연습장, 지원 안내를 분리하고 입력/출력 형식 선택으로 5개 변환 방향을 제공합니다.
- 로컬 예제 체험, 목록 삭제 되돌리기, 편집한 소스의 설정 변경 시 보존, 잘못된 확장자 안내를 추가했습니다.
- 모바일 390px 화면과 키보드 포커스, 움직임 최소화 설정을 지원합니다.
- 예제 검증 중 발견한 단독 수식 문단의 Word 내보내기 누락을 수정했습니다.
- 회귀 검증 9개 통과. 브라우저에서 5방향 예제, 수식 렌더링, 편집 유지, 되돌리기, 연습장 양방향 전환을 확인했습니다.
- `dist/index.html`은 MathJax와 변환 코드를 내장한 단일 파일입니다. 배포는 수행하지 않았습니다.
