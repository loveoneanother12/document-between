// HWPX (OWPML zip) -> document model
import { unzipSync } from 'fflate';
import { formatNumber } from './hwp5.js';

let _DOMParser = typeof DOMParser !== 'undefined' ? DOMParser : null;
export function setDOMParser(dp) { _DOMParser = dp; }

const local = (el) => (el.localName || el.nodeName || '').replace(/^[^:]+:/, '');
const children = (el) => { const out = []; const k = el?.childNodes || []; for (let i = 0; i < k.length; i++) if (k[i].nodeType === 1) out.push(k[i]); return out; };
const child = (el, name) => children(el).find(c => local(c) === name) || null;
const attr = (el, name, dflt = '') => el?.hasAttribute?.(name) ? el.getAttribute(name) : dflt;
const descendants = (el, name) => Array.from(el?.getElementsByTagName('*') || []).filter(e => local(e) === name);
const margins = el => Object.fromEntries(['left','right','top','bottom'].map(k => [k, num(attr(el, k))]));
const num = (v, d = 0) => { const n = parseFloat(v); return Number.isFinite(n) ? n : d; };

function parseXml(text) {
  if (!_DOMParser) throw new Error('XML 파서가 없습니다');
  const doc = new _DOMParser().parseFromString(text, 'application/xml');
  return doc.documentElement;
}

const NUMFMT = { DIGIT: 0, CIRCLED_DIGIT: 1, ROMAN_CAPITAL: 2, ROMAN_SMALL: 3, LATIN_CAPITAL: 4, LATIN_SMALL: 5, CIRCLED_LATIN_CAPITAL: 6, CIRCLED_LATIN_SMALL: 7, HANGUL_SYLLABLE: 8, CIRCLED_HANGUL_SYLLABLE: 9, HANGUL_JAMO: 10, CIRCLED_HANGUL_JAMO: 11, HANGUL_PHONETIC: 12, IDEOGRAPH: 13, CIRCLED_IDEOGRAPH: 14 };

// ---- header.xml ----
function parseHeader(root) {
  const charPr = new Map(), paraPr = new Map(), numberings = new Map(), bullets = new Map(), borderFills = new Map();
  const all = root.getElementsByTagName('*');
  const fonts = new Map();
  for (const el of Array.from(all)) if (local(el) === 'fontface') {
    const lang = attr(el, 'lang');
    for (const font of children(el)) if (local(font) === 'font') fonts.set(`${lang}:${attr(font, 'id')}`, attr(font, 'face'));
  }
  for (let i = 0; i < all.length; i++) {
    const el = all[i];
    const t = local(el);
    if (t === 'charPr') {
      const p = { size: num(attr(el, 'height'), 1000) / 100, bold: false, italic: false, underline: false, sup: false, sub: false };
      for (const k of children(el)) {
        const kt = local(k);
        if (kt === 'bold') p.bold = true; else if (kt === 'italic') p.italic = true;
        else if (kt === 'supscript') p.sup = true; else if (kt === 'subscript') p.sub = true;
        else if (kt === 'underline' && attr(k, 'type') === 'BOTTOM') p.underline = true;
      }
      const ref = child(el, 'fontRef');
      p.fonts = Object.fromEntries(['HANGUL','LATIN','HANJA','JAPANESE','OTHER','SYMBOL','USER'].map(lang => [lang.toLowerCase(), fonts.get(`${lang}:${attr(ref, lang.toLowerCase())}`) || '']));
      p.font = fonts.get(`HANGUL:${attr(ref, 'hangul')}`) || fonts.get(`LATIN:${attr(ref, 'latin')}`) || '';
      charPr.set(attr(el, 'id'), p);
    } else if (t === 'paraPr') {
      const al = child(el, 'align'); const hd = child(el, 'heading');
      const h = attr(al, 'horizontal', 'JUSTIFY').toLowerCase();
      const headType = { NONE: 0, OUTLINE: 1, NUMBER: 2, BULLET: 3 }[attr(hd, 'type', 'NONE')] ?? 0;
      const fallback = descendants(el, 'default')[0] || el;
      const margin = child(fallback, 'margin') || child(el, 'margin');
      const spacing = child(fallback, 'lineSpacing') || child(el, 'lineSpacing');
      const layout = { margins: Object.fromEntries(['left','right','intent','prev','next'].map(k => [k, num(attr(child(margin, k), 'value'))])), lineSpacing: { type: attr(spacing, 'type', 'PERCENT'), value: num(attr(spacing, 'value'), 160) } };
      paraPr.set(attr(el, 'id'), { layout, align: h === 'distribute' ? 'justify' : h, headType, numberingId: attr(hd, 'idRef', '0'), level: num(attr(hd, 'level'), 0) });
    } else if (t === 'numbering') {
      const formats = Array(10).fill(''), codes = Array(10).fill(0), starts = Array(10).fill(1);
      for (const k of children(el)) if (local(k) === 'paraHead') {
        const lv = num(attr(k, 'level'), 1) - 1;
        if (lv < 0 || lv > 9) continue;
        formats[lv] = (k.textContent || '').trim();
        codes[lv] = NUMFMT[attr(k, 'numFormat', 'DIGIT')] ?? 0;
        starts[lv] = num(attr(k, 'start'), 1) || 1;
      }
      numberings.set(attr(el, 'id'), { formats, codes, starts });
    } else if (t === 'borderFill') {
      const borders = {};
      for (const side of ['left','right','top','bottom']) {
        const b = child(el, side + 'Border');
        borders[side] = { type: attr(b, 'type', 'NONE'), width: num(attr(b, 'width')), color: attr(b, 'color', '#000000') };
      }
      const brush = descendants(el, 'winBrush')[0];
      borderFills.set(attr(el, 'id'), { borders, fill: attr(brush, 'faceColor', 'none') });
    } else if (t === 'bullet') {
      bullets.set(attr(el, 'id'), attr(el, 'char', '•') || '•');
    }
  }
  return { charPr, paraPr, numberings, bullets, borderFills };
}

// ---- section ----
class HwpxParser {
  constructor(hdr, ctx) { this.h = hdr; this.ctx = ctx; this.counters = new Map(); }

  headText(pp) {
    if (!pp || !pp.headType) return '';
    if (pp.headType === 3) return (this.h.bullets.get(pp.numberingId) || '•') + ' ';
    const nm = this.h.numberings.get(pp.numberingId);
    if (!nm) return '';
    const lv = Math.min(pp.level, 9);
    let c = this.counters.get(pp.numberingId);
    if (!c) { c = nm.starts.map(x => x - 1); this.counters.set(pp.numberingId, c); }
    c[lv]++;
    for (let k = lv + 1; k < 10; k++) c[k] = nm.starts[k] - 1;
    const fmt = nm.formats[lv] || '^' + (lv + 1) + '.';
    return fmt.replace(/\^(10|[1-9])/g, (m, d) => formatNumber(Math.max(1, c[d - 1]), nm.codes[d - 1] || 0)) + ' ';
  }

  parseBlocks(container, depth = 0) {
    const blocks = [];
    if (depth > 12) return blocks;
    for (const el of children(container)) {
      const t = local(el);
      if (t === 'p') blocks.push(...this.parseParagraph(el, depth));
      else if (t === 'subList') blocks.push(...this.parseBlocks(el, depth + 1));
      else if (t === 'tbl') { const tb = this.parseTable(el, depth + 1); if (tb) blocks.push(tb); }
    }
    return blocks;
  }

  parseParagraph(p, depth) {
    const pp = this.h.paraPr.get(attr(p, 'paraPrIDRef'));
    const inlines = [];
    const after = [];
    const head = this.headText(pp);
    if (head) inlines.push({ type: 'text', text: head, bold: false, italic: false, underline: false, sup: false, sub: false });
    for (const run of children(p)) {
      if (local(run) !== 'run') continue;
      const cp = this.h.charPr.get(attr(run, 'charPrIDRef')) || {};
      const st = { bold: !!cp.bold, italic: !!cp.italic, underline: !!cp.underline, sup: !!cp.sup, sub: !!cp.sub, size: cp.size, font: cp.font, fonts: cp.fonts };
      for (const el of children(run)) {
        const t = local(el);
        switch (t) {
          case 't': this.parseT(el, st, inlines); break;
          case 'equation': {
            const sc = child(el, 'script');
            const script = (sc ? sc.textContent : '').trim();
            if (script) inlines.push({ type: 'eq', script });
            break;
          }
          case 'ctrl': {
            for (const c of children(el)) {
              const ct = local(c);
              if (ct === 'header' || ct === 'footer') {
                this.ctx[ct + 's'].push({ apply: attr(c, 'applyPageType', 'BOTH'), blocks: this.parseBlocks(c, depth + 1) });
              } else if (ct === 'footNote' || ct === 'endNote') {
                const blocks = this.parseBlocks(c, depth + 1);
                inlines.push({ type: 'note', kind: ct === 'footNote' ? 'fn' : 'en', blocks });
              }
            }
            break;
          }
          case 'tbl': {
            const tb = this.parseTable(el, depth + 1);
            if (tb) inlines.push(tb);
            break;
          }
          case 'pic': {
            const img = this.parsePic(el, depth + 1);
            if (img) { if (isInline(el)) inlines.push(img); else after.push(img); }
            break;
          }
          case 'container': case 'rect': case 'ellipse': case 'line': case 'arc': case 'polygon': case 'curve': case 'connectLine': case 'textart': case 'ole': case 'drawingObject': case 'shape': {
            const objs = this.parseShape(el, depth + 1);
            for (const ob of objs) { if (isInline(el) && ob.type === 'image') inlines.push(ob); else after.push(ob); }
            break;
          }
          default: break;
        }
      }
    }
    const para = { type: 'p', inlines, align: pp?.align || 'justify', headType: pp?.headType || 0, level: pp?.level || 0 };
    if (pp?.layout) para.layout = pp.layout;
    if (attr(p, 'pageBreak') === '1') para.pageBreak = true;
    if (head) para.numbering = { key: `${pp.headType}:${pp.numberingId}`, level: pp.level, prefix: head, bullet: pp.headType === 3, definition: this.h.numberings.get(pp.numberingId) };
    // Tables are block objects in the targets. Preserve their source order
    // instead of moving floating tables behind later inline tables.
    const ordered = [], chunk = [];
    let first = true;
    for (const il of inlines) {
      if (il.type !== 'table') { chunk.push(il); continue; }
      if (chunk.length) ordered.push({ ...para, inlines: chunk.splice(0), ...(first ? {} : {numbering:undefined}) });
      ordered.push(il); first = false;
    }
    if (chunk.length || !ordered.length) ordered.push({ ...para, inlines: chunk, ...(first ? {} : {numbering:undefined}) });
    return [...ordered, ...after];
  }

  parseT(el, st, inlines) {
    const push = (text) => { if (!text) return; const last = inlines[inlines.length - 1]; if (last && last.type === 'text' && sameStyle(last, st)) last.text += text; else inlines.push({ type: 'text', text, ...st }); };
    const k = el?.childNodes || [];
    for (let i = 0; i < k.length; i++) {
      const n = k[i];
      if (n.nodeType === 3 || n.nodeType === 4) { push(n.nodeValue); continue; }
      if (n.nodeType !== 1) continue;
      const t = local(n);
      if (t === 'tab') inlines.push({ type: 'tab' });
      else if (t === 'lineBreak') inlines.push({ type: 'br' });
      else if (t === 'nbSpace') push(' ');
      else if (t === 'fwSpace') push(' ');
      else if (t === 'hyphen') push('');
      else if (n.textContent) push(n.textContent);
    }
  }

  parseTable(tbl, depth) {
    const rows = num(attr(tbl, 'rowCnt'), 0), cols = num(attr(tbl, 'colCnt'), 0);
    const cells = [];
    let caption = null;
    for (const el of children(tbl)) {
      const t = local(el);
      if (t === 'caption') caption = this.parseBlocks(el, depth + 1);
      if (t !== 'tr') continue;
      for (const tc of children(el)) {
        if (local(tc) !== 'tc') continue;
        const addr = child(tc, 'cellAddr'), span = child(tc, 'cellSpan'), sz = child(tc, 'cellSz');
        const cell = {
          col: num(attr(addr, 'colAddr'), 0), row: num(attr(addr, 'rowAddr'), 0),
          colspan: num(attr(span, 'colSpan'), 1) || 1, rowspan: num(attr(span, 'rowSpan'), 1) || 1,
          width: num(attr(sz, 'width'), 0), height: num(attr(sz, 'height'), 0), blocks: [],
        };
        const sl = child(tc, 'subList');
        cell.verticalAlign = attr(sl, 'vertAlign', 'CENTER').toLowerCase();
        cell.style = this.h.borderFills?.get(attr(tc, 'borderFillIDRef'));
        cell.margins = margins(attr(tc, 'hasMargin') === '1' ? child(tc, 'cellMargin') : child(tbl, 'inMargin'));
        cell.header = attr(tc, 'header') === '1';
        cell.blocks = sl ? this.parseBlocks(sl, depth + 1) : [];
        cells.push(cell);
      }
    }
    const pos = child(tbl, 'pos');
    if (pos && attr(pos, 'treatAsChar') !== '1') {
      const warning = '떠 있는 표는 본문 순서대로 배치됩니다. 원본의 절대 위치와 쪽 나눔은 달라질 수 있습니다.';
      if (!this.ctx.warnings.includes(warning)) this.ctx.warnings.push(warning);
    }
    const sz = child(tbl, 'sz');
    let r = rows, c = cols;
    if (!r || !c) for (const cl of cells) { r = Math.max(r, cl.row + cl.rowspan); c = Math.max(c, cl.col + cl.colspan); }
    return { type: 'table', rows: r, cols: c, cells, caption, widthHU: num(attr(sz, 'width'), 0), repeatHeader: attr(tbl, 'repeatHeader') === '1', pageBreak: attr(tbl, 'pageBreak', 'CELL') };
  }

  parsePic(pic, depth) {
    const img = pic.getElementsByTagName('*');
    let ref = null;
    for (let i = 0; i < img.length; i++) if (local(img[i]) === 'img') { ref = attr(img[i], 'binaryItemIDRef'); break; }
    const sz = child(pic, 'sz') || child(pic, 'curSz');
    const widthPt = num(attr(sz, 'width'), 0) / 100, heightPt = num(attr(sz, 'height'), 0) / 100;
    const capEl = child(pic, 'caption');
    const caption = capEl ? this.parseBlocks(capEl, depth + 1) : null;
    if (!ref) return null;
    const key = this.ctx.imageRef(ref);
    if (!key) return null;
    return { type: 'image', ref: key, widthPt, heightPt, caption, behind: attr(pic, 'textWrap') === 'BEHIND_TEXT' };
  }

  parseShape(el, depth) {
    const out = [];
    const t = local(el);
    const sz = child(el, 'sz');
    const widthPt = num(attr(sz, 'width'), 0) / 100, heightPt = num(attr(sz, 'height'), 0) / 100;
    if (t === 'container') {
      for (const c of children(el)) {
        const ct = local(c);
        if (ct === 'pic') { const im = this.parsePic(c, depth + 1); if (im) out.push(im); }
        else if (['container', 'rect', 'ellipse', 'line', 'arc', 'polygon', 'curve', 'connectLine', 'textart'].includes(ct)) out.push(...this.parseShape(c, depth + 1));
      }
      if (out.length) return out;
    }
    // text box
    const dt = child(el, 'drawText');
    if (dt) {
      const blocks = this.parseBlocks(dt, depth + 1);
      if (blocks.some(b => b.type !== 'p' || b.inlines.length)) { out.push({ type: 'textbox', blocks, widthPt, heightPt }); return out; }
    }
    const names = { rect: '사각형', ellipse: '타원', line: '선', arc: '호', polygon: '다각형', curve: '곡선', connectLine: '연결선', textart: '글맵시', ole: 'OLE 개체', container: '묶음 개체' };
    const desc = names[t] || t;
    this.ctx.warnings.push(`그리기 개체(${desc})는 이미지로 변환되지 않습니다 — 그림으로 직접 삽입이 필요합니다.`);
    out.push({ type: 'shape', desc, widthPt, heightPt });
    return out;
  }
}

function isInline(el) {
  const pos = child(el, 'pos');
  if (pos && attr(pos, 'treatAsChar') === '1') return true;
  return attr(el, 'treatAsChar') === '1';
}
const sameStyle = (a, b) => a.bold === b.bold && a.italic === b.italic && a.underline === b.underline && a.sup === b.sup && a.sub === b.sub && a.size === b.size && a.font === b.font && JSON.stringify(a.fonts) === JSON.stringify(b.fonts);

export function parseHwpx(bytes) {
  let zip;
  try { zip = unzipSync(bytes); } catch (e) { throw new Error('HWPX(ZIP) 파일을 열 수 없습니다: ' + e.message); }
  const files = Object.keys(zip);
  const text = (p) => new TextDecoder('utf-8').decode(zip[p]);
  const findFile = (want) => files.find(f => f.toLowerCase() === want.toLowerCase()) || null;
  const mime = findFile('mimetype') ? text('mimetype').trim() : '';
  if (findFile('META-INF/manifest.xml') && /encrypt/i.test(text(findFile('META-INF/manifest.xml')))) throw new Error('암호가 걸린 문서는 변환할 수 없습니다.');
  const warnings = [];
  if (mime && !/hwp/i.test(mime)) warnings.push(`mimetype이 HWPX가 아닙니다: ${mime}`);

  // manifest (content.hpf)
  const manifest = new Map(); // id -> href
  let sectionPaths = [];
  const hpfPath = findFile('Contents/content.hpf');
  if (hpfPath) {
    try {
      const root = parseXml(text(hpfPath));
      const items = root.getElementsByTagName('*');
      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        if (local(it) === 'item') manifest.set(attr(it, 'id'), attr(it, 'href'));
        if (local(it) === 'itemref') { const href = manifest.get(attr(it, 'idref')); if (href && /section\d*\.xml$/i.test(href)) sectionPaths.push(href); }
      }
    } catch (e) { warnings.push('content.hpf 를 읽지 못했습니다: ' + e.message); }
  }
  if (!sectionPaths.length) sectionPaths = files.filter(f => /^Contents\/section\d+\.xml$/i.test(f)).sort((a, b) => +a.match(/(\d+)\.xml$/)[1] - +b.match(/(\d+)\.xml$/)[1]);
  if (!sectionPaths.length) throw new Error('본문(Contents/section*.xml)이 없습니다 — HWPX 파일이 맞는지 확인하세요.');

  const hdrPath = findFile('Contents/header.xml');
  const hdr = hdrPath ? parseHeader(parseXml(text(hdrPath))) : { charPr: new Map(), paraPr: new Map(), numberings: new Map(), bullets: new Map() };

  const images = new Map();
  const ctx = {
    warnings, headers: [], footers: [],
    imageRef: (id) => {
      if (images.has(id)) return id;
      let href = manifest.get(id);
      if (href && !findFile(href)) href = null;
      if (!href) {
        const cand = files.find(f => /^BinData\//i.test(f) && f.slice(8).replace(/\.[^.]+$/, '').toLowerCase() === id.toLowerCase());
        href = cand || files.find(f => /^BinData\//i.test(f) && f.toLowerCase().includes(id.toLowerCase()));
      }
      if (!href) { warnings.push(`그림 ${id} 의 데이터를 BinData에서 찾지 못했습니다.`); return null; }
      const ext = (href.match(/\.([a-z0-9]+)$/i) || [, 'bin'])[1].toLowerCase();
      images.set(id, { ext, data: zip[findFile(href)] });
      return id;
    },
  };
  const parser = new HwpxParser(hdr, ctx);
  const blocks = [];
  let page;
  const noteFormats = {};
  for (const sp of sectionPaths) {
    const path = findFile(sp);
    if (!path) continue;
    const root = parseXml(text(path));
    for (const kind of ['footNote','endNote']) {
      const pr = descendants(root, kind + 'Pr')[0];
      if (pr && !noteFormats[kind]) noteFormats[kind] = attr(child(pr, 'autoNumFormat'), 'type', 'DIGIT');
    }
    const pg = descendants(root, 'pagePr')[0];
    if (pg && !page) page = { width: num(attr(pg, 'width')), height: num(attr(pg, 'height')), ...Object.fromEntries(['left','right','top','bottom','header','footer','gutter'].map(k => [k, num(attr(child(pg, 'margin'), k))])) };
    blocks.push(...parser.parseBlocks(root));
  }
  if (sectionPaths.length > 1) warnings.push('여러 구역의 용지 설정과 머리말은 첫 구역 기준으로 변환됩니다.');
  return { source: 'hwpx', blocks, images, warnings, page, noteFormats, headers: ctx.headers, footers: ctx.footers };
}
