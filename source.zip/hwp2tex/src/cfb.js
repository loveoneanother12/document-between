// Minimal OLE2 / Compound File Binary reader (enough for HWP 5.x).
// Exposes: parseCFB(Uint8Array) -> { entries: Map<path, {name,type,size,data()}>, read(path) }

const ENDOFCHAIN = 0xfffffffe;
const FREESECT = 0xffffffff;

export function parseCFB(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const sig = [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1];
  for (let i = 0; i < 8; i++) if (bytes[i] !== sig[i]) throw new Error('OLE 복합 문서 서명이 아닙니다 (HWP 5.0 파일이 아닙니다)');

  const sectorShift = dv.getUint16(30, true);
  const miniShift = dv.getUint16(32, true);
  const sectorSize = 1 << sectorShift;
  const miniSize = 1 << miniShift;
  const numFat = dv.getUint32(44, true);
  const firstDir = dv.getUint32(48, true);
  const miniCutoff = dv.getUint32(56, true);
  const firstMiniFat = dv.getUint32(60, true);
  const numMiniFat = dv.getUint32(64, true);
  const firstDifat = dv.getUint32(68, true);
  const numDifat = dv.getUint32(72, true);
  const entriesPerSector = sectorSize / 4;

  const sectorOffset = (n) => (n + 1) * sectorSize;
  const readSectorU32 = (n) => {
    const off = sectorOffset(n);
    const out = new Uint32Array(entriesPerSector);
    for (let i = 0; i < entriesPerSector; i++) out[i] = dv.getUint32(off + i * 4, true);
    return out;
  };

  // DIFAT -> list of FAT sectors
  const fatSectors = [];
  for (let i = 0; i < 109 && fatSectors.length < numFat; i++) {
    const s = dv.getUint32(76 + i * 4, true);
    if (s === FREESECT || s === ENDOFCHAIN) break;
    fatSectors.push(s);
  }
  let difat = firstDifat;
  for (let d = 0; d < numDifat && difat !== ENDOFCHAIN && difat !== FREESECT; d++) {
    const arr = readSectorU32(difat);
    for (let i = 0; i < entriesPerSector - 1 && fatSectors.length < numFat; i++) {
      if (arr[i] === FREESECT) break;
      fatSectors.push(arr[i]);
    }
    difat = arr[entriesPerSector - 1];
  }
  // FAT
  const fat = new Uint32Array(fatSectors.length * entriesPerSector);
  fatSectors.forEach((s, i) => fat.set(readSectorU32(s), i * entriesPerSector));

  const chain = (start, table, limit) => {
    const out = [];
    let s = start;
    const seen = new Set();
    while (s !== ENDOFCHAIN && s !== FREESECT && s < table.length && !seen.has(s)) {
      seen.add(s);
      out.push(s);
      if (limit && out.length > limit) break;
      s = table[s];
    }
    return out;
  };

  const readChain = (start, size) => {
    const secs = chain(start, fat);
    const out = new Uint8Array(size);
    let pos = 0;
    for (const s of secs) {
      if (pos >= size) break;
      const off = sectorOffset(s);
      const n = Math.min(sectorSize, size - pos, bytes.length - off);
      if (n <= 0) break;
      out.set(bytes.subarray(off, off + n), pos);
      pos += n;
    }
    return out;
  };

  // Directory
  const dirSecs = chain(firstDir, fat);
  const dirBytes = new Uint8Array(dirSecs.length * sectorSize);
  dirSecs.forEach((s, i) => {
    const off = sectorOffset(s);
    dirBytes.set(bytes.subarray(off, Math.min(off + sectorSize, bytes.length)), i * sectorSize);
  });
  const ddv = new DataView(dirBytes.buffer);
  const entries = [];
  for (let i = 0; i + 128 <= dirBytes.length; i++) {
    const o = i * 128;
    if (o + 128 > dirBytes.length) break;
    const nameLen = ddv.getUint16(o + 64, true);
    const type = dirBytes[o + 66];
    if (type === 0) { entries.push(null); continue; }
    let name = '';
    for (let k = 0; k + 1 < nameLen; k += 2) {
      const c = ddv.getUint16(o + k, true);
      if (c === 0) break;
      name += String.fromCharCode(c);
    }
    entries.push({
      name, type,
      left: ddv.getUint32(o + 68, true),
      right: ddv.getUint32(o + 72, true),
      child: ddv.getUint32(o + 76, true),
      start: ddv.getUint32(o + 116, true),
      size: ddv.getUint32(o + 120, true),
    });
  }
  const root = entries[0];
  if (!root) throw new Error('CFB 루트 디렉터리가 없습니다');

  // MiniFAT + mini stream
  let miniFat = new Uint32Array(0);
  if (numMiniFat > 0 && firstMiniFat !== ENDOFCHAIN) {
    const mfSecs = chain(firstMiniFat, fat);
    miniFat = new Uint32Array(mfSecs.length * entriesPerSector);
    mfSecs.forEach((s, i) => miniFat.set(readSectorU32(s), i * entriesPerSector));
  }
  const miniStream = readChain(root.start, root.size);
  const readMini = (start, size) => {
    const secs = chain(start, miniFat);
    const out = new Uint8Array(size);
    let pos = 0;
    for (const s of secs) {
      if (pos >= size) break;
      const off = s * miniSize;
      const n = Math.min(miniSize, size - pos, miniStream.length - off);
      if (n <= 0) break;
      out.set(miniStream.subarray(off, off + n), pos);
      pos += n;
    }
    return out;
  };

  // Walk tree to build paths
  const files = new Map();
  const walk = (idx, prefix, depth) => {
    if (idx === FREESECT || idx >= entries.length || depth > 64) return;
    const e = entries[idx];
    if (!e) return;
    walk(e.left, prefix, depth + 1);
    walk(e.right, prefix, depth + 1);
    const path = prefix + e.name;
    if (e.type === 2) {
      files.set(path, {
        name: e.name, size: e.size,
        data: () => (e.size < miniCutoff ? readMini(e.start, e.size) : readChain(e.start, e.size)),
      });
    } else if (e.type === 1) {
      walk(e.child, path + '/', depth + 1);
    }
  };
  walk(root.child, '', 0);

  return {
    files,
    list: () => [...files.keys()],
    read: (path) => {
      const f = files.get(path);
      return f ? f.data() : null;
    },
  };
}
