// Document model -> LaTeX source (+ image files)
import { hwpEqToLatex } from './eqn.js';
import { bmpToPng } from './bmp2png.js';

const ESC = { '\\': '\\textbackslash{}', '{': '\\{', '}': '\\}', '$': '\\$', '&': '\\&', '#': '\\#', '%': '\\%', '_': '\\_', '~': '\\textasciitilde{}', '^': '\\textasciicircum{}' };
export function escText(s) {
  return s.replace(/[\\{}$&#%_~^]/g, (c) => ESC[c])
    .replace(/\u00a0/g, '~')
    .replace(/[“”]/g, (c) => c === '“' ? '``' : "''")
    .replace(/[‘’]/g, (c) => c === '‘' ? '`' : "'")
    .replace(/[\u200b\u200c\u200d\ufeff]/g, '');
}

const DEFAULTS = {
  notes: 'keep',        // keep | footnote | endnote | section
  engine: 'kotex',      // kotex | fontspec
  imagesDir: 'images',
  wrap: true,           // full document
  title: '',
  keepStyles: true,     // bold/italic/underline
};

export function docToLatex(doc, options = {}) {
  const o = { ...DEFAULTS, ...options };
  const warnings = [...(doc.warnings || [])];
  const files = [];
  const imageNames = new Map(); // ref -> file path
  const needs = { endnotes: false, multirow: false, tcolorbox: false, graphicx: false, array: false };
  const sectionNotes = []; // for notes:'section'
  const eqWarnings = new Map();

  // ---- images ----
  for (const [ref, img] of doc.images) {
    let ext = img.ext, data = img.data;
    if (ext === 'bmp' || ext === 'dib') {
      const png = bmpToPng(data);
      if (png) { ext = 'png'; data = png; }
      else warnings.push(`${ref}.bmp 는 지원하지 않는 BMP 형식이라 PNG로 바꾸지 못했습니다. 직접 변환해 주세요.`);
    } else if (ext === 'wmf' || ext === 'emf') {
      warnings.push(`${ref}.${ext} (${ext.toUpperCase()}) 는 LaTeX가 바로 읽지 못합니다. PDF/PNG로 변환해 주세요.`);
    } else if (ext === 'jpeg') ext = 'jpg';
    const path = `${o.imagesDir}/${ref}.${ext}`;
    imageNames.set(ref, path);
    files.push({ path, data });
  }

  const eqToLatex = (script) => {
    const r = hwpEqToLatex(script);
    if (r.warnings.length) eqWarnings.set(script, r.warnings);
    return r.latex;
  };
  const eqLatex = (il) => il.latex !== undefined ? il.latex : eqToLatex(il.script);

  // ---- inline rendering ----
  const renderInlines = (inlines, ctx) => {
    const parts = [];
    const after = [];
    // merge consecutive equal-style text
    for (let i = 0; i < inlines.length; i++) {
      const il = inlines[i];
      switch (il.type) {
        case 'text': {
          let t = escText(il.text);
          if (!t) break;
          if (il.sup) t = `\\textsuperscript{${t}}`;
          if (il.sub) t = `\\textsubscript{${t}}`;
          if (o.keepStyles && t.trim()) {
            if (il.bold) t = `\\textbf{${t}}`;
            if (il.italic) t = `\\textit{${t}}`;
            if (il.underline) t = `\\underline{${t}}`;
          }
          parts.push(t); break;
        }
        case 'eq': {
          const l = eqLatex(il);
          if (!l) break;
          parts.push(il.display ? `\\[ ${l} \\]` : `$${l}$`);
          break;
        }
        case 'note': {
          const body = renderBlocks(il.blocks, { ...ctx, inNote: true }).trim();
          if (!body) break;
          let mode = o.notes === 'keep' ? (il.kind === 'en' ? 'endnote' : 'footnote') : o.notes;
          if (ctx.inTable && mode === 'footnote') mode = 'footnotemark';
          if (mode === 'footnote') parts.push(`\\footnote{${body}}`);
          else if (mode === 'endnote') { needs.endnotes = true; parts.push(`\\endnote{${body}}`); }
          else if (mode === 'section') { sectionNotes.push(body); parts.push(`\\textsuperscript{${sectionNotes.length})}`); }
          else { // footnotemark inside table: put text after table
            parts.push(`\\footnotemark`);
            ctx.pendingFootnotes?.push(body);
          }
          break;
        }
        case 'image': {
          const path = imageNames.get(il.ref);
          if (!path) break;
          needs.graphicx = true;
          if (il.behind) {
            if (ctx.inTable) { warnings.push(`표 안의 '글 뒤' 배경 그림(${path})은 생략했습니다.`); break; }
            after.push(`% 글 뒤 배경 그림 (필요 없으면 아래 한 줄 삭제)\n\\includegraphics[width=${imgWidth(il.widthPt)}]{${path}}`);
            break;
          }
          parts.push(`\\includegraphics[width=${imgWidth(il.widthPt)}]{${path}}`);
          break;
        }
        case 'table': after.push(renderTable(il, ctx)); break;
        case 'textbox': after.push(renderTextbox(il, ctx)); break;
        case 'shape': after.push(renderShape(il)); break;
        case 'tab': parts.push('\\quad '); break;
        case 'br': parts.push('\\newline\n'); break;
        default: break;
      }
    }
    return { text: parts.join('').replace(/\\newline\n$/, ''), after };
  };

  const fmt = (n) => Math.round(n * 10) / 10;
  const imgWidth = (pt) => (!pt || pt <= 0) ? '0.6\\linewidth' : pt > 440 ? '\\linewidth' : `${fmt(pt)}pt`;
  const sizeCmd = (pt) => pt >= 24 ? '\\Huge' : pt >= 20 ? '\\LARGE' : pt >= 16 ? '\\Large' : pt >= 13 ? '\\large' : '';

  const renderParagraph = (p, ctx) => {
    const inl = p.inlines;
    // display equation: a paragraph that is only one equation (plus whitespace)
    const nonWs = inl.filter(x => !(x.type === 'text' && !x.text.trim()) && x.type !== 'tab');
    if (nonWs.length === 1 && nonWs[0].type === 'eq' && !ctx.inTable) {
      const l = eqLatex(nonWs[0]);
      return l ? `\\[ ${l} \\]` : '';
    }
    const { text, after } = renderInlines(inl, ctx);
    let body = text.split('\\newline\n').map(x => x.trim()).filter(Boolean).join(' \\newline\n');
    if (!body.replace(/\\quad ?/g, '').trim()) body = '';
    if (body && o.keepStyles && !ctx.inTable && !ctx.inNote) {
      const sizes = inl.filter(x => x.type === 'text' && x.text.trim() && x.size).map(x => x.size);
      if (sizes.length && sizes.every(sz => sz === sizes[0]) && sizeCmd(sizes[0])) body = `{${sizeCmd(sizes[0])} ${body}\\par}`;
    }
    if (body && !ctx.inTable && !ctx.inNote) {
      if (p.align === 'center') body = `\\begin{center}\n${body}\n\\end{center}`;
      else if (p.align === 'right') body = `\\begin{flushright}\n${body}\n\\end{flushright}`;
    }
    return [body, ...after].filter(Boolean).join('\n\n');
  };

  const renderTable = (t, ctx) => {
    const rows = Math.max(1, t.rows), cols = Math.max(1, t.cols);
    const grid = Array.from({ length: rows }, () => Array(cols).fill(null));
    for (const c of t.cells) {
      if (c.row >= rows || c.col >= cols) continue;
      grid[c.row][c.col] = { cell: c, start: true };
      for (let r = c.row; r < Math.min(rows, c.row + c.rowspan); r++)
        for (let k = c.col; k < Math.min(cols, c.col + c.colspan); k++)
          if (!(r === c.row && k === c.col)) grid[r][k] = { cell: c, start: false };
    }
    // column widths (pt) from spanning-free cells
    const widths = Array(cols).fill(0);
    for (const c of t.cells) if (c.colspan === 1 && c.col < cols && c.width) widths[c.col] = Math.max(widths[c.col], c.width / 100);
    const total = widths.reduce((a, b) => a + b, 0);
    const haveWidths = widths.every(w => w > 0);
    const maxW = 440; // pt, roughly text width
    const scale = haveWidths && total > maxW ? maxW / total : 1;
    needs.array = true;
    const colSpec = '|' + widths.map(w => haveWidths ? `>{\\centering\\arraybackslash}m{${fmt((w - 10) * scale)}pt}|` : 'c|').join('');
    const pending = [];
    const cctx = { ...ctx, inTable: true, pendingFootnotes: pending };
    const lines = [];
    for (let r = 0; r < rows; r++) {
      const cellsOut = [];
      let k = 0;
      while (k < cols) {
        const g = grid[r][k];
        if (!g) { cellsOut.push(''); k++; continue; }
        const c = g.cell;
        const span = Math.min(c.colspan, cols - k);
        let content = '';
        if (g.start) {
          content = renderBlocks(c.blocks, cctx).trim().replace(/\n\n+/g, ' \\newline ').replace(/\n/g, ' ');
          if (c.rowspan > 1) { needs.multirow = true; content = `\\multirow{${c.rowspan}}{*}{${content}}`; }
        } else if (c.col === k && r > c.row) {
          content = ''; // covered by multirow
        }
        if (span > 1 || (c.col === k && c.colspan > 1)) {
          const spec = (k === 0 ? '|' : '') + (haveWidths ? `>{\\centering\\arraybackslash}m{${fmt(spanWidth(widths, k, span) * scale - 10)}pt}|` : 'c|');
          content = `\\multicolumn{${span}}{${spec}}{${content}}`;
        }
        cellsOut.push(content);
        k += span;
      }
      // hline: only draw full line where no multirow continues — keep simple with \hline
      lines.push(cellsOut.join(' & ') + ' \\\\ \\hline');
    }
    const tab = `\\begin{center}\n\\begin{tabular}{${colSpec}}\n\\hline\n${lines.join('\n')}\n\\end{tabular}\n\\end{center}`;
    const notes = pending.map(b => `\\footnotetext{${b}}`).join('\n');
    const caption = t.caption ? renderBlocks(t.caption, ctx).trim() : '';
    return [caption ? `\\begin{center}${caption}\\end{center}` : '', tab, notes].filter(Boolean).join('\n');
  };
  const spanWidth = (widths, k, span) => { let s = 0; for (let i = k; i < k + span; i++) s += widths[i] || 0; return s; };

  const renderTextbox = (tb, ctx) => {
    needs.tcolorbox = true;
    const body = renderBlocks(tb.blocks, ctx).trim();
    return `\\begin{tcolorbox}[colback=white,colframe=black,boxrule=0.4pt,arc=0pt]\n${body}\n\\end{tcolorbox}`;
  };
  const renderShape = (sh) => {
    const w = Math.min(Math.max(sh.widthPt || 100, 40), 440), h = Math.min(Math.max(sh.heightPt || 60, 20), 600);
    return `\\begin{center}\\framebox[${fmt(w)}pt]{\\rule{0pt}{${fmt(h)}pt}\\textit{(그리기 개체: ${escText(sh.desc)} — 그림으로 직접 삽입)}}\\end{center}`;
  };

  const renderBlocks = (blocks, ctx) => {
    const out = [];
    for (const b of blocks) {
      switch (b.type) {
        case 'p': { const s = renderParagraph(b, ctx); if (s) out.push(s); break; }
        case 'display': { const l = eqLatex(b); if (l) out.push(`\\[ ${l} \\]`); break; }
        case 'heading': {
          const { text } = renderInlines(b.inlines.map(i => i.type === 'text' ? { ...i, bold: false, size: 0 } : i), ctx);
          const cmd = b.level <= 1 ? 'section' : b.level === 2 ? 'subsection' : 'subsubsection';
          if (text.trim()) out.push(`\\${cmd}*{${text.trim()}}`);
          break;
        }
        case 'table': out.push(renderTable(b, ctx)); break;
        case 'image': {
          const path = imageNames.get(b.ref); if (!path) break;
          needs.graphicx = true;
          const cap = b.caption ? renderBlocks(b.caption, ctx).trim() : '';
          const ig = `\\includegraphics[width=${imgWidth(b.widthPt)}]{${path}}`;
          if (b.behind && ctx.inTable) { warnings.push(`표 안의 '글 뒤' 배경 그림(${path})은 생략했습니다.`); break; }
          if (b.behind) out.push(`% 글 뒤 배경 그림 (필요 없으면 아래 한 줄 삭제)\n${ig}`);
          else if (ctx.inTable) out.push(ig + (cap ? ` \\newline ${cap}` : ''));
          else out.push(`\\begin{center}\n${ig}${cap ? `\\\\[2pt]\n${cap}` : ''}\n\\end{center}`);
          break;
        }
        case 'textbox': out.push(renderTextbox(b, ctx)); break;
        case 'shape': out.push(renderShape(b)); break;
        default: break;
      }
    }
    return out.join('\n\n');
  };

  let body = renderBlocks(doc.blocks, {});
  if (o.notes === 'section' && sectionNotes.length) {
    body += `\n\n\\section*{해설}\n\\begin{enumerate}\n` + sectionNotes.map(n => `\\item ${n}`).join('\n') + `\n\\end{enumerate}`;
  }
  if (needs.endnotes) body += '\n\n\\theendnotes';

  for (const [script, ws] of eqWarnings) warnings.push(`수식 "${script.slice(0, 40)}": ${ws.join(', ')}`);

  if (!o.wrap) return { tex: body, files, warnings };

  const pre = [];
  pre.push('\\documentclass[11pt,a4paper]{article}');
  pre.push('\\usepackage[margin=20mm]{geometry}');
  if (o.engine === 'fontspec') {
    pre.push('\\usepackage{fontspec}');
    pre.push('\\setmainfont{Noto Serif CJK KR}');
    pre.push('\\setsansfont{Noto Sans CJK KR}');
  } else {
    pre.push('\\usepackage{kotex}  % XeLaTeX 또는 LuaLaTeX로 컴파일하세요');
  }
  pre.push('\\usepackage{amsmath,amssymb}');
  pre.push('\\usepackage{graphicx}');
  pre.push('\\usepackage{array}');
  if (needs.multirow) pre.push('\\usepackage{multirow}');
  if (needs.tcolorbox) pre.push('\\usepackage{tcolorbox}');
  if (needs.endnotes) pre.push('\\usepackage{endnotes}');
  pre.push('\\setlength{\\parindent}{0pt}');
  pre.push('\\setlength{\\parskip}{6pt}');
  pre.push('\\renewcommand{\\arraystretch}{1.2}');
  pre.push('% --- 이 파일은 HWP→LaTeX 변환기로 생성되었습니다 ---');
  const tex = pre.join('\n') + '\n\n\\begin{document}\n\n' + body + '\n\n\\end{document}\n';
  return { tex, files, warnings };
}
