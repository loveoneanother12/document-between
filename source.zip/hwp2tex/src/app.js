// Browser entry: exposes window.HWP2TEX
import { zipSync, unzipSync } from 'fflate';
import { convert, detectFormat, hwpEqToLatex, parseDocument, parseDocx, docToLatex, docToDocx, docToHwpx, latexToHancom, parseLatexDoc } from './index.js';

function walkEquations(doc, fn) {
  const walk = (blocks) => {
    for (const b of blocks || []) {
      if (b.type === 'p' || b.type === 'heading') for (const il of b.inlines) {
        if (il.type === 'eq') fn(il);
        else if (il.type === 'note') walk(il.blocks);
        else if (il.type === 'table') walk(il.cells.flatMap(c => c.blocks));
        else if (il.type === 'textbox') walk(il.blocks);
      } else if (b.type === 'display') fn(b);
      else if (b.type === 'table') { walk(b.cells.flatMap(c => c.blocks)); if (b.caption) walk(b.caption); }
      else if (b.type === 'textbox') walk(b.blocks);
    }
  };
  walk(doc.blocks);
  for (const part of [...(doc.headers || []), ...(doc.footers || [])]) walk(part.blocks);
}

function stats(doc) {
  const s = { paras: 0, eqs: 0, notes: 0, tables: 0, images: doc.images.size, shapes: 0 };
  const walk = (blocks) => {
    for (const b of blocks || []) {
      if (b.type === 'p' || b.type === 'heading') { if (b.inlines.length) s.paras++; for (const il of b.inlines) { if (il.type === 'eq') s.eqs++; else if (il.type === 'note') { s.notes++; walk(il.blocks); } else if (il.type === 'table') { s.tables++; walk(il.cells.flatMap(c => c.blocks)); } else if (il.type === 'textbox') walk(il.blocks); else if (il.type === 'shape') s.shapes++; } }
      else if (b.type === 'display') s.eqs++;
      else if (b.type === 'table') { s.tables++; walk(b.cells.flatMap(c => c.blocks)); }
      else if (b.type === 'textbox') walk(b.blocks);
      else if (b.type === 'shape') s.shapes++;
    }
  };
  walk(doc.blocks);
  for (const part of [...(doc.headers || []), ...(doc.footers || [])]) walk(part.blocks);
  return s;
}

// equation review rows: {src, srcKind, out, outKind, latex (for rendering), warnings}
function eqRows(doc, target) {
  const rows = [];
  walkEquations(doc, (eq) => {
    if (eq.script !== undefined) { // source is Hancom
      const r = hwpEqToLatex(eq.script);
      rows.push({ src: eq.script, srcKind: 'hwp', out: r.latex, outKind: 'tex', latex: r.latex, warnings: r.warnings });
    } else { // source is LaTeX (from .tex or Word)
      if (target === 'hwpx') { const h = latexToHancom(eq.latex); rows.push({ src: eq.latex, srcKind: 'tex', out: h.script, outKind: 'hwp', latex: eq.latex, warnings: h.warnings }); }
      else rows.push({ src: eq.latex, srcKind: doc.source === 'docx' ? 'docx' : 'tex', out: eq.latex, outKind: 'tex', latex: eq.latex, warnings: [] });
    }
  });
  return rows;
}

function findTexInZip(bytes) {
  const zip = unzipSync(bytes);
  const files = new Map();
  let texName = null, texText = null;
  const texs = Object.keys(zip).filter(k => /\.tex$/i.test(k) && !/(^|\/)__MACOSX\//.test(k));
  const pick = texs.find(k => /(^|\/)main\.tex$/i.test(k)) || texs.sort((a, b) => zip[b].length - zip[a].length)[0];
  for (const [k, v] of Object.entries(zip)) { if (k.endsWith('/')) continue; files.set(k, v); }
  if (pick) { texName = pick; texText = new TextDecoder('utf-8').decode(zip[pick]); }
  return { texName, texText, files };
}

// mode: hwp2tex | hwp2docx | tex2hwpx | docx2hwpx | docx2tex
export function runMode(mode, bytes, name, opts = {}) {
  const fmt = detectFormat(bytes);
  const isZip = fmt === 'hwpx';
  switch (mode) {
    case 'hwp2tex': {
      if (fmt !== 'hwp' && fmt !== 'hwpx') throw new Error('HWP 또는 HWPX 파일이 아닙니다.');
      const r = convert(bytes, opts);
      return { kind: 'tex', tex: r.tex, files: r.files, warnings: r.warnings, stats: stats(r.doc), equations: eqRows(r.doc, 'tex'), format: r.doc.source };
    }
    case 'hwp2docx': {
      if (fmt !== 'hwp' && fmt !== 'hwpx') throw new Error('HWP 또는 HWPX 파일이 아닙니다.');
      const doc = parseDocument(bytes);
      const r = docToDocx(doc, { title: name, fontMode: opts.fontMode || 'compatible', font: opts.font, latinFont: opts.latinFont });
      return { kind: 'docx', data: r.docx, warnings: r.warnings, stats: stats(doc), equations: eqRows(doc, 'tex'), format: doc.source };
    }
    case 'tex2hwpx': {
      let texText, files = new Map();
      if (isZip) { const z = findTexInZip(bytes); if (!z.texText) throw new Error('ZIP 안에서 .tex 파일을 찾지 못했습니다.'); texText = z.texText; files = z.files; }
      else texText = new TextDecoder('utf-8').decode(bytes);
      if (!/\\(begin|section|documentclass|item|frac|textbf|\[|\()|\$/.test(texText)) throw new Error('LaTeX 소스로 보이지 않습니다 (.tex 또는 .tex와 그림을 담은 .zip 을 올려 주세요).');
      const doc = parseLatexDoc(texText, files);
      const r = docToHwpx(doc, { title: name, eqToScript: latexToHancom });
      return { kind: 'hwpx', data: r.hwpx, warnings: [...doc.warnings, ...r.warnings], stats: stats(doc), equations: eqRows(doc, 'hwpx'), format: 'latex' };
    }
    case 'docx2hwpx': {
      if (!isZip) throw new Error('Word(.docx) 파일이 아닙니다.');
      const doc = parseDocx(bytes);
      const r = docToHwpx(doc, { title: name, eqToScript: latexToHancom });
      return { kind: 'hwpx', data: r.hwpx, warnings: [...doc.warnings, ...r.warnings], stats: stats(doc), equations: eqRows(doc, 'hwpx'), format: 'docx' };
    }
    case 'docx2tex': {
      if (!isZip) throw new Error('Word(.docx) 파일이 아닙니다.');
      const doc = parseDocx(bytes);
      const r = docToLatex(doc, opts);
      return { kind: 'tex', tex: r.tex, files: r.files, warnings: [...doc.warnings, ...r.warnings], stats: stats(doc), equations: eqRows(doc, 'tex'), format: 'docx' };
    }
    default: throw new Error('알 수 없는 변환 방향: ' + mode);
  }
}

export function makeZip(entries) { // {path: Uint8Array|string}
  const out = {};
  for (const [k, v] of Object.entries(entries)) out[k] = typeof v === 'string' ? new TextEncoder().encode(v) : [v, { level: 0 }];
  return zipSync(out, { level: 6 });
}

export { detectFormat, hwpEqToLatex, latexToHancom };
