// Document model -> HWPX (OWPML zip)
import { zipSync } from 'fflate';
import { imageSize } from './imgsize.js';

const xe = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const XMLH = '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>';
const NS_SEC = 'xmlns:ha="http://www.hancom.co.kr/hwpml/2011/app" xmlns:hp="http://www.hancom.co.kr/hwpml/2011/paragraph" xmlns:hp10="http://www.hancom.co.kr/hwpml/2016/paragraph" xmlns:hs="http://www.hancom.co.kr/hwpml/2011/section" xmlns:hc="http://www.hancom.co.kr/hwpml/2011/core" xmlns:hh="http://www.hancom.co.kr/hwpml/2011/head" xmlns:hhs="http://www.hancom.co.kr/hwpml/2011/history" xmlns:hm="http://www.hancom.co.kr/hwpml/2011/master-page" xmlns:hpf="http://www.hancom.co.kr/schema/2011/hpf" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:opf="http://www.idpf.org/2007/opf/" xmlns:ooxmlchart="http://www.hancom.co.kr/hwpml/2016/ooxmlchart" xmlns:hwpunitchar="http://www.hancom.co.kr/hwpml/2016/HwpUnitChar" xmlns:epub="http://www.idpf.org/2007/ops" xmlns:config="urn:oasis:names:tc:opendocument:xmlns:config:1.0"';

const PAGE_W = 59528, PAGE_H = 84188, MARGIN = 5669;
const TEXT_W = PAGE_W - MARGIN * 2; // 48190 HWPUNIT

const FONTS = ['함초롬바탕', '함초롬돋움'];
function fontfaces(fonts) {
  const langs = ['HANGUL', 'LATIN', 'HANJA', 'JAPANESE', 'OTHER', 'SYMBOL', 'USER'];
  return `<hh:fontfaces itemCnt="7">` + langs.map(l => `<hh:fontface lang="${l}" fontCnt="${fonts.length}">` + fonts.map((f, i) => `<hh:font id="${i}" face="${xe(f)}" type="TTF" isEmbedded="0"><hh:typeInfo familyType="FCAT_GOTHIC" weight="6" proportion="4" contrast="0" strokeVariation="1" armStyle="1" letterform="1" midline="1" xHeight="1"/></hh:font>`).join('') + `</hh:fontface>`).join('') + `</hh:fontfaces>`;
}
function borderFills() {
  const bf = (id, type, fill) => `<hh:borderFill id="${id}" threeD="0" shadow="0" centerLine="NONE" breakCellSeparateLine="0"><hh:slash type="NONE" Crooked="0" isCounter="0"/><hh:backSlash type="NONE" Crooked="0" isCounter="0"/><hh:leftBorder type="${type}" width="0.12 mm" color="#000000"/><hh:rightBorder type="${type}" width="0.12 mm" color="#000000"/><hh:topBorder type="${type}" width="0.12 mm" color="#000000"/><hh:bottomBorder type="${type}" width="0.12 mm" color="#000000"/>${fill ? '<hc:fillBrush><hc:winBrush faceColor="#F2F2F2" hatchColor="#000000" alpha="0"/></hc:fillBrush>' : ''}</hh:borderFill>`;
  return `<hh:borderFills itemCnt="3">${bf(1, 'NONE')}${bf(2, 'SOLID')}${bf(3, 'SOLID', true)}</hh:borderFills>`;
}

class Styles {
  constructor() { this.fonts = [...FONTS]; this.chars = new Map(); this.charList = []; this.paras = new Map(); this.paraList = []; }
  charId(st = {}) {
    const size = Math.round((st.size || 10) * 100);
    const font = st.font || FONTS[0];
    if (!this.fonts.includes(font)) this.fonts.push(font);
    const fontId = this.fonts.indexOf(font);
    const key = [fontId, size, !!st.bold, !!st.italic, !!st.underline, !!st.sup, !!st.sub].join('|');
    if (this.chars.has(key)) return this.chars.get(key);
    const id = this.charList.length;
    this.chars.set(key, id);
    this.charList.push({ fontId, size, bold: !!st.bold, italic: !!st.italic, underline: !!st.underline, sup: !!st.sup, sub: !!st.sub });
    return id;
  }
  paraId(align = 'justify', opts = {}) {
    const key = [align, opts.indent || 0, opts.left || 0].join('|');
    if (this.paras.has(key)) return this.paras.get(key);
    const id = this.paraList.length;
    this.paras.set(key, id);
    this.paraList.push({ align, indent: opts.indent || 0, left: opts.left || 0 });
    return id;
  }
  charXml() {
    return `<hh:charProperties itemCnt="${this.charList.length}">` + this.charList.map((c, i) =>
      `<hh:charPr id="${i}" height="${c.size}" textColor="#000000" shadeColor="none" useFontSpace="0" useKerning="0" symMark="NONE" borderFillIDRef="1"><hh:fontRef hangul="${c.fontId}" latin="${c.fontId}" hanja="${c.fontId}" japanese="${c.fontId}" other="${c.fontId}" symbol="${c.fontId}" user="${c.fontId}"/><hh:ratio hangul="100" latin="100" hanja="100" japanese="100" other="100" symbol="100" user="100"/><hh:spacing hangul="0" latin="0" hanja="0" japanese="0" other="0" symbol="0" user="0"/><hh:relSz hangul="100" latin="100" hanja="100" japanese="100" other="100" symbol="100" user="100"/><hh:offset hangul="0" latin="0" hanja="0" japanese="0" other="0" symbol="0" user="0"/>${c.bold ? '<hh:bold/>' : ''}${c.italic ? '<hh:italic/>' : ''}<hh:underline type="${c.underline ? 'BOTTOM' : 'NONE'}" shape="SOLID" color="#000000"/>${c.sup ? '<hh:supscript/>' : ''}${c.sub ? '<hh:subscript/>' : ''}</hh:charPr>`).join('') + `</hh:charProperties>`;
  }
  paraXml() {
    const AL = { justify: 'JUSTIFY', left: 'LEFT', right: 'RIGHT', center: 'CENTER', distribute: 'DISTRIBUTE' };
    return `<hh:paraProperties itemCnt="${this.paraList.length}">` + this.paraList.map((p, i) =>
      `<hh:paraPr id="${i}" tabPrIDRef="0" condense="0" fontLineHeight="0" snapToGrid="0" suppressLineNumbers="0" checked="0" textDir="AUTO"><hh:align horizontal="${AL[p.align] || 'JUSTIFY'}" vertical="BASELINE"/><hh:heading type="NONE" idRef="0" level="0"/><hh:breakSetting breakLatinWord="KEEP_WORD" breakNonLatinWord="BREAK_WORD" widowOrphan="0" keepWithNext="0" keepLines="0" pageBreakBefore="0" lineWrap="BREAK"/><hh:autoSpacing eAsianEng="0" eAsianNum="0"/><hh:margin><hc:intent value="${p.indent}" unit="HWPUNIT"/><hc:left value="${p.left}" unit="HWPUNIT"/><hc:right value="0" unit="HWPUNIT"/><hc:prev value="0" unit="HWPUNIT"/><hc:next value="0" unit="HWPUNIT"/></hh:margin><hh:lineSpacing type="PERCENT" value="160"/><hh:border borderFillIDRef="1" offsetLeft="0" offsetRight="0" offsetTop="0" offsetBottom="0" connect="0" ignoreMargin="0"/></hh:paraPr>`).join('') + `</hh:paraProperties>`;
  }
}

function headerXml(st, secCnt = 1) {
  return XMLH + `<hh:head xmlns:hh="http://www.hancom.co.kr/hwpml/2011/head" xmlns:hp="http://www.hancom.co.kr/hwpml/2011/paragraph" xmlns:hc="http://www.hancom.co.kr/hwpml/2011/core" version="1.4" secCnt="${secCnt}">` +
    `<hh:beginNum page="1" footnote="1" endnote="1" pic="1" tbl="1" equation="1"/><hh:refList>` + fontfaces(st.fonts) + borderFills() + st.charXml() +
    `<hh:tabProperties itemCnt="1"><hh:tabPr id="0" autoTabLeft="0" autoTabRight="0"/></hh:tabProperties><hh:numberings itemCnt="0"/><hh:bullets itemCnt="0"/>` + st.paraXml() +
    `<hh:styles itemCnt="1"><hh:style id="0" type="PARA" name="바탕글" engName="Normal" paraPrIDRef="0" charPrIDRef="0" nextStyleIDRef="0" langID="1042" lockForm="0"/></hh:styles>` +
    `</hh:refList><hh:compatibleDocument targetProgram="HWP201X"><hh:layoutCompatibility/></hh:compatibleDocument><hh:docOption><hh:linkinfo path="" pageInherit="0" footnoteInherit="0"/></hh:docOption></hh:head>`;
}

const SECPR = `<hp:secPr id="" textDirection="HORIZONTAL" spaceColumns="1134" tabStop="8000" tabStopVal="4000" tabStopUnit="HWPUNIT" outlineShapeIDRef="0" memoShapeIDRef="0" textVerticalWidthHead="0" masterPageCnt="0"><hp:grid lineGrid="0" charGrid="0" wonggojiFormat="0"/><hp:startNum pageStartsOn="BOTH" page="0" pic="0" tbl="0" equation="0"/><hp:visibility hideFirstHeader="0" hideFirstFooter="0" hideFirstMasterPage="0" border="SHOW_ALL" fill="SHOW_ALL" hideFirstPageNum="0" hideFirstEmptyLine="0" showLineNumber="0"/><hp:lineNumberShape restartType="0" countBy="0" distance="0" startNumber="0"/><hp:pagePr landscape="WIDELY" width="${PAGE_W}" height="${PAGE_H}" gutterType="LEFT_ONLY"><hp:margin header="4252" footer="4252" gutter="0" left="${MARGIN}" right="${MARGIN}" top="5669" bottom="4252"/></hp:pagePr><hp:footNotePr><hp:autoNumFormat type="DIGIT" userChar="" prefixChar="" suffixChar=")" supscript="0"/><hp:noteLine length="-1" type="SOLID" width="0.12 mm" color="#000000"/><hp:noteSpacing betweenNotes="283" belowLine="567" aboveLine="850"/><hp:numbering type="CONTINUOUS" newNum="1"/><hp:placement place="EACH_COLUMN" beneathText="0"/></hp:footNotePr><hp:endNotePr><hp:autoNumFormat type="DIGIT" userChar="" prefixChar="" suffixChar=")" supscript="0"/><hp:noteLine length="14692344" type="SOLID" width="0.12 mm" color="#000000"/><hp:noteSpacing betweenNotes="0" belowLine="567" aboveLine="850"/><hp:numbering type="CONTINUOUS" newNum="1"/><hp:placement place="END_OF_DOCUMENT" beneathText="0"/></hp:endNotePr><hp:pageBorderFill type="BOTH" borderFillIDRef="1" textBorder="PAPER" headerInside="0" footerInside="0" fillArea="PAPER"><hp:offset left="1417" right="1417" top="1417" bottom="1417"/></hp:pageBorderFill><hp:pageBorderFill type="EVEN" borderFillIDRef="1" textBorder="PAPER" headerInside="0" footerInside="0" fillArea="PAPER"><hp:offset left="1417" right="1417" top="1417" bottom="1417"/></hp:pageBorderFill><hp:pageBorderFill type="ODD" borderFillIDRef="1" textBorder="PAPER" headerInside="0" footerInside="0" fillArea="PAPER"><hp:offset left="1417" right="1417" top="1417" bottom="1417"/></hp:pageBorderFill></hp:secPr><hp:ctrl><hp:colPr id="" type="NEWSPAPER" layout="LEFT" colCount="1" sameSz="1" sameGap="0"/></hp:ctrl>`;

export function docToHwpx(doc, options = {}) {
  const warnings = [...(doc.warnings || [])];
  const st = new Styles();
  st.charId({ size: 10 }); st.paraId('justify'); // id 0 defaults
  const eqToScript = options.eqToScript || ((latex) => ({ script: latex, warnings: [] }));
  let ids = { pic: 0, tbl: 0, eq: 0, fn: 0, en: 0, inst: 2000000000 };
  const binItems = []; // {id, href, mediaType, data}
  const binByRef = new Map();
  const binFor = (ref) => {
    if (binByRef.has(ref)) return binByRef.get(ref);
    const img = doc.images.get(ref);
    if (!img) return null;
    const ext = (img.ext || 'png').toLowerCase().replace('jpeg', 'jpg');
    const id = `image${binItems.length + 1}`;
    const href = `BinData/${id}.${ext}`;
    const mt = { png: 'image/png', jpg: 'image/jpeg', gif: 'image/gif', bmp: 'image/bmp', svg: 'image/svg+xml', tif: 'image/tiff', tiff: 'image/tiff', wmf: 'image/x-wmf', emf: 'image/x-emf' }[ext] || 'application/octet-stream';
    const item = { id, href, mediaType: mt, data: img.data, ext };
    binItems.push(item); binByRef.set(ref, item);
    return item;
  };
  const preview = [];

  const tText = (text) => xe(text).replace(/\t/g, '<hp:tab width="8000" leader="0" type="0"/>').replace(/\n/g, '<hp:lineBreak/>');

  const runText = (text, style) => text ? `<hp:run charPrIDRef="${st.charId(style)}"><hp:t>${tText(text)}</hp:t></hp:run>` : '';

  const equationXml = (latexOrScript, display, isScript) => {
    const r = isScript ? { script: latexOrScript, warnings: [] } : eqToScript(latexOrScript);
    for (const w of r.warnings) warnings.push(`수식 "${latexOrScript.slice(0, 30)}": ${w}`);
    const script = r.script;
    const n = ++ids.eq;
    const len = script.replace(/[{}]/g, '').length;
    const width = Math.min(TEXT_W, Math.max(1500, len * 520));
    const depth = (script.match(/over|sum|int|prod|matrix|cases|pile|eqalign|#/g) || []).length;
    const height = Math.min(20000, 1450 + Math.min(depth, 6) * 900);
    return `<hp:equation id="${ids.inst + n}" zOrder="${n}" numberingType="EQUATION" textWrap="TOP_AND_BOTTOM" textFlow="BOTH_SIDES" lock="0" dropcapstyle="None" version="Equation Version 60" baseLine="${display ? 50 : 71}" textColor="#000000" baseUnit="1000" lineMode="CHAR" font="HancomEQN"><hp:sz width="${width}" widthRelTo="ABSOLUTE" height="${height}" heightRelTo="ABSOLUTE" protect="0"/><hp:pos treatAsChar="1" affectLSpacing="0" flowWithText="1" allowOverlap="0" holdAnchorAndSO="0" vertRelTo="PARA" horzRelTo="PARA" vertAlign="TOP" horzAlign="LEFT" vertOffset="0" horzOffset="0"/><hp:outMargin left="56" right="56" top="0" bottom="0"/><hp:shapeComment>수식입니다.</hp:shapeComment><hp:script>${xe(script)}</hp:script></hp:equation>`;
  };

  const picXml = (img, inline) => {
    const item = binFor(img.ref);
    if (!item) { warnings.push(`그림 ${img.ref} 데이터가 없어 건너뜁니다.`); return ''; }
    let w = Math.round((img.widthPt || 0) * 100), h = Math.round((img.heightPt || 0) * 100);
    const px = imageSize(item.data, item.ext);
    if ((!w || !h) && px) {
      const ratio = px.height / px.width;
      if (!w && !h) { w = Math.min(TEXT_W, Math.round(px.width * 75)); h = Math.round(w * ratio); }
      else if (!h) h = Math.round(w * ratio); else w = Math.round(h / ratio);
    }
    if (!w) w = Math.round(TEXT_W * 0.6); if (!h) h = Math.round(w * 0.75);
    if (w > TEXT_W) { h = Math.round(h * TEXT_W / w); w = TEXT_W; }
    const n = ++ids.pic;
    const id = ids.inst + 100000 + n;
    return `<hp:pic id="${id}" zOrder="${n}" numberingType="PICTURE" textWrap="TOP_AND_BOTTOM" textFlow="BOTH_SIDES" lock="0" dropcapstyle="None" href="" groupLevel="0" instid="${id}" reverse="0"><hp:offset x="0" y="0"/><hp:orgSz width="${w}" height="${h}"/><hp:curSz width="${w}" height="${h}"/><hp:flip horizontal="0" vertical="0"/><hp:rotationInfo angle="0" centerX="${Math.round(w / 2)}" centerY="${Math.round(h / 2)}" rotateimage="1"/><hp:renderingInfo><hc:transMatrix e1="1" e2="0" e3="0" e4="0" e5="1" e6="0"/><hc:scaMatrix e1="1" e2="0" e3="0" e4="0" e5="1" e6="0"/><hc:rotMatrix e1="1" e2="0" e3="0" e4="0" e5="1" e6="0"/></hp:renderingInfo><hp:imgRect><hc:pt0 x="0" y="0"/><hc:pt1 x="${w}" y="0"/><hc:pt2 x="${w}" y="${h}"/><hc:pt3 x="0" y="${h}"/></hp:imgRect><hp:imgClip left="0" right="${w}" top="0" bottom="${h}"/><hp:inMargin left="0" right="0" top="0" bottom="0"/><hp:imgDim dimwidth="${w}" dimheight="${h}"/><hc:img binaryItemIDRef="${item.id}" bright="0" contrast="0" effect="REAL_PIC" alpha="0"/><hp:effects/><hp:sz width="${w}" widthRelTo="ABSOLUTE" height="${h}" heightRelTo="ABSOLUTE" protect="0"/><hp:pos treatAsChar="1" affectLSpacing="0" flowWithText="1" allowOverlap="0" holdAnchorAndSO="0" vertRelTo="PARA" horzRelTo="PARA" vertAlign="TOP" horzAlign="LEFT" vertOffset="0" horzOffset="0"/><hp:outMargin left="0" right="0" top="0" bottom="0"/></hp:pic>`;
  };

  const subList = (blocks, vert = 'TOP') => `<hp:subList id="" textDirection="HORIZONTAL" lineWrap="BREAK" vertAlign="${vert}" linkListIDRef="0" linkListNextIDRef="0" textWidth="0" textHeight="0" hasTextRef="0" hasNumRef="0">${blocksXml(blocks.length ? blocks : [{ type: 'p', inlines: [] }], true)}</hp:subList>`;

  const noteXml = (note) => {
    const isEn = note.kind === 'en';
    const n = isEn ? ++ids.en : ++ids.fn;
    const tag = isEn ? 'endNote' : 'footNote';
    const body = note.blocks.length ? note.blocks : [{ type: 'p', inlines: [] }];
    // first paragraph gets the auto number control
    const first = body[0];
    const firstXml = first.type === 'p'
      ? `<hp:p id="0" paraPrIDRef="${st.paraId('justify')}" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="${st.charId({ size: 9 })}"><hp:ctrl><hp:autoNum num="${n}" numType="${isEn ? 'ENDNOTE' : 'FOOTNOTE'}"><hp:autoNumFormat type="DIGIT" userChar="" prefixChar="" suffixChar=")" supscript="0"/></hp:autoNum></hp:ctrl><hp:t> </hp:t></hp:run>${inlinesXml(first.inlines, { size: 9 }).runs}</hp:p>`
      : blocksXml([first], true);
    const rest = blocksXml(body.slice(1), true);
    return `<hp:ctrl><hp:${tag} number="${n}" suffixChar="41" instId="${ids.inst + 200000 + n}"><hp:subList id="" textDirection="HORIZONTAL" lineWrap="BREAK" vertAlign="TOP" linkListIDRef="0" linkListNextIDRef="0" textWidth="0" textHeight="0" hasTextRef="0" hasNumRef="0">${firstXml}${rest}</hp:subList></hp:${tag}></hp:ctrl>`;
  };

  const tableXml = (t) => {
    const rows = Math.max(1, t.rows), cols = Math.max(1, t.cols);
    const n = ++ids.tbl;
    const colW = Array(cols).fill(0);
    for (const c of t.cells) if (c.colspan === 1 && c.col < cols && c.width) colW[c.col] = Math.max(colW[c.col], c.width);
    let total = colW.reduce((a, b) => a + b, 0);
    if (!colW.every(w => w > 0) || total === 0) { const w = Math.floor(TEXT_W / cols); colW.fill(w); total = w * cols; }
    if (total > TEXT_W) { for (let i = 0; i < cols; i++) colW[i] = Math.round(colW[i] * TEXT_W / total); total = colW.reduce((a, b) => a + b, 0); }
    // group cells by row
    const byRow = Array.from({ length: rows }, () => []);
    for (const c of t.cells) if (c.row < rows) byRow[c.row].push(c);
    const rowH = Array(rows).fill(1400);
    for (const c of t.cells) if (c.rowspan === 1 && c.row < rows && c.height) rowH[c.row] = Math.max(rowH[c.row], c.height);
    const trs = byRow.map((cells, r) => `<hp:tr>${cells.sort((a, b) => a.col - b.col).map(c => {
      const w = colW.slice(c.col, c.col + c.colspan).reduce((a, b) => a + b, 0);
      const h = rowH.slice(c.row, c.row + c.rowspan).reduce((a, b) => a + b, 0);
      return `<hp:tc name="" header="0" hasMargin="0" protect="0" editable="0" dirty="0" borderFillIDRef="2">${subList(c.blocks, 'CENTER')}<hp:cellAddr colAddr="${c.col}" rowAddr="${c.row}"/><hp:cellSpan colSpan="${c.colspan}" rowSpan="${c.rowspan}"/><hp:cellSz width="${w}" height="${h}"/><hp:cellMargin left="510" right="510" top="141" bottom="141"/></hp:tc>`;
    }).join('')}</hp:tr>`).join('');
    const totalH = rowH.reduce((a, b) => a + b, 0);
    return `<hp:tbl id="${ids.inst + 300000 + n}" zOrder="${n}" numberingType="TABLE" textWrap="TOP_AND_BOTTOM" textFlow="BOTH_SIDES" lock="0" dropcapstyle="None" pageBreak="CELL" repeatHeader="1" rowCnt="${rows}" colCnt="${cols}" cellSpacing="0" borderFillIDRef="2" noAdjust="0"><hp:sz width="${total}" widthRelTo="ABSOLUTE" height="${totalH}" heightRelTo="ABSOLUTE" protect="0"/><hp:pos treatAsChar="1" affectLSpacing="0" flowWithText="1" allowOverlap="0" holdAnchorAndSO="0" vertRelTo="PARA" horzRelTo="PARA" vertAlign="TOP" horzAlign="LEFT" vertOffset="0" horzOffset="0"/><hp:outMargin left="283" right="283" top="283" bottom="283"/><hp:inMargin left="510" right="510" top="141" bottom="141"/>${trs}</hp:tbl>`;
  };

  // inline list -> runs; returns {runs, after} (after: block xml to append as separate paragraphs)
  const inlinesXml = (inlines, baseStyle = {}) => {
    let runs = '';
    const after = [];
    let buf = '', bufStyle = null;
    const flush = () => { if (buf) runs += runText(buf, { ...baseStyle, ...bufStyle }); buf = ''; bufStyle = null; };
    const same = (a, b) => a && b && ['bold', 'italic', 'underline', 'sup', 'sub', 'size', 'font'].every(k => (a[k] || (k === 'size' ? 10 : false)) === (b[k] || (k === 'size' ? 10 : false)));
    for (const il of inlines) {
      switch (il.type) {
        case 'text': { const stl = { bold: il.bold, italic: il.italic, underline: il.underline, sup: il.sup, sub: il.sub, size: il.size, font: il.font }; if (bufStyle && !same(stl, bufStyle)) flush(); if (!bufStyle) bufStyle = stl; buf += il.text; preview.push(il.text); break; }
        case 'tab': buf += '\t'; break;
        case 'br': buf += '\n'; break;
        case 'eq': flush(); runs += `<hp:run charPrIDRef="${st.charId(baseStyle)}">${equationXml(il.latex ?? il.script, false, il.latex === undefined)}</hp:run>`; break;
        case 'note': flush(); runs += `<hp:run charPrIDRef="${st.charId(baseStyle)}">${noteXml(il)}</hp:run>`; break;
        case 'image': flush(); runs += `<hp:run charPrIDRef="${st.charId(baseStyle)}">${picXml(il, true)}</hp:run>`; break;
        case 'table': flush(); runs += `<hp:run charPrIDRef="${st.charId(baseStyle)}">${tableXml(il)}</hp:run>`; break;
        case 'textbox': after.push(...il.blocks); break;
        case 'shape': flush(); buf += `[${il.desc || '그림'}]`; break;
        default: break;
      }
    }
    flush();
    return { runs, after };
  };

  const paraXml = (p, nested) => {
    const align = p.align || 'justify';
    const ppr = st.paraId(align, { left: (p.level || 0) * 1500 });
    const { runs, after } = inlinesXml(p.inlines, {});
    const body = runs || `<hp:run charPrIDRef="${st.charId({})}"><hp:t></hp:t></hp:run>`;
    preview.push('\n');
    return `<hp:p id="0" paraPrIDRef="${ppr}" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">${body}</hp:p>` + (after.length ? blocksXml(after, nested) : '');
  };

  const blocksXml = (blocks, nested = false) => blocks.map(b => {
    switch (b.type) {
      case 'p': return paraXml(b, nested);
      case 'display': { // display equation paragraph
        return `<hp:p id="0" paraPrIDRef="${st.paraId('center')}" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="${st.charId({})}">${equationXml(b.latex ?? b.script, true, b.latex === undefined)}</hp:run></hp:p>`;
      }
      case 'table': return `<hp:p id="0" paraPrIDRef="${st.paraId('center')}" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="${st.charId({})}">${tableXml(b)}</hp:run></hp:p>` + (b.caption ? blocksXml(b.caption.map(c => ({ ...c, align: 'center' })), nested) : '');
      case 'image': return `<hp:p id="0" paraPrIDRef="${st.paraId('center')}" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="${st.charId({})}">${picXml(b, false)}</hp:run></hp:p>` + (b.caption ? blocksXml(b.caption.map(c => ({ ...c, align: 'center' })), nested) : '');
      case 'textbox': return blocksXml(b.blocks, nested);
      case 'shape': return paraXml({ type: 'p', inlines: [{ type: 'text', text: `[${b.desc || '그림'} — 직접 삽입]`, italic: true }], align: 'center' }, nested);
      case 'heading': return paraXml({ type: 'p', inlines: b.inlines.map(i => i.type === 'text' ? { ...i, bold: true, size: b.level === 1 ? 16 : b.level === 2 ? 14 : 12 } : i), align: 'left' }, nested);
      default: return '';
    }
  }).join('');

  let body = blocksXml(doc.blocks);
  // the first paragraph must carry secPr + colPr
  const firstRunIdx = body.indexOf('<hp:run ');
  if (firstRunIdx >= 0) {
    const insertAt = body.indexOf('>', firstRunIdx) + 1;
    body = body.slice(0, insertAt) + SECPR + body.slice(insertAt);
  } else {
    body = `<hp:p id="0" paraPrIDRef="0" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="0">${SECPR}<hp:t></hp:t></hp:run></hp:p>` + body;
  }
  const sectionXml = XMLH + `<hs:sec ${NS_SEC}>${body}</hs:sec>`;
  const header = headerXml(st);

  const manifestItems = [`<opf:item id="header" href="Contents/header.xml" media-type="application/xml"/>`, `<opf:item id="section0" href="Contents/section0.xml" media-type="application/xml"/>`, `<opf:item id="settings" href="settings.xml" media-type="application/xml"/>`]
    .concat(binItems.map(b => `<opf:item id="${b.id}" href="${b.href}" media-type="${b.mediaType}" isEmbeded="1"/>`));
  const hpf = XMLH + `<opf:package xmlns:opf="http://www.idpf.org/2007/opf/" xmlns:hpf="http://www.hancom.co.kr/schema/2011/hpf" xmlns:dc="http://purl.org/dc/elements/1.1/" version="" unique-identifier="" id=""><opf:metadata><opf:title>${xe(options.title || '')}</opf:title><opf:language>ko</opf:language><opf:meta name="creator" content="text">hwp2tex</opf:meta><opf:meta name="CreatedDate" content="text">${new Date().toISOString()}</opf:meta><opf:meta name="ModifiedDate" content="text">${new Date().toISOString()}</opf:meta></opf:metadata><opf:manifest>${manifestItems.join('')}</opf:manifest><opf:spine><opf:itemref idref="header" linear="yes"/><opf:itemref idref="section0" linear="yes"/></opf:spine></opf:package>`;
  const container = XMLH + `<ocf:container xmlns:ocf="urn:oasis:names:tc:opendocument:xmlns:container" xmlns:hpf="http://www.hancom.co.kr/schema/2011/hpf"><ocf:rootfiles><ocf:rootfile full-path="Contents/content.hpf" media-type="application/hwpml-package+xml"/></ocf:rootfiles></ocf:container>`;
  const version = XMLH + `<hv:HCFVersion xmlns:hv="http://www.hancom.co.kr/hwpml/2011/version" tagetApplication="WORDPROCESSOR" major="5" minor="1" micro="0" buildNumber="1" os="1" xmlVersion="1.2" application="Hancom Office Hangul" appVersion="11, 0, 0, 3524 WIN32LEWindows_8"/>`;
  const settings = XMLH + `<ha:HWPApplicationSetting xmlns:ha="http://www.hancom.co.kr/hwpml/2011/app" xmlns:config="urn:oasis:names:tc:opendocument:xmlns:config:1.0"><ha:CaretPosition listIDRef="0" paraIDRef="0" pos="0"/></ha:HWPApplicationSetting>`;
  const manifest = XMLH + `<odf:manifest xmlns:odf="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0"/>`;
  const enc = (s) => new TextEncoder().encode(s);
  const entries = {
    'mimetype': [enc('application/hwp+zip'), { level: 0 }],
    'version.xml': enc(version),
    'META-INF/container.xml': enc(container),
    'META-INF/manifest.xml': enc(manifest),
    'Contents/content.hpf': enc(hpf),
    'Contents/header.xml': enc(header),
    'Contents/section0.xml': enc(sectionXml),
    'settings.xml': enc(settings),
    'Preview/PrvText.txt': enc(preview.join('').slice(0, 2000)),
  };
  for (const b of binItems) entries[b.href] = [b.data, { level: 0 }];
  const zip = zipSync(entries, { level: 6 });
  return { hwpx: zip, warnings, sectionXml, header };
}
