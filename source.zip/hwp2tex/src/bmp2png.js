// Pure-JS BMP -> PNG (uncompressed BMP: 1/4/8-bit palette, 16/24/32-bit, BITFIELDS). Returns null when unsupported.
import { zlibSync } from 'fflate';

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
  return t;
})();
function crc32(buf) { let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }

function chunk(type, data) {
  const out = new Uint8Array(8 + data.length + 4);
  const dv = new DataView(out.buffer);
  dv.setUint32(0, data.length);
  out.set([type.charCodeAt(0), type.charCodeAt(1), type.charCodeAt(2), type.charCodeAt(3)], 4);
  out.set(data, 8);
  const crcBuf = out.subarray(4, 8 + data.length);
  dv.setUint32(8 + data.length, crc32(crcBuf));
  return out;
}

export function encodePNG(width, height, rgba) {
  const raw = new Uint8Array((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (width * 4 + 1)] = 0;
    raw.set(rgba.subarray(y * width * 4, (y + 1) * width * 4), y * (width * 4 + 1) + 1);
  }
  const ihdr = new Uint8Array(13);
  const dv = new DataView(ihdr.buffer);
  dv.setUint32(0, width); dv.setUint32(4, height);
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const sig = new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]);
  const parts = [sig, chunk('IHDR', ihdr), chunk('IDAT', zlibSync(raw, { level: 6 })), chunk('IEND', new Uint8Array(0))];
  let len = 0; for (const p of parts) len += p.length;
  const out = new Uint8Array(len); let o = 0; for (const p of parts) { out.set(p, o); o += p.length; }
  return out;
}

export function decodeBMP(bytes) {
  if (bytes.length < 54 || bytes[0] !== 0x42 || bytes[1] !== 0x4d) return null;
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const dataOffset = dv.getUint32(10, true);
  const hdrSize = dv.getUint32(14, true);
  let width, height, bpp, compression = 0, colorsUsed = 0;
  if (hdrSize === 12) { width = dv.getUint16(18, true); height = dv.getInt16(20, true); bpp = dv.getUint16(24, true); }
  else { width = dv.getInt32(18, true); height = dv.getInt32(22, true); bpp = dv.getUint16(28, true); compression = dv.getUint32(30, true); colorsUsed = dv.getUint32(46, true); }
  if (compression !== 0 && compression !== 3) return null; // RLE etc unsupported
  const topDown = height < 0; height = Math.abs(height);
  if (width <= 0 || height <= 0 || width * height > 80_000_000) return null;
  let rMask = 0x00ff0000, gMask = 0x0000ff00, bMask = 0x000000ff, aMask = 0;
  if (compression === 3) { rMask = dv.getUint32(54, true); gMask = dv.getUint32(58, true); bMask = dv.getUint32(62, true); if (hdrSize >= 56) aMask = dv.getUint32(66, true); }
  const palette = [];
  if (bpp <= 8) {
    const n = colorsUsed || (1 << bpp);
    const pOff = 14 + hdrSize;
    const entry = hdrSize === 12 ? 3 : 4;
    for (let i = 0; i < n; i++) { const o = pOff + i * entry; if (o + 3 > bytes.length) break; palette.push([bytes[o + 2], bytes[o + 1], bytes[o]]); }
  }
  const rowSize = Math.floor((bpp * width + 31) / 32) * 4;
  const rgba = new Uint8Array(width * height * 4);
  const shiftOf = (m) => { if (!m) return [0, 0]; let s = 0; while (!((m >>> s) & 1)) s++; let bits = 0; while ((m >>> (s + bits)) & 1) bits++; return [s, bits]; };
  const [rs, rb] = shiftOf(rMask), [gs, gb] = shiftOf(gMask), [bs, bb] = shiftOf(bMask), [as_, ab] = shiftOf(aMask);
  const scale = (v, bits) => bits === 8 ? v : bits === 0 ? 0 : Math.round(v * 255 / ((1 << bits) - 1));
  for (let y = 0; y < height; y++) {
    const srcY = topDown ? y : height - 1 - y;
    const rowOff = dataOffset + srcY * rowSize;
    if (rowOff + rowSize > bytes.length + rowSize) break;
    for (let x = 0; x < width; x++) {
      let r = 0, g = 0, b = 0, a = 255;
      if (bpp === 24) { const o = rowOff + x * 3; if (o + 2 >= bytes.length) continue; b = bytes[o]; g = bytes[o + 1]; r = bytes[o + 2]; }
      else if (bpp === 32) {
        const o = rowOff + x * 4; if (o + 3 >= bytes.length) continue;
        const v = dv.getUint32(o, true);
        if (compression === 3) { r = scale((v & rMask) >>> rs, rb); g = scale((v & gMask) >>> gs, gb); b = scale((v & bMask) >>> bs, bb); a = aMask ? scale((v & aMask) >>> as_, ab) : 255; }
        else { b = bytes[o]; g = bytes[o + 1]; r = bytes[o + 2]; }
      }
      else if (bpp === 16) {
        const o = rowOff + x * 2; if (o + 1 >= bytes.length) continue;
        const v = dv.getUint16(o, true);
        if (compression === 3) { r = scale((v & rMask) >>> rs, rb); g = scale((v & gMask) >>> gs, gb); b = scale((v & bMask) >>> bs, bb); }
        else { r = scale((v >> 10) & 31, 5); g = scale((v >> 5) & 31, 5); b = scale(v & 31, 5); }
      }
      else if (bpp === 8) { const o = rowOff + x; const p = palette[bytes[o]] || [0, 0, 0]; [r, g, b] = p; }
      else if (bpp === 4) { const o = rowOff + (x >> 1); const idx = x & 1 ? bytes[o] & 15 : bytes[o] >> 4; const p = palette[idx] || [0, 0, 0]; [r, g, b] = p; }
      else if (bpp === 1) { const o = rowOff + (x >> 3); const idx = (bytes[o] >> (7 - (x & 7))) & 1; const p = palette[idx] || [0, 0, 0]; [r, g, b] = p; }
      else return null;
      const d = (y * width + x) * 4;
      rgba[d] = r; rgba[d + 1] = g; rgba[d + 2] = b; rgba[d + 3] = a;
    }
  }
  return { width, height, rgba };
}

export function bmpToPng(bytes) {
  const img = decodeBMP(bytes);
  if (!img) return null;
  return encodePNG(img.width, img.height, img.rgba);
}
