// HWP 5.x (binary, OLE) -> document model
import { parseCFB } from './cfb.js';
import { inflateSync } from 'fflate';

const TAG = {
  BIN_DATA: 0x12, CHAR_SHAPE: 0x15, NUMBERING: 0x17, BULLET: 0x18, PARA_SHAPE: 0x19,
  PARA_HEADER: 0x42, PARA_TEXT: 0x43, PARA_CHAR_SHAPE: 0x44, CTRL_HEADER: 0x47,
  LIST_HEADER: 0x48, SHAPE_COMPONENT: 0x4c, TABLE: 0x4d, SHAPE_PICTURE: 0x55,
  SHAPE_CONTAINER: 0x56, EQEDIT: 0x58,
};

const cid = (s) => ((s.charCodeAt(0) << 24) | (s.charCodeAt(1) << 16) | (s.charCodeAt(2) << 8) | s.charCodeAt(3)) >>> 0;
const CTRL = {
  TBL: cid('tbl '), GSO: cid('gso '), EQED: cid('eqed'), FN: cid('fn  '), EN: cid('en  '),
  HEAD: cid('head'), FOOT: cid('foot'), SECD: cid('secd'), COLD: cid('cold'), ATNO: cid('atno'),
};
const ctrlName = (id) => String.fromCharCode((id >>> 24) & 255, (id >>> 16) & 255, (id >>> 8) & 255, id & 255);

function u16(d, o) { return d[o] | (d[o + 1] << 8); }
function u32(d, o) { return (d[o] | (d[o + 1] << 8) | (d[o + 2] << 16) | (d[o + 3] << 24)) >>> 0; }
function i32(d, o) { return u32(d, o) | 0; }
function utf16(d, start, end) {
  let s = '';
  for (let i = start; i + 1 < end; i += 2) s += String.fromCharCode(u16(d, i));
  return s;
}
function hwpString(d, o) {
  if (o + 2 > d.length) return { value: '', next: d.length };
  const n = u16(d, o);
  const end = o + 2 + n * 2;
  if (end > d.length) return { value: '', next: d.length };
  return { value: utf16(d, o + 2, end), next: end };
}

function readRecords(d) {
  const recs = [];
  let o = 0;
  while (o + 4 <= d.length) {
    const h = u32(d, o); o += 4;
    const tagId = h & 0x3ff, level = (h >>> 10) & 0x3ff;
    let size = (h >>> 20) & 0xfff;
    if (size === 0xfff) { if (o + 4 > d.length) break; size = u32(d, o); o += 4; }
    if (o + size > d.length) break;
    recs.push({ tagId, level, data: d.subarray(o, o + size) });
    o += size;
  }
  return recs;
}

function inflate(bytes) {
  try { return inflateSync(bytes); } catch (e) { /* maybe not compressed */ }
  return bytes;
}

// ---- DocInfo ----
function parseDocInfo(recs) {
  const binData = [], charShapes = [], paraShapes = [], numberings = [], bullets = [];
  for (const r of recs) {
    const d = r.data;
    if (r.tagId === TAG.BIN_DATA && d.length >= 2) {
      const attr = u16(d, 0);
      const type = attr & 0xf;
      if (type === 0) {
        binData.push({ kind: 'link' });
      } else {
        const storageId = u16(d, 2);
        const { value: ext } = hwpString(d, 4);
        binData.push({ kind: type === 2 ? 'storage' : 'embed', storageId, ext, compress: (attr >> 4) & 3 });
      }
    } else if (r.tagId === TAG.CHAR_SHAPE) {
      const attr = d.length >= 50 ? u32(d, 46) : 0;
      charShapes.push({
        size: d.length >= 46 ? u32(d, 42) / 100 : 10,
        italic: !!(attr & 1), bold: !!(attr & 2),
        underline: ((attr >> 2) & 3) === 1,
        sup: !!(attr & (1 << 15)), sub: !!(attr & (1 << 16)),
        strike: ((attr >> 18) & 7) !== 0,
      });
    } else if (r.tagId === TAG.PARA_SHAPE && d.length >= 4) {
      const a1 = u32(d, 0);
      const alignCode = (a1 >>> 2) & 7;
      const align = ['justify', 'left', 'right', 'center', 'distribute', 'distribute'][alignCode] || 'justify';
      paraShapes.push({ align, headType: (a1 >>> 23) & 3, level: (a1 >>> 25) & 7, numberingId: d.length >= 32 ? u16(d, 30) : 0 });
    } else if (r.tagId === TAG.NUMBERING && d.length >= 14) {
      const formats = [], codes = [], starts = [1, 1, 1, 1, 1, 1, 1];
      let o = 0;
      for (let lv = 0; lv < 7; lv++) {
        if (o + 12 > d.length) { formats.push(''); codes.push(0); continue; }
        const attr = u32(d, o); codes.push((attr >>> 5) & 0xff); o += 12;
        const { value, next } = hwpString(d, o); formats.push(value); o = next;
      }
      let base = 1;
      if (o + 2 <= d.length) { base = u16(d, o) || 1; o += 2; }
      for (let lv = 0; lv < 7; lv++) { if (o + 4 <= d.length) { starts[lv] = u32(d, o) || 1; o += 4; } else starts[lv] = base; }
      numberings.push({ formats, codes, starts });
    } else if (r.tagId === TAG.BULLET && d.length >= 14) {
      const code = u16(d, 12);
      bullets.push(code > 0 ? String.fromCharCode(code) : '•');
    }
  }
  return { binData, charShapes, paraShapes, numberings, bullets };
}

// ---- Body ----
const EXTENDED = new Set([1, 2, 3, 11, 12, 14, 15, 16, 17, 18, 21, 22, 23]);
const INLINE = new Set([4, 5, 6, 7, 8, 9, 19, 20]);

const CIRCLED = '①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳';
const HANGUL_GA = '가나다라마바사아자차카타파하';
const HANGUL_JAMO = 'ㄱㄴㄷㄹㅁㅂㅅㅇㅈㅊㅋㅌㅍㅎ';
const HANGUL_IL = ['일', '이', '삼', '사', '오', '육', '칠', '팔', '구', '십'];
const IDEO = '一二三四五六七八九十';
function roman(n) { const v = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1], sy = ['M', 'CM', 'D', 'CD', 'C', 'XC', 'L', 'XL', 'X', 'IX', 'V', 'IV', 'I']; let s = ''; for (let i = 0; i < v.length; i++) while (n >= v[i]) { s += sy[i]; n -= v[i]; } return s; }
export function formatNumber(n, code) {
  const idx = n - 1;
  switch (code) {
    case 1: return CIRCLED[idx] || String(n);
    case 2: return roman(n);
    case 3: return roman(n).toLowerCase();
    case 4: return String.fromCharCode(65 + (idx % 26));
    case 5: return String.fromCharCode(97 + (idx % 26));
    case 6: return String.fromCharCode(0x24b6 + (idx % 26));
    case 7: return String.fromCharCode(0x24d0 + (idx % 26));
    case 8: return HANGUL_GA[idx % 14];
    case 9: return String.fromCharCode(0x326e + (idx % 14));
    case 10: return HANGUL_JAMO[idx % 14];
    case 11: return String.fromCharCode(0x3260 + (idx % 14));
    case 12: return n <= 10 ? HANGUL_IL[idx] : String(n);
    case 13: return n <= 10 ? IDEO[idx] : String(n);
    case 14: return String.fromCharCode(0x3280 + (idx % 10));
    default: return String(n);
  }
}

class Hwp5Parser {
  constructor(docInfo, ctx) { this.di = docInfo; this.ctx = ctx; this.counters = new Map(); this.outlineId = 0; }

  // returns the paragraph-head text ("1. ", "(가) ", "• ") for a numbered/bulleted paragraph
  headText(ps) {
    if (!ps || !ps.headType) return '';
    if (ps.headType === 3) return (this.di.bullets[ps.numberingId - 1] || '•') + ' ';
    const numId = ps.headType === 1 ? this.outlineId : ps.numberingId;
    const num = this.di.numberings[numId - 1];
    if (!num) return '';
    const lv = Math.min(ps.level, 6);
    const key = numId;
    let c = this.counters.get(key);
    if (!c) { c = num.starts.map(x => x - 1); this.counters.set(key, c); }
    c[lv]++;
    for (let k = lv + 1; k < 7; k++) c[k] = num.starts[k] - 1;
    const fmt = num.formats[lv] || '^' + (lv + 1) + '.';
    const text = fmt.replace(/\^([1-7])/g, (m, d) => formatNumber(Math.max(1, c[d - 1]), num.codes[d - 1] || 0));
    return text + ' ';
  }

  // Parse all paragraphs in records[s,e) whose level is the minimum level found there
  parseParagraphList(recs, s, e, depth = 0) {
    const blocks = [];
    if (depth > 12) return blocks;
    let minLevel = Infinity;
    for (let i = s; i < e; i++) if (recs[i].tagId === TAG.PARA_HEADER && recs[i].level < minLevel) minLevel = recs[i].level;
    if (minLevel === Infinity) return blocks;
    let i = s;
    while (i < e) {
      if (recs[i].tagId === TAG.PARA_HEADER && recs[i].level === minLevel) {
        let j = i + 1;
        while (j < e && !(recs[j].tagId === TAG.PARA_HEADER && recs[j].level === minLevel)) j++;
        blocks.push(...this.parseParagraph(recs, i, j, depth));
        i = j;
      } else i++;
    }
    return blocks;
  }

  parseParagraph(recs, s, e, depth) {
    const header = recs[s];
    const L = header.level;
    const paraShapeId = header.data.length >= 10 ? u16(header.data, 8) : -1;
    const ps = this.di.paraShapes[paraShapeId];
    const head = this.headText(ps);
    const textChunks = [];
    const charRuns = []; // [pos, shapeId]
    const ctrls = [];
    let i = s + 1;
    while (i < e) {
      const r = recs[i];
      if (r.tagId === TAG.CTRL_HEADER && r.level === L + 1 && r.data.length >= 4) {
        let j = i + 1;
        while (j < e && recs[j].level > L + 1) j++;
        ctrls.push({ id: u32(r.data, 0), data: r.data, cs: i + 1, ce: j });
        i = j; continue;
      }
      if (r.tagId === TAG.PARA_TEXT && r.level === L + 1) textChunks.push(r.data);
      else if (r.tagId === TAG.PARA_CHAR_SHAPE && r.level === L + 1) {
        for (let o = 0; o + 8 <= r.data.length; o += 8) charRuns.push([u32(r.data, o), u32(r.data, o + 4)]);
      }
      i++;
    }
    // concatenate text
    let total = 0; for (const c of textChunks) total += c.length;
    const text = new Uint8Array(total); { let p = 0; for (const c of textChunks) { text.set(c, p); p += c.length; } }

    const inlines = [];
    const after = []; // blocks to place after the paragraph (floating objects)
    let ctrlIdx = 0;
    let wpos = 0; // WCHAR position for char shape lookup
    let runIdx = 0;
    const styleAt = (pos) => {
      while (runIdx + 1 < charRuns.length && charRuns[runIdx + 1][0] <= pos) runIdx++;
      if (runIdx > 0 && charRuns[runIdx][0] > pos) { runIdx = 0; while (runIdx + 1 < charRuns.length && charRuns[runIdx + 1][0] <= pos) runIdx++; }
      const id = charRuns.length ? charRuns[runIdx][1] : -1;
      return this.di.charShapes[id] || {};
    };
    let buf = '';
    let bufStyle = null;
    const sameStyle = (a, b) => a && b && a.bold === b.bold && a.italic === b.italic && a.underline === b.underline && a.sup === b.sup && a.sub === b.sub;
    const flush = () => {
      if (buf) inlines.push({ type: 'text', text: buf, ...pick(bufStyle) });
      buf = ''; bufStyle = null;
    };
    const pick = (st) => ({ bold: !!st?.bold, italic: !!st?.italic, underline: !!st?.underline, sup: !!st?.sup, sub: !!st?.sub, size: st?.size || 10 });
    const pushChar = (ch, pos) => {
      const st = styleAt(pos);
      if (bufStyle && !sameStyle(st, bufStyle)) flush();
      if (!bufStyle) bufStyle = st;
      buf += ch;
    };

    const handleCtrl = (ctrl) => {
      if (!ctrl) return;
      const id = ctrl.id;
      switch (id) {
        case CTRL.EQED: {
          for (let k = ctrl.cs; k < ctrl.ce; k++) if (recs[k].tagId === TAG.EQEDIT) {
            const d = recs[k].data;
            if (d.length >= 6) {
              const n = u16(d, 4);
              const script = utf16(d, 6, Math.min(d.length, 6 + n * 2)).replace(/\0+/g, '').trim();
              flush();
              inlines.push({ type: 'eq', script });
            }
            break;
          }
          break;
        }
        case CTRL.FN: case CTRL.EN: {
          flush();
          const blocks = this.parseListContent(recs, ctrl.cs, ctrl.ce, depth + 1);
          inlines.push({ type: 'note', kind: id === CTRL.FN ? 'fn' : 'en', blocks });
          break;
        }
        case CTRL.TBL: {
          flush();
          const tbl = this.parseTable(ctrl, recs, depth + 1);
          if (tbl) { const inlineObj = !!(u32(ctrl.data, 4) & 1); if (inlineObj) inlines.push(tbl); else after.push(tbl); }
          break;
        }
        case CTRL.GSO: {
          flush();
          const objs = this.parseGso(ctrl, recs, depth + 1);
          const inlineObj = !!(u32(ctrl.data, 4) & 1);
          for (const ob of objs) { if (inlineObj || ob.type === 'p') inlines.push(ob); else after.push(ob); }
          break;
        }
        case CTRL.SECD:
          if (ctrl.data.length >= 20) this.outlineId = u16(ctrl.data, 18);
          break;
        default:
          break; // cold, head, foot, atno, nwno, pgnp, bokm, fields ... ignored
      }
    };

    for (let o = 0; o + 2 <= text.length; o += 2) {
      const ch = u16(text, o);
      const pos = o / 2;
      if (ch >= 0x20) {
        if (ch >= 0xd800 && ch <= 0xdbff && o + 4 <= text.length) {
          const lo = u16(text, o + 2);
          if (lo >= 0xdc00 && lo <= 0xdfff) { pushChar(String.fromCharCode(ch, lo), pos); o += 2; continue; }
        }
        pushChar(String.fromCharCode(ch), pos);
        continue;
      }
      if (EXTENDED.has(ch)) {
        const ctrl = ctrls[ctrlIdx++];
        handleCtrl(ctrl);
        o += 14; continue;
      }
      if (INLINE.has(ch)) {
        if (ch === 9) { flush(); inlines.push({ type: 'tab' }); }
        o += 14; continue;
      }
      switch (ch) {
        case 10: flush(); inlines.push({ type: 'br' }); break;
        case 13: break;
        case 30: pushChar(' ', pos); break;
        case 31: pushChar(' ', pos); break;
        default: break;
      }
    }
    flush();
    // controls not anchored by a control char (defensive)
    while (ctrlIdx < ctrls.length) handleCtrl(ctrls[ctrlIdx++]);

    const out = [];
    if (head) inlines.unshift({ type: 'text', text: head, bold: false, italic: false, underline: false, sup: false, sub: false });
    const para = { type: 'p', inlines, align: ps?.align || 'justify', headType: ps?.headType || 0, level: ps?.level || 0 };
    out.push(para);
    out.push(...after);
    return out;
  }

  // paragraphs following the first LIST_HEADER in [s,e)
  parseListContent(recs, s, e, depth) {
    for (let i = s; i < e; i++) if (recs[i].tagId === TAG.LIST_HEADER) return this.parseParagraphList(recs, i + 1, e, depth);
    return [];
  }

  parseTable(ctrl, recs, depth) {
    const { cs, ce } = ctrl;
    let tIdx = -1;
    for (let i = cs; i < ce; i++) if (recs[i].tagId === TAG.TABLE) { tIdx = i; break; }
    if (tIdx < 0) return null;
    const td = recs[tIdx].data;
    const rows = u16(td, 4), cols = u16(td, 6);
    // caption: LIST_HEADER before TABLE
    let caption = null;
    for (let i = cs; i < tIdx; i++) if (recs[i].tagId === TAG.LIST_HEADER) { caption = this.parseParagraphList(recs, i + 1, tIdx, depth); break; }
    const cells = [];
    let i = tIdx + 1;
    while (i < ce) {
      const r = recs[i];
      if (r.tagId === TAG.LIST_HEADER && r.level === recs[tIdx].level) {
        const d = r.data;
        const cell = {
          col: u16(d, 8), row: u16(d, 10), colspan: u16(d, 12) || 1, rowspan: u16(d, 14) || 1,
          width: u32(d, 16), height: u32(d, 20), blocks: [],
        };
        let j = i + 1;
        while (j < ce && !(recs[j].level <= r.level && (recs[j].tagId === TAG.LIST_HEADER || recs[j].tagId === TAG.TABLE))) {
          if (recs[j].level < r.level) break;
          j++;
        }
        cell.blocks = this.parseParagraphList(recs, i + 1, j, depth);
        cells.push(cell);
        i = j; continue;
      }
      i++;
    }
    return { type: 'table', rows, cols, cells, caption, widthHU: u32(ctrl.data, 16) };
  }

  parseGso(ctrl, recs, depth) {
    const { cs, ce } = ctrl;
    const out = [];
    const widthPt = u32(ctrl.data, 16) / 100, heightPt = u32(ctrl.data, 20) / 100; // HWPUNIT(1/7200in) -> pt (1/72in)
    const behind = ((u32(ctrl.data, 4) >>> 21) & 7) === 2; // text wrap: BEHIND_TEXT
    let scIdx = -1;
    for (let i = cs; i < ce; i++) if (recs[i].tagId === TAG.SHAPE_COMPONENT || recs[i].tagId === TAG.SHAPE_CONTAINER) { scIdx = i; break; }
    // caption before shape component
    let caption = null;
    if (scIdx > cs) for (let i = cs; i < scIdx; i++) if (recs[i].tagId === TAG.LIST_HEADER) { caption = this.parseParagraphList(recs, i + 1, scIdx, depth); break; }
    const scanStart = scIdx >= 0 ? scIdx + 1 : cs;
    let textList = -1;
    for (let i = scanStart; i < ce; i++) if (recs[i].tagId === TAG.LIST_HEADER) { textList = i; break; }
    const picEnd = textList >= 0 ? textList : ce;
    let found = false;
    const kinds = new Set();
    for (let i = scanStart; i < picEnd; i++) {
      const r = recs[i];
      if (r.tagId === TAG.SHAPE_PICTURE && r.data.length >= 73) {
        const binId = u16(r.data, 71);
        const ref = this.ctx.imageRef(binId);
        if (ref) { out.push({ type: 'image', ref, widthPt, heightPt, caption, behind }); found = true; }
      } else if (r.tagId >= 0x4e && r.tagId <= 0x53) kinds.add(['선', '사각형', '타원', '호', '다각형', '곡선'][r.tagId - 0x4e]);
    }
    if (textList >= 0) {
      const blocks = this.parseParagraphList(recs, textList + 1, ce, depth);
      if (blocks.some(b => b.type !== 'p' || b.inlines.length)) out.push({ type: 'textbox', blocks, widthPt, heightPt });
      found = found || blocks.length > 0;
    }
    if (!found && kinds.size) {
      this.ctx.warnings.push(`그리기 개체(${[...kinds].join('/')})는 이미지로 변환되지 않습니다 — 그림으로 직접 삽입이 필요합니다.`);
      out.push({ type: 'shape', desc: [...kinds].join('/'), widthPt, heightPt });
    }
    return out;
  }
}

export function parseHwp5(bytes) {
  const cfb = parseCFB(bytes);
  const fh = cfb.read('FileHeader');
  if (!fh || new TextDecoder().decode(fh.subarray(0, 17)) !== 'HWP Document File') throw new Error('HWP 5.0 파일 헤더를 찾을 수 없습니다');
  const flags = u32(fh, 36);
  if (flags & 2) throw new Error('암호가 걸린 문서는 변환할 수 없습니다. 한글에서 암호를 해제한 뒤 다시 시도하세요.');
  if (flags & 4) throw new Error('배포용 문서는 변환할 수 없습니다. 원본 문서를 사용하세요.');
  const compressed = !!(flags & 1);
  const warnings = [];
  const docInfoRaw = cfb.read('DocInfo');
  const di = parseDocInfo(readRecords(compressed ? inflate(docInfoRaw) : docInfoRaw));

  const images = new Map();
  const ctx = {
    warnings,
    imageRef: (binId) => {
      const item = di.binData[binId - 1];
      if (!item || item.kind === 'link') { warnings.push(`외부 연결 그림(#${binId})은 파일 안에 없어 건너뜁니다.`); return null; }
      const key = `bin${binId}`;
      if (images.has(key)) return key;
      const hex = item.storageId.toString(16).toUpperCase().padStart(4, '0');
      const want = `BinData/BIN${hex}.${item.ext}`.toLowerCase();
      let path = null;
      for (const p of cfb.list()) if (p.toLowerCase() === want) { path = p; break; }
      if (!path) { warnings.push(`그림 데이터 ${want} 를 찾지 못했습니다.`); return null; }
      let data = cfb.read(path);
      const comp = item.compress === 1 || (item.compress === 0 && compressed);
      if (comp) data = inflate(data);
      images.set(key, { ext: (item.ext || 'bin').toLowerCase(), data });
      return key;
    },
  };
  const parser = new Hwp5Parser(di, ctx);
  const blocks = [];
  const sections = cfb.list().filter(p => /^BodyText\/Section\d+$/.test(p)).sort((a, b) => +a.match(/\d+$/)[0] - +b.match(/\d+$/)[0]);
  if (!sections.length) throw new Error('본문(BodyText)이 없습니다');
  for (const sec of sections) {
    let raw = cfb.read(sec);
    if (compressed) raw = inflate(raw);
    const recs = readRecords(raw);
    blocks.push(...parser.parseParagraphList(recs, 0, recs.length));
  }
  return { source: 'hwp', blocks, images, warnings };
}
