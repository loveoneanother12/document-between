// Document model -> DOCX (WordprocessingML zip)
import { zipSync } from 'fflate';
import { bmpToPng } from './bmp2png.js';
import { imageSize } from './imgsize.js';
import { latexToOmml } from './mathast.js';
import { hwpEqToLatex } from './eqn.js';

const xe = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, '');
const XMLH = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
const W_NS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"';
const EMU = 12700;

export function docToDocx(doc, options = {}) {
  const TEXT_W_PT = doc.page?.width ? (doc.page.width - doc.page.left - doc.page.right - (doc.page.gutter || 0)) / 100 : 451;
  const tw = n => Math.round((n || 0) / 5);
  const warnings = [...(doc.warnings || [])];
  const font = options.font || '맑은 고딕';
  const eqToLatex = options.eqToLatex || ((script) => hwpEqToLatex(script));
  const media = []; // {name, data, rId, ext}
  const mediaByRef = new Map();
  const footnotes = [], endnotes = [];
  let imgId = 0;
  const lists = new Map();
  const numberFormats = {0:'decimal',1:'decimalEnclosedCircle',2:'upperRoman',3:'lowerRoman',4:'upperLetter',5:'lowerLetter'};
  const nativeList = p => {
    const n = p.numbering;
    if (!n || n.level > 8 || (!n.bullet && (!n.definition || n.definition.codes.slice(0, n.level + 1).some(c => !numberFormats[c])))) return null;
    if (!lists.has(n.key)) lists.set(n.key, { ...n, id: lists.size + 1 });
    return lists.get(n.key);
  };

  const mediaFor = (ref) => {
    if (mediaByRef.has(ref)) return mediaByRef.get(ref);
    const img = doc.images.get(ref); if (!img) return null;
    let ext = (img.ext || 'png').toLowerCase().replace('jpeg', 'jpg'), data = img.data;
    if (ext === 'bmp' || ext === 'dib') { const png = bmpToPng(data); if (png) { ext = 'png'; data = png; } }
    if (!['png', 'jpg', 'gif', 'bmp', 'tif', 'tiff', 'emf', 'wmf', 'svg'].includes(ext)) { warnings.push(`그림 형식 ${ext} 은 Word에 넣을 수 없어 건너뜁니다.`); return null; }
    const n = media.length + 1;
    const m = { name: `image${n}.${ext}`, data, rId: `rIdImg${n}`, ext };
    media.push(m); mediaByRef.set(ref, m);
    return m;
  };

  const rPr = (st = {}) => {
    let s = '';
    if (st.font) s += `<w:rFonts w:ascii="${xe(st.font)}" w:hAnsi="${xe(st.font)}" w:eastAsia="${xe(st.font)}" w:cs="${xe(st.font)}"/>`;
    if (st.bold) s += '<w:b/><w:bCs/>';
    if (st.italic) s += '<w:i/><w:iCs/>';
    if (st.underline) s += '<w:u w:val="single"/>';
    if (st.sup) s += '<w:vertAlign w:val="superscript"/>'; else if (st.sub) s += '<w:vertAlign w:val="subscript"/>';
    if (st.size && st.size !== 10) s += `<w:sz w:val="${Math.round(st.size * 2)}"/><w:szCs w:val="${Math.round(st.size * 2)}"/>`;
    return s ? `<w:rPr>${s}</w:rPr>` : '';
  };
  const run = (text, st) => {
    if (!text) return '';
    const parts = text.split(/(\t|\n)/).map(p => p === '\t' ? '<w:tab/>' : p === '\n' ? '<w:br/>' : p ? `<w:t xml:space="preserve">${xe(p)}</w:t>` : '').join('');
    return `<w:r>${rPr(st)}${parts}</w:r>`;
  };

  const ommlOf = (il) => {
    let latex = il.latex;
    if (latex === undefined) { const r = eqToLatex(il.script); latex = r.latex; for (const w of r.warnings || []) warnings.push(`수식 "${il.script.slice(0, 30)}": ${w}`); }
    const o = latexToOmml(latex);
    for (const w of o.warnings) warnings.push(`수식 "${latex.slice(0, 30)}": ${w}`);
    return o.omml;
  };

  const drawing = (img, widthPt, heightPt) => {
    const m = mediaFor(img.ref); if (!m) return '';
    let w = widthPt || 0, h = heightPt || 0;
    const px = imageSize(m.data, m.ext);
    if ((!w || !h) && px) { const ratio = px.height / px.width; if (!w && !h) { w = Math.min(TEXT_W_PT, px.width * 0.75); h = w * ratio; } else if (!h) h = w * ratio; else w = h / ratio; }
    if (!w) w = TEXT_W_PT * 0.6; if (!h) h = w * 0.75;
    if (w > TEXT_W_PT) { h = h * TEXT_W_PT / w; w = TEXT_W_PT; }
    const cx = Math.round(w * EMU), cy = Math.round(h * EMU);
    const id = ++imgId;
    return `<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${cx}" cy="${cy}"/><wp:docPr id="${id}" name="그림 ${id}"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="${id}" name="${m.name}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="${m.rId}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>`;
  };

  const noteRef = (note) => {
    const isEn = note.kind === 'en';
    const list = isEn ? endnotes : footnotes;
    const id = list.length + 1;
    const body = (note.blocks.length ? note.blocks : [{ type: 'p', inlines: [] }]);
    const paras = blocksXml(body, { inNote: true, noteKind: isEn ? 'EndnoteText' : 'FootnoteText' });
    // prepend the note reference mark into the first paragraph
    const refRun = `<w:r><w:rPr><w:vertAlign w:val="superscript"/></w:rPr><w:${isEn ? 'endnoteRef' : 'footnoteRef'}/></w:r><w:r><w:t xml:space="preserve"> </w:t></w:r>`;
    const firstP = paras.indexOf('<w:p>') >= 0 ? paras.indexOf('<w:p>') : paras.indexOf('<w:p ');
    let withRef = paras;
    if (firstP >= 0) { const close = paras.indexOf('</w:pPr>', firstP); const at = close >= 0 && close < paras.indexOf('</w:p>', firstP) ? close + 8 : paras.indexOf('>', firstP) + 1; withRef = paras.slice(0, at) + refRun + paras.slice(at); }
    list.push(`<w:${isEn ? 'endnote' : 'footnote'} w:id="${id}">${withRef}</w:${isEn ? 'endnote' : 'footnote'}>`);
    return `<w:r><w:rPr><w:vertAlign w:val="superscript"/></w:rPr><w:${isEn ? 'endnoteReference' : 'footnoteReference'} w:id="${id}"/></w:r>`;
  };

  const inlinesXml = (inlines, ctx) => {
    let s = ''; const after = [];
    for (const il of inlines) {
      switch (il.type) {
        case 'text': s += run(il.text, il); break;
        case 'tab': s += '<w:r><w:tab/></w:r>'; break;
        case 'br': s += '<w:r><w:br/></w:r>'; break;
        case 'eq': s += ommlOf(il); break;
        case 'note': s += ctx.inNote ? run(' [주: ' + plain(il.blocks) + ']') : noteRef(il); break;
        case 'image': s += drawing(il, il.widthPt, il.heightPt); break;
        case 'table': after.push(il); break;
        case 'textbox': after.push(il); break;
        case 'shape': s += run(`[${il.desc || '그림'} — 직접 삽입]`, { italic: true }); break;
        default: break;
      }
    }
    return { runs: s, after };
  };

  const pPr = (p, ctx) => {
    let s = '';
    if (p.pageBreak) s += '<w:pageBreakBefore/>';
    if (ctx.noteKind) s += `<w:pStyle w:val="${ctx.noteKind}"/>`;
    if (ctx.box) s += '<w:pBdr><w:top w:val="single" w:sz="4" w:space="4" w:color="000000"/><w:left w:val="single" w:sz="4" w:space="4" w:color="000000"/><w:bottom w:val="single" w:sz="4" w:space="4" w:color="000000"/><w:right w:val="single" w:sz="4" w:space="4" w:color="000000"/></w:pBdr>';
    const list = nativeList(p);
    if (list) s += `<w:numPr><w:ilvl w:val="${p.numbering.level}"/><w:numId w:val="${list.id}"/></w:numPr>`;
    if (p.layout) {
      const m = p.layout.margins, line = p.layout.lineSpacing;
      s += `<w:spacing w:before="${tw(m.prev)}" w:after="${tw(m.next)}" w:line="${line.type === 'PERCENT' ? Math.round(line.value * 2.4) : tw(line.value)}" w:lineRule="${line.type === 'PERCENT' ? 'auto' : line.type === 'FIXED' ? 'exact' : 'atLeast'}"/>`;
      s += `<w:ind w:left="${tw(m.left)}" w:right="${tw(m.right)}" ${m.intent < 0 ? 'w:hanging' : 'w:firstLine'}="${Math.abs(tw(m.intent))}"/>`;
    } else if (p.level) s += `<w:ind w:left="${p.level * 400}"/>`;
    const jc = { center: 'center', right: 'right', left: 'left', justify: 'both' }[p.align];
    if (jc && jc !== 'left') s += `<w:jc w:val="${jc}"/>`;
    return s ? `<w:pPr>${s}</w:pPr>` : '';
  };

  const paraXml = (p, ctx) => {
    let inlines = p.inlines;
    if (nativeList(p)) {
      let remaining = p.numbering.prefix.length;
      inlines = p.inlines.map(il => {
        if (il.type !== 'text' || !remaining) return il;
        const skip = Math.min(remaining, il.text.length); remaining -= skip;
        return { ...il, text: il.text.slice(skip) };
      });
    }
    const { runs, after } = inlinesXml(inlines, ctx);
    return `<w:p>${pPr(p, ctx)}${runs}</w:p>` + (after.length ? blocksXml(after, ctx) : '');
  };

  const tableXml = (t, ctx) => {
    const rows = Math.max(1, t.rows), cols = Math.max(1, t.cols);
    const grid = Array.from({ length: rows }, () => Array(cols).fill(null));
    for (const c of t.cells) {
      if (c.row >= rows || c.col >= cols) continue;
      for (let r = c.row; r < Math.min(rows, c.row + c.rowspan); r++) for (let k = c.col; k < Math.min(cols, c.col + c.colspan); k++) grid[r][k] = { cell: c, start: r === c.row && k === c.col, rowStart: r === c.row };
    }
    const colW = Array(cols).fill(0);
    for (const c of t.cells) if (c.colspan === 1 && c.col < cols && c.width) colW[c.col] = Math.max(colW[c.col], c.width / 5); // HWPUNIT -> twips
    let total = colW.reduce((a, b) => a + b, 0);
    const maxTw = Math.min(TEXT_W_PT * 20, ctx.cellWidth || Infinity, t.widthHU ? tw(t.widthHU) : Infinity);
    if (!colW.every(w => w > 0) || !total) { colW.fill(Math.floor(maxTw / cols)); total = colW.reduce((a, b) => a + b, 0); }
    if (total > maxTw) { for (let i = 0; i < cols; i++) colW[i] = Math.round(colW[i] * maxTw / total); }
    const trs = [];
    for (let r = 0; r < rows; r++) {
      const tcs = [];
      let k = 0;
      while (k < cols) {
        const g = grid[r][k];
        if (!g) { tcs.push(`<w:tc><w:tcPr><w:tcW w:w="${Math.round(colW[k])}" w:type="dxa"/></w:tcPr><w:p/></w:tc>`); k++; continue; }
        const c = g.cell;
        const span = Math.min(c.colspan, cols - k);
        const w = colW.slice(k, k + span).reduce((a, b) => a + b, 0);
        let pr = `<w:tcW w:w="${Math.round(w)}" w:type="dxa"/>`;
        if (span > 1) pr += `<w:gridSpan w:val="${span}"/>`;
        if (c.rowspan > 1) pr += g.rowStart ? '<w:vMerge w:val="restart"/>' : '<w:vMerge/>';
        if (c.style?.borders) {
          const types = {NONE:'nil',SOLID:'single',DASH:'dashed',DOT:'dotted',DASH_DOT:'dotDash',DASH_DOT_DOT:'dotDotDash',DOUBLE_SLIM:'double',DOUBLE:'double',SLIM_THICK:'thinThickSmallGap',THICK_SLIM:'thickThinSmallGap'};
          pr += '<w:tcBorders>' + Object.entries(c.style.borders).map(([side,b]) => `<w:${side} w:val="${types[b.type] || 'single'}" w:sz="${Math.max(2, Math.round(b.width * 72 / 25.4 * 8))}" w:color="${xe(b.color.replace('#',''))}"/>`).join('') + '</w:tcBorders>';
        }
        if (c.style?.fill && /^#[0-9a-f]{6}$/i.test(c.style.fill)) pr += `<w:shd w:val="clear" w:fill="${c.style.fill.slice(1)}"/>`;
        if (c.margins) pr += '<w:tcMar>' + Object.entries(c.margins).map(([side,v]) => `<w:${side} w:w="${tw(v)}" w:type="dxa"/>`).join('') + '</w:tcMar>';
        pr += `<w:vAlign w:val="${['top','center','bottom'].includes(c.verticalAlign) ? c.verticalAlign : 'center'}"/>`;
        const content = g.start ? (blocksXml(c.blocks.length ? c.blocks : [{ type: 'p', inlines: [] }], { ...ctx, inTable: true, cellWidth: Math.max(100, w - tw((c.margins?.left || 0) + (c.margins?.right || 0))) }) || '<w:p/>') : '<w:p/>';
        tcs.push(`<w:tc><w:tcPr>${pr}</w:tcPr>${content}</w:tc>`);
        k += span;
      }
      const height = Math.max(0, ...t.cells.filter(c => c.row === r && c.rowspan === 1).map(c => tw(c.height)));
      const repeat = t.repeatHeader && t.cells.some(c => c.row === r && c.header);
      trs.push(`<w:tr><w:trPr>${height ? `<w:trHeight w:val="${height}" w:hRule="atLeast"/>` : ''}${repeat ? '<w:tblHeader/>' : ''}${t.pageBreak === 'NONE' ? '<w:cantSplit/>' : ''}</w:trPr>${tcs.join('')}</w:tr>`);
    }
    const borders = '<w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:left w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:right w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="000000"/></w:tblBorders>';
    const tbl = `<w:tbl><w:tblPr><w:tblW w:w="0" w:type="auto"/><w:jc w:val="center"/>${t.cells.some(c => c.style) ? '' : borders}<w:tblLayout w:type="fixed"/><w:tblCellMar><w:left w:w="80" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>${colW.map(w => `<w:gridCol w:w="${Math.round(w)}"/>`).join('')}</w:tblGrid>${trs.join('')}</w:tbl>`;
    const cap = t.caption ? blocksXml(t.caption.map(c => ({ ...c, align: 'center' })), ctx) : '';
    // a table must be followed by a paragraph before another table / end of cell
    return cap + tbl + '<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="20" w:lineRule="exact"/></w:pPr></w:p>'; 
  };

  const blocksXml = (blocks, ctx = {}) => blocks.map(b => {
    switch (b.type) {
      case 'p': return paraXml(b, ctx);
      case 'display': return `<w:p>${pPr({ align: 'center' }, ctx)}<m:oMathPara>${ommlOf(b)}</m:oMathPara></w:p>`;
      case 'heading': return `<w:p><w:pPr><w:pStyle w:val="Heading${Math.min(3, b.level || 1)}"/>${b.align === 'center' ? '<w:jc w:val="center"/>' : ''}</w:pPr>${inlinesXml(b.inlines, ctx).runs}</w:p>`;
      case 'table': return tableXml(b, ctx);
      case 'image': return `<w:p>${pPr({ align: 'center' }, ctx)}${drawing(b, b.widthPt, b.heightPt)}</w:p>` + (b.caption ? blocksXml(b.caption.map(c => ({ ...c, align: 'center' })), ctx) : '');
      case 'textbox': return blocksXml(b.blocks, { ...ctx, box: true });
      case 'shape': return `<w:p>${pPr({ align: 'center' }, ctx)}${run(`[${b.desc || '그림'} — 직접 삽입]`, { italic: true })}</w:p>`;
      default: return '';
    }
  }).join('');

  // display-equation paragraphs: a paragraph holding only one equation
  const body = blocksXml(doc.blocks.map(b => (b.type === 'p' && b.inlines.filter(i => !(i.type === 'text' && !i.text.trim())).length === 1 && b.inlines.find(i => i.type === 'eq')) ? { ...b.inlines.find(i => i.type === 'eq'), type: 'display' } : b));

  const parts = [];
  for (const kind of ['header','footer']) {
    const seen = new Set();
    for (const part of doc[kind + 's'] || []) {
      const type = part.apply === 'EVEN' ? 'even' : 'default';
      if (seen.has(type)) { warnings.push('구역별 ' + kind + ' 변경은 첫 설정만 보존됩니다.'); continue; }
      seen.add(type);
      const name = kind + (parts.length + 1);
      parts.push({ kind, type, name, xml: XMLH + `<w:${kind === 'header' ? 'hdr' : 'ftr'} ${W_NS}>${blocksXml(part.blocks)}<w:p/></w:${kind === 'header' ? 'hdr' : 'ftr'}>` });
    }
  }
  const pg = doc.page;
  const noteFormat = kind => ({DIGIT:'decimal',ROMAN_SMALL:'lowerRoman',ROMAN_CAPITAL:'upperRoman',LATIN_SMALL:'lowerLetter',LATIN_CAPITAL:'upperLetter'}[doc.noteFormats?.[kind]] || (kind === 'endNote' ? 'lowerRoman' : 'decimal'));
  const section = parts.map(p => `<w:${p.kind}Reference w:type="${p.type}" r:id="${p.name}"/>`).join('') + (pg ? `<w:pgSz w:w="${tw(pg.width)}" w:h="${tw(pg.height)}"/><w:pgMar w:top="${tw(pg.top + pg.header)}" w:right="${tw(pg.right)}" w:bottom="${tw(pg.bottom + pg.footer)}" w:left="${tw(pg.left)}" w:header="${tw(pg.top)}" w:footer="${tw(pg.bottom)}" w:gutter="${tw(pg.gutter)}"/>` : '<w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1417" w:right="1417" w:bottom="1417" w:left="1417" w:header="708" w:footer="708" w:gutter="0"/>');
  const document = XMLH + `<w:document ${W_NS}><w:body>${body}<w:sectPr>${section}</w:sectPr></w:body></w:document>`;
  const numbering = XMLH + `<w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">` + [...lists.values()].map(n => {
    const levels = Array.from({length:9}, (_,i) => {
      const fmt = n.bullet ? 'bullet' : numberFormats[n.definition.codes[i]] || 'decimal';
      const label = n.bullet ? n.prefix.trim() : (n.definition.formats[i] || '^' + (i+1) + '.').replace(/\^(10|[1-9])/g, (_,d) => '%' + d);
      return `<w:lvl w:ilvl="${i}"><w:start w:val="${n.definition?.starts[i] || 1}"/><w:numFmt w:val="${fmt}"/><w:suff w:val="space"/><w:lvlText w:val="${xe(label)}"/><w:lvlJc w:val="left"/></w:lvl>`;
    }).join('');
    return `<w:abstractNum w:abstractNumId="${n.id}"><w:multiLevelType w:val="multilevel"/>${levels}</w:abstractNum>`;
  }).join('') + [...lists.values()].map(n => `<w:num w:numId="${n.id}"><w:abstractNumId w:val="${n.id}"/></w:num>`).join('') + '</w:numbering>';

  const styles = XMLH + `<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="${xe(font)}" w:hAnsi="${xe(font)}" w:eastAsia="${xe(font)}" w:cs="${xe(font)}"/><w:sz w:val="20"/><w:szCs w:val="20"/><w:lang w:val="en-US" w:eastAsia="ko-KR"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="320" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>` +
    `<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>` +
    `<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="240" w:after="120"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:sz w:val="32"/></w:rPr></w:style>` +
    `<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="200" w:after="100"/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:sz w:val="28"/></w:rPr></w:style>` +
    `<w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:outlineLvl w:val="2"/></w:pPr><w:rPr><w:b/><w:sz w:val="24"/></w:rPr></w:style>` +
    `<w:style w:type="paragraph" w:styleId="FootnoteText"><w:name w:val="footnote text"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:rPr><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>` +
    `<w:style w:type="paragraph" w:styleId="EndnoteText"><w:name w:val="endnote text"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:rPr><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>` +
    `</w:styles>`;
  const sepNotes = (tag) => `<w:${tag} w:type="separator" w:id="-1"><w:p><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:r><w:separator/></w:r></w:p></w:${tag}><w:${tag} w:type="continuationSeparator" w:id="0"><w:p><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:r><w:continuationSeparator/></w:r></w:p></w:${tag}>`;
  const footnotesXml = XMLH + `<w:footnotes ${W_NS}>${sepNotes('footnote')}${footnotes.join('')}</w:footnotes>`;
  const endnotesXml = XMLH + `<w:endnotes ${W_NS}>${sepNotes('endnote')}${endnotes.join('')}</w:endnotes>`;
  const settings = XMLH + `<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">${parts.some(p => p.type === 'even') ? '<w:evenAndOddHeaders/>' : ''}<w:footnotePr><w:numFmt w:val="${noteFormat('footNote')}"/><w:footnote w:id="-1"/><w:footnote w:id="0"/></w:footnotePr><w:endnotePr><w:numFmt w:val="${noteFormat('endNote')}"/><w:endnote w:id="-1"/><w:endnote w:id="0"/></w:endnotePr><w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat></w:settings>`;
  const rels = XMLH + `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes" Target="footnotes.xml"/><Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/endnotes" Target="endnotes.xml"/>${parts.map(p => `<Relationship Id="${p.name}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/${p.kind}" Target="${p.name}.xml"/>`).join('')}<Relationship Id="rIdNumbering" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>${media.map(m => `<Relationship Id="${m.rId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${m.name}"/>`).join('')}</Relationships>`;
  const rootRels = XMLH + `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>`;
  const exts = [...new Set(media.map(m => m.ext))];
  const mime = { png: 'image/png', jpg: 'image/jpeg', gif: 'image/gif', bmp: 'image/bmp', tif: 'image/tiff', tiff: 'image/tiff', emf: 'image/x-emf', wmf: 'image/x-wmf', svg: 'image/svg+xml' };
  const contentTypes = XMLH + `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>${exts.map(e => `<Default Extension="${e}" ContentType="${mime[e]}"/>`).join('')}${parts.map(p => `<Override PartName="/word/${p.name}.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.${p.kind}+xml"/>`).join('')}<Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/><Override PartName="/word/footnotes.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml"/><Override PartName="/word/endnotes.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>`;
  const core = XMLH + `<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${xe(options.title || '')}</dc:title><dc:creator>hwp2tex</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString()}</dcterms:created></cp:coreProperties>`;

  const enc = (s) => new TextEncoder().encode(s);
  const entries = {
    '[Content_Types].xml': enc(contentTypes),
    '_rels/.rels': enc(rootRels),
    'docProps/core.xml': enc(core),
    'word/document.xml': enc(document),
    'word/styles.xml': enc(styles),
    'word/numbering.xml': enc(numbering),
    'word/settings.xml': enc(settings),
    'word/footnotes.xml': enc(footnotesXml),
    'word/endnotes.xml': enc(endnotesXml),
    'word/_rels/document.xml.rels': enc(rels),
  };
  for (const p of parts) { entries[`word/${p.name}.xml`] = enc(p.xml); entries[`word/_rels/${p.name}.xml.rels`] = enc(rels); }
  for (const name of ['footnotes','endnotes']) entries[`word/_rels/${name}.xml.rels`] = enc(rels);
  for (const m of media) entries['word/media/' + m.name] = [m.data, { level: 0 }];
  return { docx: zipSync(entries, { level: 6 }), warnings };
}

function plain(blocks) {
  let s = '';
  for (const b of blocks || []) if (b.type === 'p') for (const il of b.inlines) { if (il.type === 'text') s += il.text; else if (il.type === 'eq') s += '[수식]'; }
  return s.trim();
}
