// Public API: convert(bytes, options) -> { tex, files, warnings, doc }
import { parseHwp5 } from './hwp5.js';
import { parseHwpx, setDOMParser as _setHwpxDP } from './hwpx.js';
import { docToLatex } from './latex.js';
import { hwpEqToLatex } from './eqn.js';

export function detectFormat(bytes) {
  if (bytes.length >= 8 && bytes[0] === 0xd0 && bytes[1] === 0xcf && bytes[2] === 0x11 && bytes[3] === 0xe0) return 'hwp';
  if (bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b) return 'hwpx';
  const head = new TextDecoder().decode(bytes.subarray(0, 200));
  if (/<\?xml/.test(head) && /HWPML|hwpml/.test(head)) return 'hml';
  return 'unknown';
}

export function parseDocument(bytes) {
  const fmt = detectFormat(bytes);
  if (fmt === 'hwp') return parseHwp5(bytes);
  if (fmt === 'hwpx') return parseHwpx(bytes);
  if (fmt === 'hml') throw new Error('HML(한글 XML) 형식은 아직 지원하지 않습니다. 한글에서 HWPX로 저장해 주세요.');
  throw new Error('HWP/HWPX 파일이 아닙니다.');
}

export function convert(bytes, options = {}) {
  const doc = parseDocument(bytes);
  const out = docToLatex(doc, options);
  return { ...out, doc, format: doc.source };
}

export { parseHwp5, parseHwpx, docToLatex, hwpEqToLatex };
export function setDOMParser(dp) { _setHwpxDP(dp); setDocxDOMParser(dp); }

import { parseLatexDoc } from './latexdoc.js';
import { docToHwpx } from './hwpxwrite.js';
import { latexToHancom } from './mathast.js';
export function latexToHwpx(texString, files = new Map(), options = {}) {
  const doc = parseLatexDoc(texString, files);
  const out = docToHwpx(doc, { ...options, eqToScript: latexToHancom });
  return { hwpx: out.hwpx, warnings: [...doc.warnings, ...out.warnings], doc };
}
export { parseLatexDoc, docToHwpx, latexToHancom };

import { docToDocx } from './docxwrite.js';
export function toDocx(bytes, options = {}) {
  const doc = parseDocument(bytes);
  const out = docToDocx(doc, options);
  return { docx: out.docx, warnings: out.warnings, doc };
}
export { docToDocx };

import { parseDocx, setDocxDOMParser } from './docxread.js';
export function docxToHwpx(bytes, options = {}) {
  const doc = parseDocx(bytes);
  const out = docToHwpx(doc, { ...options, eqToScript: latexToHancom });
  return { hwpx: out.hwpx, warnings: [...doc.warnings, ...out.warnings], doc };
}
export function docxToLatex(bytes, options = {}) {
  const doc = parseDocx(bytes);
  const out = docToLatex(doc, options);
  return { ...out, doc };
}
export { parseDocx, setDocxDOMParser };
