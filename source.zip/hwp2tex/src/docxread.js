// DOCX -> document model
import { unzipSync } from 'fflate';
import { ommlToLatex, tidyLatexFromOmml } from './mathast.js';
import { formatNumber } from './hwp5.js';

let _DOMParser = typeof DOMParser !== 'undefined' ? DOMParser : null;
export function setDocxDOMParser(dp) { _DOMParser = dp; }
const local = (el) => (el.localName || el.nodeName || '').replace(/^[^:]+:/, '');
const kids = (el) => { const out = []; const k = el.childNodes || []; for (let i = 0; i < k.length; i++) if (k[i].nodeType === 1) out.push(k[i]); return out; };
const kid = (el, name) => kids(el).find(c => local(c) === name) || null;
const attr = (el, name, dflt = '') => { if (!el || !el.getAttribute) return dflt; const v = el.getAttribute('w:' + name) ?? el.getAttribute(name) ?? el.getAttribute('r:' + name); return v == null ? dflt : v; };
const num = (v, d = 0) => { const n = parseFloat(v); return Number.isFinite(n) ? n : d; };
const parseXml = (text) => new _DOMParser().parseFromString(text, 'application/xml').documentElement;
const NUMFMT = { decimal: 0, decimalEnclosedCircle: 1, upperRoman: 2, lowerRoman: 3, upperLetter: 4, lowerLetter: 5, ganada: 8, chosung: 10, koreanDigital: 12, ideographDigital: 13, koreanCounting: 12 };

export function parseDocx(bytes) {
  let zip;
  try { zip = unzipSync(bytes); } catch (e) { throw new Error('DOCX(ZIP) 파일을 열 수 없습니다: ' + e.message); }
  const has = (p) => Object.hasOwn(zip, p);
  const text = (p) => new TextDecoder('utf-8').decode(zip[p]);
  if (!has('word/document.xml')) throw new Error('word/document.xml 이 없습니다 — Word(.docx) 파일이 맞는지 확인하세요.');
  const warnings = [];
  const images = new Map();

  // relationships
  const rels = new Map();
  if (has('word/_rels/document.xml.rels')) {
    const r = parseXml(text('word/_rels/document.xml.rels'));
    for (const el of kids(r)) if (local(el) === 'Relationship') rels.set(el.getAttribute('Id'), el.getAttribute('Target'));
  }
  // styles: paragraph style id -> {bold, size, heading level, italic}
  const styles = new Map();
  let defaultFont = '';
  const fontOf = rpr => { const f = rpr && kid(rpr, 'rFonts'); return attr(f, 'eastAsia') || attr(f, 'ascii') || attr(f, 'hAnsi'); };
  if (has('word/styles.xml')) {
    const s = parseXml(text('word/styles.xml'));
    const defaults = kid(s, 'docDefaults');
    defaultFont = fontOf(defaults && kid(kid(defaults, 'rPrDefault') || defaults, 'rPr'));
    for (const st of kids(s)) {
      if (local(st) !== 'style') continue;
      const id = attr(st, 'styleId');
      const name = attr(kid(st, 'name'), 'val').toLowerCase();
      const rpr = kid(st, 'rPr');
      const info = { bold: !!(rpr && kid(rpr, 'b') && attr(kid(rpr, 'b'), 'val', '1') !== '0'), italic: !!(rpr && kid(rpr, 'i')), size: rpr && kid(rpr, 'sz') ? num(attr(kid(rpr, 'sz'), 'val')) / 2 : 0, heading: /^heading (\d)|^제목 (\d)/.exec(name) ? +(/\d/.exec(name)[0]) : 0, numPr: kid(kid(st, 'pPr') || st, 'numPr') };
      info.font = fontOf(rpr) || defaultFont;
      styles.set(id, info);
    }
  }
  // numbering
  const abstracts = new Map(), nums = new Map();
  if (has('word/numbering.xml')) {
    const n = parseXml(text('word/numbering.xml'));
    for (const el of kids(n)) {
      if (local(el) === 'abstractNum') {
        const lvls = [];
        for (const lv of kids(el)) if (local(lv) === 'lvl') lvls[num(attr(lv, 'ilvl'))] = { fmt: attr(kid(lv, 'numFmt'), 'val', 'decimal'), text: attr(kid(lv, 'lvlText'), 'val', '%1.'), start: num(attr(kid(lv, 'start'), 'val'), 1) || 1 };
        abstracts.set(attr(el, 'abstractNumId'), lvls);
      } else if (local(el) === 'num') nums.set(attr(el, 'numId'), attr(kid(el, 'abstractNumId'), 'val'));
    }
  }
  const counters = new Map();
  const numberText = (numId, ilvl) => {
    const abs = abstracts.get(nums.get(numId)); if (!abs) return '';
    const lv = abs[ilvl] || abs[0]; if (!lv) return '';
    let c = counters.get(numId); if (!c) { c = abs.map(l => (l ? l.start : 1) - 1); counters.set(numId, c); }
    c[ilvl] = (c[ilvl] ?? 0) + 1;
    for (let k = ilvl + 1; k < c.length; k++) c[k] = (abs[k] ? abs[k].start : 1) - 1;
    if (lv.fmt === 'bullet') return (lv.text === '' || lv.text === '' || lv.text.charCodeAt(0) >= 0xf000 ? '•' : lv.text) + ' ';
    if (lv.fmt === 'none') return '';
    return lv.text.replace(/%(\d)/g, (m, d) => formatNumber(Math.max(1, c[d - 1] ?? 1), NUMFMT[(abs[d - 1] || lv).fmt] ?? 0)) + ' ';
  };
  // notes
  const noteMap = (part, tag) => {
    const m = new Map();
    if (!has(part)) return m;
    const root = parseXml(text(part));
    for (const n of kids(root)) if (local(n) === tag && !attr(n, 'type')) m.set(attr(n, 'id'), n);
    return m;
  };
  const footnotes = noteMap('word/footnotes.xml', 'footnote'), endnotes = noteMap('word/endnotes.xml', 'endnote');

  const imageRef = (rId) => {
    const target = rels.get(rId); if (!target) return null;
    const path = 'word/' + target.replace(/^\/?word\//, '').replace(/^\//, '');
    const key = rId;
    if (images.has(key)) return key;
    if (!has(path)) { warnings.push(`그림 ${target} 을 찾지 못했습니다.`); return null; }
    const ext = (path.match(/\.([A-Za-z0-9]+)$/) || [, 'png'])[1].toLowerCase();
    images.set(key, { ext, data: zip[path] });
    return key;
  };

  const runStyle = (r, pStyleInfo) => {
    const rpr = kid(r, 'rPr');
    const st = { bold: !!pStyleInfo?.bold, italic: !!pStyleInfo?.italic, underline: false, sup: false, sub: false, size: pStyleInfo?.size || 0, font: pStyleInfo?.font || defaultFont };
    if (rpr) {
      st.font = fontOf(rpr) || st.font;
      const b = kid(rpr, 'b'); if (b) st.bold = attr(b, 'val', '1') !== '0' && attr(b, 'val', '1') !== 'false';
      const i = kid(rpr, 'i'); if (i) st.italic = attr(i, 'val', '1') !== '0' && attr(i, 'val', '1') !== 'false';
      const u = kid(rpr, 'u'); if (u) st.underline = attr(u, 'val', 'single') !== 'none';
      const va = kid(rpr, 'vertAlign'); if (va) { st.sup = attr(va, 'val') === 'superscript'; st.sub = attr(va, 'val') === 'subscript'; }
      const sz = kid(rpr, 'sz'); if (sz) st.size = num(attr(sz, 'val')) / 2;
      const rs = kid(rpr, 'rStyle'); if (rs && styles.get(attr(rs, 'val'))?.bold) st.bold = true;
    }
    return st;
  };

  const parseRuns = (container, inlines, pStyleInfo, depth) => {
    for (const el of kids(container)) {
      const t = local(el);
      if (t === 'r') {
        const st = runStyle(el, pStyleInfo);
        for (const c of kids(el)) {
          const ct = local(c);
          if (ct === 't') pushText(inlines, c.textContent, st);
          else if (ct === 'tab') inlines.push({ type: 'tab' });
          else if (ct === 'br') inlines.push({ type: 'br' });
          else if (ct === 'sym') pushText(inlines, String.fromCharCode(parseInt(attr(c, 'char', '20'), 16)), st);
          else if (ct === 'footnoteReference' || ct === 'endnoteReference') {
            const isEn = ct === 'endnoteReference';
            const n = (isEn ? endnotes : footnotes).get(attr(c, 'id'));
            if (n) inlines.push({ type: 'note', kind: isEn ? 'en' : 'fn', blocks: parseBlocks(n, depth + 1).map(stripNoteRef) });
          }
          else if (ct === 'drawing' || ct === 'pict' || ct === 'object') {
            const img = parseDrawing(c);
            if (img) inlines.push(img);
          }
        }
      } else if (t === 'oMath') {
        const latex = tidyLatexFromOmml(ommlToLatex(el, warnings));
        if (latex.trim()) inlines.push({ type: 'eq', latex });
      } else if (t === 'oMathPara') {
        for (const om of kids(el)) if (local(om) === 'oMath') { const latex = tidyLatexFromOmml(ommlToLatex(om, warnings)); if (latex.trim()) inlines.push({ type: 'eq', latex, display: true }); }
      } else if (t === 'hyperlink' || t === 'smartTag' || t === 'ins' || t === 'sdt' || t === 'sdtContent' || t === 'fldSimple' || t === 'customXml' || t === 'dir' || t === 'bdo') {
        parseRuns(t === 'sdt' ? (kid(el, 'sdtContent') || el) : el, inlines, pStyleInfo, depth);
      }
    }
  };
  const pushText = (inlines, s, st) => { if (!s) return; const last = inlines[inlines.length - 1]; if (last && last.type === 'text' && sameStyle(last, st)) last.text += s; else inlines.push({ type: 'text', text: s, ...st }); };
  const sameStyle = (a, b) => ['bold', 'italic', 'underline', 'sup', 'sub', 'size', 'font'].every(k => (a[k] || 0) === (b[k] || 0));
  const stripNoteRef = (b) => b; // the note mark run (footnoteRef) produces no text, nothing to strip

  const parseDrawing = (el) => {
    const all = el.getElementsByTagName('*');
    let rId = null, cx = 0, cy = 0;
    for (let i = 0; i < all.length; i++) {
      const a = all[i], n = local(a);
      if (n === 'blip' && !rId) rId = a.getAttribute('r:embed') || a.getAttribute('r:link') || attr(a, 'embed');
      else if (n === 'imagedata' && !rId) rId = a.getAttribute('r:id') || attr(a, 'id');
      else if (n === 'extent' && !cx) { cx = num(a.getAttribute('cx')); cy = num(a.getAttribute('cy')); }
    }
    if (!rId) return null;
    const ref = imageRef(rId); if (!ref) return null;
    const anchor = kid(el, 'anchor');
    return { type: 'image', ref, widthPt: cx / 12700, heightPt: cy / 12700, inline: !anchor };
  };

  const parseParagraph = (p, depth) => {
    const ppr = kid(p, 'pPr');
    const styleId = ppr && kid(ppr, 'pStyle') ? attr(kid(ppr, 'pStyle'), 'val') : '';
    const sInfo = styles.get(styleId);
    const jcEl = ppr && kid(ppr, 'jc');
    const jc = jcEl ? attr(jcEl, 'val') : '';
    const align = { center: 'center', right: 'right', end: 'right', both: 'justify', distribute: 'justify', left: 'left', start: 'left' }[jc] || 'justify';
    const inlines = [];
    const numPr = (ppr && kid(ppr, 'numPr')) || sInfo?.numPr;
    let level = 0;
    if (numPr) {
      const numId = attr(kid(numPr, 'numId'), 'val'); const ilvl = num(attr(kid(numPr, 'ilvl'), 'val'));
      level = ilvl;
      const head = numberText(numId, ilvl);
      if (head) inlines.push({ type: 'text', text: head, bold: false, italic: false, underline: false, sup: false, sub: false, size: 0 });
    }
    parseRuns(p, inlines, sInfo, depth);
    if (sInfo?.heading) return { type: 'heading', level: sInfo.heading, inlines, align: align === 'center' ? 'center' : 'left' };
    // a paragraph with only a display equation
    const nonWs = inlines.filter(i => !(i.type === 'text' && !i.text.trim()));
    if (nonWs.length === 1 && nonWs[0].type === 'eq' && nonWs[0].display) return { type: 'display', latex: nonWs[0].latex };
    return { type: 'p', inlines, align, level };
  };

  const parseTable = (tbl, depth) => {
    const cells = [];
    const gridCols = kid(tbl, 'tblGrid') ? kids(kid(tbl, 'tblGrid')).filter(c => local(c) === 'gridCol').map(c => num(attr(c, 'w'))) : [];
    const rowsEl = kids(tbl).filter(c => local(c) === 'tr');
    const vmerge = new Map(); // col -> cell with open vMerge
    rowsEl.forEach((tr, r) => {
      let c = 0;
      for (const tc of kids(tr)) {
        if (local(tc) !== 'tc') continue;
        const tcPr = kid(tc, 'tcPr');
        const span = tcPr && kid(tcPr, 'gridSpan') ? num(attr(kid(tcPr, 'gridSpan'), 'val'), 1) || 1 : 1;
        const vm = tcPr && kid(tcPr, 'vMerge');
        const vmVal = vm ? attr(vm, 'val', 'continue') : null;
        const w = tcPr && kid(tcPr, 'tcW') ? num(attr(kid(tcPr, 'tcW'), 'w')) : gridCols.slice(c, c + span).reduce((a, b) => a + b, 0);
        if (vm && vmVal !== 'restart' && vmerge.has(c)) { vmerge.get(c).rowspan++; c += span; continue; }
        const cell = { row: r, col: c, colspan: span, rowspan: 1, width: Math.round(w * 5), height: 0, blocks: parseBlocks(tc, depth + 1) };
        cells.push(cell);
        if (vm && vmVal === 'restart') vmerge.set(c, cell); else vmerge.delete(c);
        c += span;
      }
    });
    let rows = rowsEl.length, cols = gridCols.length;
    for (const cl of cells) cols = Math.max(cols, cl.col + cl.colspan);
    return { type: 'table', rows, cols, cells, caption: null };
  };

  const parseBlocks = (container, depth = 0) => {
    const blocks = [];
    if (depth > 12) return blocks;
    for (const el of kids(container)) {
      const t = local(el);
      if (t === 'p') blocks.push(parseParagraph(el, depth));
      else if (t === 'tbl') blocks.push(parseTable(el, depth));
      else if (t === 'sdt') blocks.push(...parseBlocks(kid(el, 'sdtContent') || el, depth));
      else if (t === 'sectPr' || t === 'bookmarkStart' || t === 'bookmarkEnd' || t === 'pPr' || t === 'tcPr') continue;
      else if (t === 'ins' || t === 'customXml') blocks.push(...parseBlocks(el, depth));
    }
    return blocks;
  };

  const root = parseXml(text('word/document.xml'));
  const body = kid(root, 'body') || root;
  const blocks = parseBlocks(body);
  // hoist images anchored (floating) stay inline; fine
  return { source: 'docx', blocks, images, warnings };
}
