// Math hub: LaTeX math -> AST -> Hancom equation script / OMML (Word), and OMML -> LaTeX.
// AST node shapes:
//  {t:'seq', items}  {t:'sym', v}  {t:'cmd', v:'\\alpha'}  {t:'text', v}  {t:'space', v}
//  {t:'frac', num, den}  {t:'sqrt', body, idx}  {t:'script', base, sub, sup, limits}
//  {t:'group', body}  {t:'fence', left, right, body}  {t:'accent', name, body}
//  {t:'env', name, rows:[[seq,...],...]}  {t:'font', style, body}  {t:'op', v}  {t:'binom', a, b}
//  {t:'boxed', body}  {t:'brace', over:bool, body, label}  {t:'stack', over, under, base}

// ---------- symbol tables ----------
// LaTeX command -> [unicode, hancom]
const TABLE = [
  ['\\alpha', 'α', 'alpha'], ['\\beta', 'β', 'beta'], ['\\gamma', 'γ', 'gamma'], ['\\delta', 'δ', 'delta'], ['\\epsilon', 'ϵ', 'epsilon'], ['\\varepsilon', 'ε', 'epsilon'],
  ['\\zeta', 'ζ', 'zeta'], ['\\eta', 'η', 'eta'], ['\\theta', 'θ', 'theta'], ['\\vartheta', 'ϑ', 'theta'], ['\\iota', 'ι', 'iota'], ['\\kappa', 'κ', 'kappa'], ['\\lambda', 'λ', 'lambda'],
  ['\\mu', 'μ', 'mu'], ['\\nu', 'ν', 'nu'], ['\\xi', 'ξ', 'xi'], ['\\pi', 'π', 'pi'], ['\\varpi', 'ϖ', 'pi'], ['\\rho', 'ρ', 'rho'], ['\\varrho', 'ϱ', 'rho'], ['\\sigma', 'σ', 'sigma'], ['\\varsigma', 'ς', 'sigma'],
  ['\\tau', 'τ', 'tau'], ['\\upsilon', 'υ', 'upsilon'], ['\\phi', 'ϕ', 'phi'], ['\\varphi', 'φ', 'phi'], ['\\chi', 'χ', 'chi'], ['\\psi', 'ψ', 'psi'], ['\\omega', 'ω', 'omega'],
  ['\\Gamma', 'Γ', 'GAMMA'], ['\\Delta', 'Δ', 'DELTA'], ['\\Theta', 'Θ', 'THETA'], ['\\Lambda', 'Λ', 'LAMBDA'], ['\\Xi', 'Ξ', 'XI'], ['\\Pi', 'Π', 'PI'], ['\\Sigma', 'Σ', 'SIGMA'],
  ['\\Upsilon', 'Υ', 'UPSILON'], ['\\Phi', 'Φ', 'PHI'], ['\\Psi', 'Ψ', 'PSI'], ['\\Omega', 'Ω', 'OMEGA'],
  ['\\times', '×', 'times'], ['\\cdot', '⋅', 'cdot'], ['\\div', '÷', 'div'], ['\\pm', '±', '+-'], ['\\mp', '∓', '-+'], ['\\ast', '∗', 'ast'], ['\\star', '⋆', 'star'], ['\\circ', '∘', 'circ'], ['\\bullet', '∙', 'bullet'],
  ['\\leq', '≤', 'leq'], ['\\le', '≤', 'leq'], ['\\geq', '≥', 'geq'], ['\\ge', '≥', 'geq'], ['\\neq', '≠', 'neq'], ['\\ne', '≠', 'neq'], ['\\ll', '≪', '<<'], ['\\gg', '≫', '>>'],
  ['\\sim', '∼', 'sim'], ['\\simeq', '≃', 'simeq'], ['\\approx', '≈', 'approx'], ['\\cong', '≅', 'cong'], ['\\equiv', '≡', '=='], ['\\propto', '∝', 'propto'], ['\\fallingdotseq', '≒', 'image'], ['\\risingdotseq', '≓', 'reimage'],
  ['\\prec', '≺', 'prec'], ['\\succ', '≻', 'succ'], ['\\doteq', '≐', 'doteq'], ['\\asymp', '≍', 'asymp'],
  ['\\in', '∈', 'in'], ['\\notin', '∉', 'notin'], ['\\ni', '∋', 'owns'], ['\\subset', '⊂', 'subset'], ['\\supset', '⊃', 'superset'], ['\\subseteq', '⊆', 'subseteq'], ['\\supseteq', '⊇', 'supseteq'],
  ['\\cup', '∪', 'cup'], ['\\cap', '∩', 'cap'], ['\\emptyset', '∅', 'emptyset'], ['\\varnothing', '∅', 'emptyset'], ['\\setminus', '∖', '-'],
  ['\\forall', '∀', 'forall'], ['\\exists', '∃', 'exists'], ['\\nexists', '∄', 'exists'], ['\\lor', '∨', 'lor'], ['\\land', '∧', 'land'], ['\\neg', '¬', 'lnot'], ['\\lnot', '¬', 'lnot'],
  ['\\therefore', '∴', 'therefore'], ['\\because', '∵', 'because'], ['\\infty', '∞', 'inf'], ['\\partial', '∂', 'partial'], ['\\nabla', '∇', 'nabla'],
  ['\\angle', '∠', 'angle'], ['\\measuredangle', '∡', 'msangle'], ['\\triangle', '△', 'TRIANGLE'], ['\\square', '□', 'square'], ['\\blacksquare', '■', 'square'], ['\\perp', '⊥', 'bot'], ['\\parallel', '∥', 'parallel'], ['\\bigcirc', '○', 'bigcirc'],
  ['\\cdots', '⋯', 'cdots'], ['\\ldots', '…', 'ldots'], ['\\dots', '…', 'ldots'], ['\\vdots', '⋮', 'vdots'], ['\\ddots', '⋱', 'ddots'],
  ['\\rightarrow', '→', '->'], ['\\to', '→', '->'], ['\\leftarrow', '←', '<-'], ['\\gets', '←', '<-'], ['\\leftrightarrow', '↔', '<->'], ['\\Rightarrow', '⇒', 'RARROW'], ['\\Leftarrow', '⇐', 'LARROW'], ['\\Leftrightarrow', '⇔', 'LRARROW'],
  ['\\uparrow', '↑', 'uparrow'], ['\\downarrow', '↓', 'downarrow'], ['\\mapsto', '↦', 'mapsto'], ['\\longrightarrow', '⟶', '->'], ['\\implies', '⇒', 'RARROW'], ['\\iff', '⇔', 'LRARROW'],
  ['\\oplus', '⊕', 'oplus'], ['\\ominus', '⊖', 'ominus'], ['\\otimes', '⊗', 'otimes'], ['\\odot', '⊙', 'odot'], ['\\oslash', '⊘', 'odiv'],
  ['\\dagger', '†', 'dagger'], ['\\ddagger', '‡', 'ddagger'], ['\\diamond', '⋄', 'diamond'], ['\\hbar', 'ℏ', 'hbar'], ['\\aleph', 'ℵ', 'aleph'], ['\\ell', 'ℓ', 'l'], ['\\Re', 'ℜ', 'Re'], ['\\Im', 'ℑ', 'Im'],
  ['\\langle', '〈', 'langle'], ['\\rangle', '〉', 'rangle'], ['\\lfloor', '⌊', 'lfloor'], ['\\rfloor', '⌋', 'rfloor'], ['\\lceil', '⌈', 'lceil'], ['\\rceil', '⌉', 'rceil'],
  ['\\prime', '′', 'prime'], ['\\degree', '°', 'DEG'], ['\\%', '%', '%'], ['\\&', '&', '&'], ['\\#', '#', '#'], ['\\$', '$', '$'], ['\\_', '_', '_'], ['\\{', '{', 'lbrace'], ['\\}', '}', 'rbrace'], ['\\backslash', '\\', 'backslash'], ['\\|', '‖', 'Vert'], ['\\vert', '|', '|'],
  ['\\sum', '∑', 'sum'], ['\\prod', '∏', 'prod'], ['\\coprod', '∐', 'coprod'], ['\\int', '∫', 'int'], ['\\iint', '∬', 'dint'], ['\\iiint', '∭', 'tint'], ['\\oint', '∮', 'oint'], ['\\bigcup', '⋃', 'union'], ['\\bigcap', '⋂', 'inter'], ['\\bigoplus', '⨁', 'bigoplus'], ['\\bigotimes', '⨂', 'bigotimes'],
  ['\\sin', 'sin', 'sin'], ['\\cos', 'cos', 'cos'], ['\\tan', 'tan', 'tan'], ['\\sec', 'sec', 'sec'], ['\\csc', 'csc', 'csc'], ['\\cot', 'cot', 'cot'], ['\\arcsin', 'arcsin', 'arcsin'], ['\\arccos', 'arccos', 'arccos'], ['\\arctan', 'arctan', 'arctan'],
  ['\\sinh', 'sinh', 'sinh'], ['\\cosh', 'cosh', 'cosh'], ['\\tanh', 'tanh', 'tanh'], ['\\log', 'log', 'log'], ['\\ln', 'ln', 'ln'], ['\\lg', 'lg', 'lg'], ['\\exp', 'exp', 'exp'], ['\\lim', 'lim', 'lim'], ['\\max', 'max', 'max'], ['\\min', 'min', 'min'],
  ['\\sup', 'sup', 'sup'], ['\\inf', 'inf', 'inf'], ['\\gcd', 'gcd', 'gcd'], ['\\det', 'det', 'det'], ['\\dim', 'dim', 'dim'], ['\\ker', 'ker', 'ker'], ['\\deg', 'deg', 'deg'], ['\\arg', 'arg', 'arg'], ['\\Pr', 'Pr', 'Pr'], ['\\bmod', 'mod', 'mod'], ['\\limsup', 'lim sup', 'limsup'], ['\\liminf', 'lim inf', 'liminf'],
];
export const LATEX_UNICODE = new Map(TABLE.map(([l, u]) => [l, u]));
export const LATEX_HANCOM = new Map(TABLE.map(([l, , h]) => [l, h]));
export const UNICODE_LATEX = new Map();
for (const [l, u] of TABLE) if (!UNICODE_LATEX.has(u) && /^[^A-Za-z]/.test(u)) UNICODE_LATEX.set(u, l);
UNICODE_LATEX.set('·', '\\cdot'); UNICODE_LATEX.set('−', '-'); UNICODE_LATEX.set('ε', '\\varepsilon'); UNICODE_LATEX.set('∞', '\\infty'); UNICODE_LATEX.set('≒', '\\fallingdotseq');
const OPNAMES = new Set(['\\sin', '\\cos', '\\tan', '\\sec', '\\csc', '\\cot', '\\arcsin', '\\arccos', '\\arctan', '\\sinh', '\\cosh', '\\tanh', '\\log', '\\ln', '\\lg', '\\exp', '\\lim', '\\max', '\\min', '\\sup', '\\inf', '\\gcd', '\\det', '\\dim', '\\ker', '\\deg', '\\arg', '\\Pr', '\\limsup', '\\liminf']);
const BIGOPS = new Set(['\\sum', '\\prod', '\\coprod', '\\int', '\\iint', '\\iiint', '\\oint', '\\bigcup', '\\bigcap', '\\bigoplus', '\\bigotimes']);
const ACCENTS = { '\\vec': 'vec', '\\overrightarrow': 'vec', '\\overleftrightarrow': 'dyad', '\\hat': 'hat', '\\widehat': 'hat', '\\bar': 'bar', '\\overline': 'overline', '\\underline': 'underline', '\\tilde': 'tilde', '\\widetilde': 'tilde', '\\dot': 'dot', '\\ddot': 'ddot', '\\dddot': 'dddot', '\\acute': 'acute', '\\grave': 'grave', '\\check': 'check', '\\breve': 'breve', '\\overset{\\frown}': 'arch' };
const FONTS = { '\\mathrm': 'rm', '\\textrm': 'rm', '\\mathbf': 'bf', '\\boldsymbol': 'bf', '\\bm': 'bf', '\\mathit': 'it', '\\mathcal': 'cal', '\\mathbb': 'bb', '\\mathsf': 'sf', '\\mathtt': 'tt', '\\mathfrak': 'frak', '\\operatorname': 'op' };
const DELIMS = { '(': '(', ')': ')', '[': '[', ']': ']', '\\{': '{', '\\}': '}', '|': '|', '\\|': '‖', '\\vert': '|', '\\Vert': '‖', '\\langle': '〈', '\\rangle': '〉', '\\lfloor': '⌊', '\\rfloor': '⌋', '\\lceil': '⌈', '\\rceil': '⌉', '.': '', '\\lbrace': '{', '\\rbrace': '}', '<': '〈', '>': '〉', '/': '/' };

// ---------- LaTeX math tokenizer / parser ----------
function tokenizeLatex(src) {
  const toks = [];
  let i = 0;
  while (i < src.length) {
    const ch = src[i];
    if (/\s/.test(ch)) { i++; continue; }
    if (ch === '%') { while (i < src.length && src[i] !== '\n') i++; continue; }
    if (ch === '\\') {
      if (i + 1 < src.length && /[A-Za-z]/.test(src[i + 1])) {
        let j = i + 1; while (j < src.length && /[A-Za-z]/.test(src[j])) j++;
        let cmd = src.slice(i, j);
        if (cmd === '\\begin' || cmd === '\\end') { const m = /^\s*\{([^}]*)\}/.exec(src.slice(j)); if (m) { toks.push({ t: cmd === '\\begin' ? 'begin' : 'end', v: m[1].replace('*', '') }); i = j + m[0].length; continue; } }
        toks.push({ t: 'cmd', v: cmd }); i = j; continue;
      }
      if (i + 1 < src.length) { toks.push({ t: 'cmd', v: '\\' + src[i + 1] }); i += 2; continue; }
      i++; continue;
    }
    if ('{}^_&'.includes(ch)) { toks.push({ t: ch, v: ch }); i++; continue; }
    if (/[0-9]/.test(ch)) { let j = i; while (j < src.length && /[0-9.]/.test(src[j])) j++; if (src[j - 1] === '.') j--; toks.push({ t: 'num', v: src.slice(i, j) }); i = j; continue; }
    toks.push({ t: 'ch', v: ch }); i++;
  }
  return toks;
}

class LP {
  constructor(toks, warnings) { this.t = toks; this.i = 0; this.w = warnings; }
  peek(k = 0) { return this.t[this.i + k] || { t: 'eof', v: '' }; }
  next() { return this.t[this.i++] || { t: 'eof', v: '' }; }
  // parse items until '}' / end / &, \\ handled by caller via stop set
  parseSeq(stop) {
    const items = [];
    for (;;) {
      const tok = this.peek();
      if (tok.t === 'eof') break;
      if (tok.t === '}' ) break;
      if (tok.t === 'end') break;
      if (stop && stop(tok)) break;
      if (tok.t === '&') { this.next(); items.push({ t: 'amp' }); continue; }
      if (tok.t === 'cmd' && tok.v === '\\\\') { this.next(); items.push({ t: 'newrow' }); continue; }
      if (tok.t === 'cmd' && tok.v === '\\right') break;
      const it = this.parseItem();
      if (it) items.push(it);
    }
    return { t: 'seq', items };
  }
  parseArg() {
    const tok = this.peek();
    if (tok.t === '{') { this.next(); const s = this.parseSeq(); if (this.peek().t === '}') this.next(); return s; }
    const it = this.parseAtom();
    return it || { t: 'seq', items: [] };
  }
  parseOptArg() {
    if (this.peek().t === 'ch' && this.peek().v === '[') {
      this.next();
      const s = this.parseSeq((tk) => tk.t === 'ch' && tk.v === ']');
      if (this.peek().t === 'ch' && this.peek().v === ']') this.next();
      return s;
    }
    return null;
  }
  parseItem() {
    let base = this.parseAtom();
    if (!base) return null;
    let sub = null, sup = null, limits = null;
    for (;;) {
      const tok = this.peek();
      if (tok.t === '^') { this.next(); sup = this.parseArg(); continue; }
      if (tok.t === '_') { this.next(); sub = this.parseArg(); continue; }
      if (tok.t === 'cmd' && (tok.v === '\\limits' || tok.v === '\\nolimits')) { this.next(); limits = tok.v === '\\limits'; continue; }
      break;
    }
    if (sub === null && sup === null) return base;
    return { t: 'script', base, sub, sup, limits };
  }
  parseAtom() {
    const tok = this.next();
    switch (tok.t) {
      case 'eof': return null;
      case '{': { const s = this.parseSeq(); if (this.peek().t === '}') this.next(); return { t: 'group', body: s }; }
      case '}': return null;
      case 'num': return { t: 'sym', v: tok.v };
      case 'ch': return { t: 'sym', v: tok.v };
      case '^': case '_': { this.i--; return { t: 'sym', v: '' }; } // dangling script -> empty base handled by caller
      case 'begin': return this.parseEnv(tok.v);
      case 'end': return null;
      case 'cmd': return this.parseCmd(tok.v);
    }
    return null;
  }
  parseEnv(name) {
    const rows = [[]];
    let cur = [];
    const body = this.parseSeq();
    for (const it of body.items) {
      if (it.t === 'amp') { rows[rows.length - 1].push({ t: 'seq', items: cur }); cur = []; }
      else if (it.t === 'newrow') { rows[rows.length - 1].push({ t: 'seq', items: cur }); cur = []; rows.push([]); }
      else cur.push(it);
    }
    rows[rows.length - 1].push({ t: 'seq', items: cur });
    if (this.peek().t === 'end') this.next();
    if (rows.length > 1 && rows[rows.length - 1].every(c => !c.items.length)) rows.pop();
    return { t: 'env', name, rows };
  }
  parseCmd(cmd) {
    switch (cmd) {
      case '\\frac': case '\\dfrac': case '\\tfrac': case '\\cfrac': { const a = this.parseArg(); const b = this.parseArg(); return { t: 'frac', num: a, den: b }; }
      case '\\binom': case '\\dbinom': case '\\tbinom': { const a = this.parseArg(); const b = this.parseArg(); return { t: 'binom', a, b }; }
      case '\\sqrt': { const idx = this.parseOptArg(); const body = this.parseArg(); return { t: 'sqrt', body, idx }; }
      case '\\text': case '\\textnormal': case '\\mbox': case '\\textbf': case '\\textit': case '\\mathtext': { const s = this.rawGroup(); return { t: 'text', v: s }; }
      case '\\left': {
        const l = this.readDelim();
        const body = this.parseSeq();
        let r = '';
        if (this.peek().t === 'cmd' && this.peek().v === '\\right') { this.next(); r = this.readDelim(); }
        return { t: 'fence', left: l, right: r, body };
      }
      case '\\right': return null;
      case '\\boxed': return { t: 'boxed', body: this.parseArg() };
      case '\\overbrace': case '\\underbrace': {
        const body = this.parseArg();
        let label = null;
        const tok = this.peek();
        if ((cmd === '\\overbrace' && tok.t === '^') || (cmd === '\\underbrace' && tok.t === '_')) { this.next(); label = this.parseArg(); }
        return { t: 'brace', over: cmd === '\\overbrace', body, label };
      }
      case '\\overset': case '\\stackrel': { const over = this.parseArg(); const base = this.parseArg(); return { t: 'stack', over, under: null, base }; }
      case '\\underset': { const under = this.parseArg(); const base = this.parseArg(); return { t: 'stack', over: null, under, base }; }
      case '\\genfrac': { this.parseArg(); this.parseArg(); this.parseArg(); this.parseArg(); const a = this.parseArg(); const b = this.parseArg(); return { t: 'frac', num: a, den: b, atop: true }; }
      case '\\,': case '\\:': case '\\;': case '\\!': case '\\ ': case '\\quad': case '\\qquad': case '\\thinspace': case '\\enspace': return { t: 'space', v: cmd };
      case '\\displaystyle': case '\\textstyle': case '\\scriptstyle': case '\\scriptscriptstyle': case '\\nonumber': case '\\notag': case '\\mathstrut': case '\\strut': case '\\allowbreak': case '\\relax': case '\\displaylimits': return null;
      case '\\phantom': case '\\hphantom': case '\\vphantom': { this.parseArg(); return null; }
      case '\\not': { const a = this.parseAtom(); return { t: 'seq', items: [{ t: 'cmd', v: '\\not' }, a].filter(Boolean) }; }
      case '\\operatorname': { const s = this.rawGroup(); return { t: 'op', v: s }; }
      case '\\substack': { const body = this.parseArg(); return { t: 'env', name: 'substack', rows: splitRows(body) }; }
      case '\\hspace': case '\\vspace': case '\\hskip': case '\\kern': { this.parseArg(); return { t: 'space', v: '\\ ' }; }
      case '\\color': case '\\textcolor': { this.parseArg(); return null; }
      case '\\mathchoice': { const a = this.parseArg(); this.parseArg(); this.parseArg(); this.parseArg(); return a; }
      case '\\pmod': { const a = this.parseArg(); return { t: 'seq', items: [{ t: 'sym', v: '(' }, { t: 'op', v: 'mod' }, { t: 'space', v: '\\ ' }, a, { t: 'sym', v: ')' }] }; }
      case '\\mod': { return { t: 'op', v: 'mod' }; }
      case '\\big': case '\\Big': case '\\bigg': case '\\Bigg': case '\\bigl': case '\\bigr': case '\\Bigl': case '\\Bigr': case '\\biggl': case '\\biggr': case '\\Biggl': case '\\Biggr': return null;
    }
    if (Object.hasOwn(ACCENTS, cmd)) return { t: 'accent', name: ACCENTS[cmd], body: this.parseArg() };
    if (Object.hasOwn(FONTS, cmd)) { const style = FONTS[cmd]; if (style === 'op') return { t: 'op', v: this.rawGroup() }; return { t: 'font', style, body: this.parseArg() }; }
    if (OPNAMES.has(cmd)) return { t: 'op', v: LATEX_UNICODE.get(cmd) };
    if (BIGOPS.has(cmd) || LATEX_UNICODE.has(cmd)) return { t: 'cmd', v: cmd };
    if (cmd === '\\\\') return { t: 'newrow' };
    this.w.push(`알 수 없는 LaTeX 명령 ${cmd}`);
    return { t: 'text', v: cmd.slice(1) };
  }
  readDelim() {
    const tok = this.next();
    if (tok.t === 'cmd') return DELIMS[tok.v] ?? tok.v.slice(1);
    if (tok.t === 'ch') return DELIMS[tok.v] ?? tok.v;
    if (tok.t === '{') return '{';
    return '';
  }
  rawGroup() {
    // read a brace group as raw text (for \text{})
    if (this.peek().t !== '{') { const a = this.next(); return a.v || ''; }
    this.next();
    let depth = 1, s = '';
    while (this.i < this.t.length) {
      const tok = this.next();
      if (tok.t === '{') { depth++; s += '{'; continue; }
      if (tok.t === '}') { depth--; if (depth === 0) break; s += '}'; continue; }
      if (tok.t === 'cmd') { s += LATEX_UNICODE.get(tok.v) ?? (tok.v.length === 2 ? tok.v[1] : tok.v); continue; }
      const prev = s[s.length - 1];
      if (s && /[A-Za-z0-9가-힣]/.test(prev) && /[A-Za-z0-9가-힣]/.test(tok.v[0])) s += ' ';
      s += tok.v;
    }
    return s;
  }
}
function splitRows(seq) {
  const rows = [[]]; let cur = [];
  for (const it of seq.items) { if (it.t === 'newrow') { rows[rows.length - 1].push({ t: 'seq', items: cur }); cur = []; rows.push([]); } else if (it.t === 'amp') { rows[rows.length - 1].push({ t: 'seq', items: cur }); cur = []; } else cur.push(it); }
  rows[rows.length - 1].push({ t: 'seq', items: cur });
  return rows;
}

export function parseLatexMath(src) {
  const warnings = [];
  const p = new LP(tokenizeLatex(src), warnings);
  let ast = p.parseSeq();
  // top-level rows (\\ or &) -> env
  if (ast.items.some(i => i.t === 'newrow' || i.t === 'amp')) ast = { t: 'env', name: ast.items.some(i => i.t === 'amp') ? 'aligned' : 'gathered', rows: splitRows(ast) };
  return { ast, warnings };
}

// ---------- AST -> Hancom script ----------
const HANCOM_ENV = { pmatrix: 'pmatrix', bmatrix: 'bmatrix', vmatrix: 'dmatrix', Vmatrix: 'dmatrix', matrix: 'matrix', smallmatrix: 'matrix', cases: 'cases', aligned: 'eqalign', align: 'eqalign', alignat: 'eqalign', gathered: 'pile', gather: 'pile', array: 'matrix', substack: 'pile', split: 'eqalign', multline: 'pile', eqnarray: 'eqalign' };
const HANCOM_FENCE = { '(': '(', ')': ')', '[': '[', ']': ']', '{': '{', '}': '}', '|': '|', '‖': '||', '〈': '<', '〉': '>', '⌊': 'lfloor', '⌋': 'rfloor', '⌈': 'lceil', '⌉': 'rceil', '': '', '/': '/' };
export function astToHancom(node, w = []) {
  const H = (n) => astToHancom(n, w);
  const grp = (n) => { const s = H(n).trim(); return `{${s}}`; };
  if (!node) return '';
  switch (node.t) {
    case 'seq': {
      let out = '';
      for (const it of node.items) { const s = H(it); if (!s) continue; if (out && !/[\s{]$/.test(out) && !/^[\s}^_]/.test(s)) out += ' '; out += s; }
      return out;
    }
    case 'sym': return node.v;
    case 'num': return node.v;
    case 'cmd': {
      if (node.v === '\\not') return 'not';
      const h = LATEX_HANCOM.get(node.v); if (h !== undefined) return h;
      w.push(`한글 수식에 없는 기호 ${node.v}`); return node.v.slice(1);
    }
    case 'text': return `"${node.v.replace(/"/g, "'")}"`;
    case 'space': return node.v === '\\quad' ? '~~' : node.v === '\\qquad' ? '~~~' : node.v === '\\ ' || node.v === '\\enspace' ? '~' : node.v === '\\!' ? '' : '`';
    case 'frac': return node.atop ? `${grp(node.num)} atop ${grp(node.den)}` : `${grp(node.num)} over ${grp(node.den)}`;
    case 'binom': return `binom ${grp(node.a)} ${grp(node.b)}`;
    case 'sqrt': return node.idx ? `root ${grp(node.idx)} of ${grp(node.body)}` : `sqrt ${grp(node.body)}`;
    case 'group': return grp(node.body);
    case 'script': {
      const base = node.base;
      const isBig = base && base.t === 'cmd' && BIGOPS.has(base.v);
      const isLim = base && base.t === 'op' && /^(lim|max|min|sup|inf|lim sup|lim inf)$/.test(base.v);
      let s = H(base);
      if (isBig || isLim) {
        if (node.sub) s += ` from ${grp(node.sub)}`;
        if (node.sup) s += ` to ${grp(node.sup)}`;
        return s;
      }
      if (node.sub) s += ` _${grp(node.sub)}`;
      if (node.sup) s += ` ^${grp(node.sup)}`;
      return s;
    }
    case 'fence': {
      const l = HANCOM_FENCE[node.left] ?? node.left, r = HANCOM_FENCE[node.right] ?? node.right;
      return `LEFT ${l || '.'} ${H(node.body)} RIGHT ${r || '.'}`.replace(/LEFT \. /, 'LEFT . ').replace(/ RIGHT \.$/, ' RIGHT .');
    }
    case 'accent': {
      const m = { vec: 'vec', dyad: 'dyad', hat: 'hat', bar: 'bar', overline: 'bar', underline: 'under', tilde: 'tilde', dot: 'dot', ddot: 'ddot', dddot: 'ddot', acute: 'acute', grave: 'grave', check: 'check', breve: 'arch', arch: 'arch' };
      return `${m[node.name] || 'bar'} ${grp(node.body)}`;
    }
    case 'env': {
      const name = HANCOM_ENV[node.name];
      if (!name) w.push(`지원하지 않는 환경 ${node.name} — matrix로 대체`);
      const body = node.rows.map(r => r.map(c => H(c).trim()).join(' & ')).join(' # ');
      return `${name || 'matrix'} {${body}}`;
    }
    case 'font': {
      const inner = H(node.body).trim();
      if (node.style === 'bf') return `bold ${inner.includes(' ') ? `{${inner}}` : inner}`;
      if (node.style === 'it') return `it {${inner}}`;
      return `rm ${inner.includes(' ') || inner.length > 1 ? `{${inner}}` : inner}`;
    }
    case 'op': return /^[a-z ]+$/i.test(node.v) ? (LATEX_HANCOM.get('\\' + node.v) || `rm "${node.v}"`).replace(/^rm "(sin|cos|tan|log|ln|lim|max|min|exp|sec|csc|cot|mod|gcd|det)"$/, '$1') : `"${node.v}"`;
    case 'boxed': return `BOX ${grp(node.body)}`;
    case 'brace': return `${node.over ? 'OVERBRACE' : 'UNDERBRACE'} ${grp(node.body)} ${node.label ? grp(node.label) : '{}'}`;
    case 'stack': { let s = H(node.base); if (node.under) s += ` from ${grp(node.under)}`; if (node.over) s += ` to ${grp(node.over)}`; return s; }
    case 'amp': return '&';
    case 'newrow': return '#';
  }
  return '';
}

export function latexToHancom(latex) {
  const { ast, warnings } = parseLatexMath(latex);
  const script = astToHancom(ast, warnings).replace(/\s+/g, ' ').trim();
  return { script, warnings };
}

// ---------- AST -> OMML ----------
const xe = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const mt = (s) => `<m:t xml:space="preserve">${xe(s)}</m:t>`;
const mr = (s, opts = {}) => {
  if (!s) return '';
  let rpr = '';
  if (opts.nor) rpr += '<m:nor/>';
  if (opts.sty) rpr += `<m:sty m:val="${opts.sty}"/>`;
  return `<m:r>${rpr ? `<m:rPr>${rpr}</m:rPr>` : ''}${mt(s)}</m:r>`;
};
const OMML_ENV_FENCE = { pmatrix: ['(', ')'], bmatrix: ['[', ']'], vmatrix: ['|', '|'], Vmatrix: ['‖', '‖'], matrix: ['', ''], smallmatrix: ['', ''], array: ['', ''] };
export function astToOmml(node, w = []) {
  const O = (n) => astToOmml(n, w);
  const E = (n) => `<m:e>${O(n)}</m:e>`;
  if (!node) return '';
  switch (node.t) {
    case 'seq': {
      // OMML operators own their operand; an empty m:e displays a placeholder in Word.
      let i = 0;
      const take = () => {
        const item = node.items[i++];
        const operator = item?.t === 'op' || (item?.t === 'script' && item.base?.t === 'cmd' && BIGOPS.has(item.base.v));
        if (!operator) return O(item);
        const spaces = [];
        while (node.items[i]?.t === 'space') spaces.push(node.items[i++]);
        const next = node.items[i];
        const boundary = !next || next.t === 'amp' || next.t === 'newrow' ||
          (next.t === 'sym' && /^[=+\-<>:,;]$/.test(next.v));
        if (boundary) return O(item) + spaces.map(O).join('');
        return astToOmml({ ...item, operandXml: spaces.map(O).join('') + take() }, w);
      };
      let result = '';
      while (i < node.items.length) result += take();
      return result;
    }
    case 'sym': return mr(node.v);
    case 'num': return mr(node.v);
    case 'cmd': { if (node.v === '\\not') return mr('̸'); const u = LATEX_UNICODE.get(node.v); if (u !== undefined) return mr(u); w.push(`Word 수식에 없는 기호 ${node.v}`); return mr(node.v.slice(1)); }
    case 'text': return mr(node.v, { nor: true });
    case 'space': {
      const spaces = { '\\quad': '\u2003', '\\qquad': '\u2003\u2003', '\\,': '\u2006', '\\thinspace': '\u2006', '\\:': '\u2005', '\\;': '\u2004', '\\enspace': '\u2002', '\\ ': ' ' };
      if (node.v === '\\!') { w.push('Word 수식에서 음수 간격 \\!은 보존되지 않습니다.'); return ''; }
      return mr(spaces[node.v] ?? ' ');
    }
    case 'frac': return `<m:f>${node.atop ? '<m:fPr><m:type m:val="noBar"/></m:fPr>' : ''}<m:num>${O(node.num)}</m:num><m:den>${O(node.den)}</m:den></m:f>`;
    case 'binom': return `<m:d><m:e><m:f><m:fPr><m:type m:val="noBar"/></m:fPr><m:num>${O(node.a)}</m:num><m:den>${O(node.b)}</m:den></m:f></m:e></m:d>`;
    case 'sqrt': return `<m:rad>${node.idx ? `<m:deg>${O(node.idx)}</m:deg>` : '<m:radPr><m:degHide m:val="1"/></m:radPr><m:deg/>'}${E(node.body)}</m:rad>`;
    case 'group': return O(node.body);
    case 'script': {
      const base = node.base;
      const isBig = base && base.t === 'cmd' && BIGOPS.has(base.v);
      const isLim = base && base.t === 'op' && /^(lim|max|min|sup|inf|lim sup|lim inf)$/.test(base.v);
      if (isBig && node.operandXml !== undefined) {
        const chr = LATEX_UNICODE.get(base.v);
        const limLoc = node.limits === false || /\\int|\\oint|\\iint|\\iiint/.test(base.v) && node.limits !== true ? 'subSup' : 'undOvr';
        return `<m:nary><m:naryPr><m:chr m:val="${chr}"/><m:limLoc m:val="${limLoc}"/>${node.sub ? '' : '<m:subHide m:val="1"/>'}${node.sup ? '' : '<m:supHide m:val="1"/>'}</m:naryPr><m:sub>${node.sub ? O(node.sub) : ''}</m:sub><m:sup>${node.sup ? O(node.sup) : ''}</m:sup><m:e>${node.operandXml}</m:e></m:nary>`;
      }
      if (isLim && node.sub && !node.sup) return `<m:limLow><m:e>${mr(base.v, { sty: 'p' })}</m:e><m:lim>${O(node.sub)}</m:lim></m:limLow>`;
      const b = base && base.t === 'sym' && base.v === '' ? '' : O(base);
      if (node.sub && node.sup) return `<m:sSubSup><m:e>${b}</m:e><m:sub>${O(node.sub)}</m:sub><m:sup>${O(node.sup)}</m:sup></m:sSubSup>`;
      if (node.sub) return `<m:sSub><m:e>${b}</m:e><m:sub>${O(node.sub)}</m:sub></m:sSub>`;
      return `<m:sSup><m:e>${b}</m:e><m:sup>${O(node.sup)}</m:sup></m:sSup>`;
    }
    case 'fence': return `<m:d><m:dPr><m:begChr m:val="${xe(node.left)}"/><m:endChr m:val="${xe(node.right)}"/></m:dPr>${E(node.body)}</m:d>`;
    case 'accent': {
      const chr = { vec: '⃗', dyad: '⃡', hat: '̂', tilde: '̃', dot: '̇', ddot: '̈', dddot: '⃛', acute: '́', grave: '̀', check: '̌', breve: '̆', arch: '̑' }[node.name];
      if (node.name === 'bar' || node.name === 'overline') return `<m:bar><m:barPr><m:pos m:val="top"/></m:barPr>${E(node.body)}</m:bar>`;
      if (node.name === 'underline') return `<m:bar><m:barPr><m:pos m:val="bot"/></m:barPr>${E(node.body)}</m:bar>`;
      return `<m:acc><m:accPr><m:chr m:val="${chr || '̂'}"/></m:accPr>${E(node.body)}</m:acc>`;
    }
    case 'env': {
      const rows = node.rows;
      if (OMML_ENV_FENCE[node.name]) {
        const [l, r] = OMML_ENV_FENCE[node.name];
        const cols = Math.max(...rows.map(x => x.length));
        const m = `<m:m><m:mPr><m:mcs><m:mc><m:mcPr><m:count m:val="${cols}"/><m:mcJc m:val="center"/></m:mcPr></m:mc></m:mcs></m:mPr>${rows.map(r => `<m:mr>${Array.from({ length: cols }, (_, i) => `<m:e>${r[i] ? O(r[i]) : ''}</m:e>`).join('')}</m:mr>`).join('')}</m:m>`;
        return l ? `<m:d><m:dPr><m:begChr m:val="${l}"/><m:endChr m:val="${r}"/></m:dPr><m:e>${m}</m:e></m:d>` : m;
      }
      const eq = `<m:eqArr>${rows.map(r => `<m:e>${r.map((c, i) => (i ? mr('&') : '') + O(c)).join('')}</m:e>`).join('')}</m:eqArr>`;
      if (node.name === 'cases') return `<m:d><m:dPr><m:begChr m:val="{"/><m:endChr m:val=""/></m:dPr><m:e>${eq}</m:e></m:d>`;
      return eq;
    }
    case 'font': {
      const text = plainText(node.body);
      if (text !== null) {
        if (node.style === 'bf') return mr(text, { sty: 'b' });
        if (node.style === 'it') return mr(text, { sty: 'i' });
        if (node.style === 'bb') return mr([...text].map(doubleStruck).join(''), { sty: 'p' });
        return mr(text, { sty: 'p' });
      }
      return O(node.body);
    }
    case 'op': return node.operandXml === undefined ? mr(node.v, { sty: 'p' }) : `<m:func><m:fName>${mr(node.v, { sty: 'p' })}</m:fName><m:e>${node.operandXml}</m:e></m:func>`;
    case 'boxed': return `<m:borderBox>${E(node.body)}</m:borderBox>`;
    case 'brace': {
      const inner = `<m:groupChr><m:groupChrPr><m:chr m:val="${node.over ? '⏞' : '⏟'}"/><m:pos m:val="${node.over ? 'top' : 'bot'}"/>${node.over ? '<m:vertJc m:val="bot"/>' : ''}</m:groupChrPr>${E(node.body)}</m:groupChr>`;
      if (!node.label) return inner;
      return node.over ? `<m:limUpp><m:e>${inner}</m:e><m:lim>${O(node.label)}</m:lim></m:limUpp>` : `<m:limLow><m:e>${inner}</m:e><m:lim>${O(node.label)}</m:lim></m:limLow>`;
    }
    case 'stack': {
      let s = O(node.base);
      if (node.under) s = `<m:limLow><m:e>${s}</m:e><m:lim>${O(node.under)}</m:lim></m:limLow>`;
      if (node.over) s = `<m:limUpp><m:e>${s}</m:e><m:lim>${O(node.over)}</m:lim></m:limUpp>`;
      return s;
    }
    case 'amp': return mr('&');
    case 'newrow': return '';
  }
  return '';
}
function plainText(node) {
  if (!node) return '';
  if (node.t === 'seq') { let s = ''; for (const it of node.items) { const p = plainText(it); if (p === null) return null; s += p; } return s; }
  if (node.t === 'sym' || node.t === 'text') return node.v;
  if (node.t === 'cmd') return LATEX_UNICODE.get(node.v) ?? null;
  if (node.t === 'group') return plainText(node.body);
  if (node.t === 'space') return ' ';
  return null;
}
function doubleStruck(c) {
  const code = c.charCodeAt(0);
  const special = { C: 'ℂ', H: 'ℍ', N: 'ℕ', P: 'ℙ', Q: 'ℚ', R: 'ℝ', Z: 'ℤ' };
  if (special[c]) return special[c];
  if (code >= 65 && code <= 90) return String.fromCodePoint(0x1d538 + code - 65);
  if (code >= 97 && code <= 122) return String.fromCodePoint(0x1d552 + code - 97);
  return c;
}

export function latexToOmml(latex) {
  const { ast, warnings } = parseLatexMath(latex);
  const body = astToOmml(ast, warnings);
  return { omml: `<m:oMath>${body}</m:oMath>`, warnings };
}

// ---------- OMML (DOM) -> LaTeX ----------
const local = (el) => (el.localName || el.nodeName || '').replace(/^[^:]+:/, '');
const kids = (el) => { const out = []; const k = el.childNodes || []; for (let i = 0; i < k.length; i++) if (k[i].nodeType === 1) out.push(k[i]); return out; };
const kid = (el, name) => kids(el).find(c => local(c) === name) || null;
const val = (el, path) => { let cur = el; for (const p of path) { cur = cur && kid(cur, p); } return cur ? (cur.getAttribute('m:val') ?? cur.getAttribute('val') ?? cur.getAttributeNS?.('http://schemas.openxmlformats.org/officeDocument/2006/math', 'val') ?? '') : null; };
const NARY = { '∑': '\\sum', '∏': '\\prod', '∐': '\\coprod', '∫': '\\int', '∬': '\\iint', '∭': '\\iiint', '∮': '\\oint', '⋃': '\\bigcup', '⋂': '\\bigcap', '⨁': '\\bigoplus', '⨂': '\\bigotimes', '': '\\int' };
const ACC = { '⃗': '\\vec', '⃡': '\\overleftrightarrow', '̂': '\\hat', '̃': '\\tilde', '̇': '\\dot', '̈': '\\ddot', '⃛': '\\dddot', '́': '\\acute', '̀': '\\grave', '̌': '\\check', '̆': '\\breve', '̄': '\\bar', '̅': '\\overline', '': '\\hat' };
const FENCE_L = { '(': '(', '[': '[', '{': '\\{', '|': '|', '‖': '\\|', '〈': '\\langle', '⟨': '\\langle', '⌊': '\\lfloor', '⌈': '\\lceil', '': '.' };
const FENCE_R = { ')': ')', ']': ']', '}': '\\}', '|': '|', '‖': '\\|', '〉': '\\rangle', '⟩': '\\rangle', '⌋': '\\rfloor', '⌉': '\\rceil', '': '.' };
export function ommlToLatex(el, w = []) {
  const L = (n) => ommlToLatex(n, w);
  const E = (n, name = 'e') => { const k = kid(n, name); return k ? L(k) : ''; };
  const t = local(el);
  switch (t) {
    case 'oMath': case 'oMathPara': case 'e': case 'num': case 'den': case 'sub': case 'sup': case 'deg': case 'lim': case 'fName': case 'mr':
      return kids(el).map(L).join(t === 'mr' ? ' & ' : '');
    case 'r': {
      const texts = kids(el).filter(c => local(c) === 't').map(c => c.textContent).join('');
      const rpr = kid(el, 'rPr');
      const nor = rpr && kid(rpr, 'nor');
      const sty = rpr ? val(rpr, ['sty']) : null;
      if (nor) return `\\text{${texts.replace(/[\\{}$&#%_^~]/g, (c) => '\\' + c)}}`;
      let s = textToLatex(texts);
      const fn = texts.trim();
      if (sty === 'p' && OPNAMES.has('\\' + fn)) return '\\' + fn + ' ';
      if (sty === 'b') s = `\\mathbf{${s}}`; else if (sty === 'p' && /^[A-Za-z]+$/.test(texts)) s = `\\mathrm{${s}}`;
      if (/\\[A-Za-z]+$/.test(s)) s += ' ';
      return s;
    }
    case 'f': { const type = val(el, ['fPr', 'type']); if (type === 'noBar') return `\\genfrac{}{}{0pt}{}{${E(el, 'num')}}{${E(el, 'den')}}`; if (type === 'lin' || type === 'skw') return `${E(el, 'num')}/${E(el, 'den')}`; return `\\frac{${E(el, 'num')}}{${E(el, 'den')}}`; }
    case 'rad': { const hide = val(el, ['radPr', 'degHide']) === '1' || val(el, ['radPr', 'degHide']) === 'on'; const d = E(el, 'deg'); return hide || !d.trim() ? `\\sqrt{${E(el)}}` : `\\sqrt[${d}]{${E(el)}}`; }
    case 'sSup': return `{${E(el)}}^{${E(el, 'sup')}}`;
    case 'sSub': return `{${E(el)}}_{${E(el, 'sub')}}`;
    case 'sSubSup': return `{${E(el)}}_{${E(el, 'sub')}}^{${E(el, 'sup')}}`;
    case 'sPre': return `{}_{${E(el, 'sub')}}^{${E(el, 'sup')}}${E(el)}`;
    case 'd': {
      const pr = kid(el, 'dPr');
      const beg = pr && kid(pr, 'begChr') ? val(pr, ['begChr']) : '(';
      const end = pr && kid(pr, 'endChr') ? val(pr, ['endChr']) : ')';
      const sep = pr && kid(pr, 'sepChr') ? val(pr, ['sepChr']) : '|';
      const es = kids(el).filter(c => local(c) === 'e').map(L);
      const inner = es.join(` ${sep === '|' ? '\\middle|' : sep} `);
      const l = FENCE_L[beg] ?? beg, r = FENCE_R[end] ?? end;
      const grow = pr && val(pr, ['grow']);
      if ((grow === '0' || grow === 'false' || grow === 'off') && es.length === 1) {
        return `${l === '.' ? '' : l}${inner}${r === '.' ? '' : r}`;
      }
      return `\\left${l} ${inner} \\right${r}`;
    }
    case 'nary': {
      const chr = val(el, ['naryPr', 'chr']) ?? '∫';
      const op = NARY[chr] || `\\mathop{${chr}}`;
      const limLoc = val(el, ['naryPr', 'limLoc']);
      const subHide = val(el, ['naryPr', 'subHide']) === '1', supHide = val(el, ['naryPr', 'supHide']) === '1';
      let s = op;
      if (limLoc === 'undOvr' && /\\int|\\oint|\\iint/.test(op)) s += '\\limits';
      if (!subHide) { const v = E(el, 'sub'); if (v.trim()) s += `_{${v}}`; }
      if (!supHide) { const v = E(el, 'sup'); if (v.trim()) s += `^{${v}}`; }
      return s + ' ' + E(el);
    }
    case 'acc': { const chr = val(el, ['accPr', 'chr']) ?? '̂'; const cmd = ACC[chr] || '\\hat'; return `${cmd}{${E(el)}}`; }
    case 'bar': { const pos = val(el, ['barPr', 'pos']); return pos === 'bot' ? `\\underline{${E(el)}}` : `\\overline{${E(el)}}`; }
    case 'box': return E(el);
    case 'borderBox': return `\\boxed{${E(el)}}`;
    case 'groupChr': { const pos = val(el, ['groupChrPr', 'pos']); return pos === 'top' ? `\\overbrace{${E(el)}}` : `\\underbrace{${E(el)}}`; }
    case 'limLow': { const base = E(el).trim().replace(/^\\mathrm\{(lim|max|min|sup|inf)\}$/, '\\$1').replace(/^(lim|max|min|sup|inf)$/, '\\$1'); const lim = E(el, 'lim'); if (/\\underbrace/.test(base)) return `${base}_{${lim}}`; if (/^\\(lim|max|min|sup|inf)$/.test(base)) return `${base}_{${lim}} `; return `\\underset{${lim}}{${base}}`; }
    case 'limUpp': { const base = E(el); const lim = E(el, 'lim'); if (/\\overbrace/.test(base)) return `${base}^{${lim}}`; return `\\overset{${lim}}{${base}}`; }
    case 'func': { const name = E(el, 'fName').trim(); const arg = E(el); const cmd = /^\\?(sin|cos|tan|sec|csc|cot|arcsin|arccos|arctan|sinh|cosh|tanh|log|ln|lg|exp|lim|max|min|sup|inf|gcd|det|dim|ker|deg|arg|Pr)$/.exec(name.replace(/^\\mathrm\{(.*)\}$/, '$1')); return (cmd ? '\\' + cmd[1] : `\\operatorname{${name.replace(/^\\mathrm\{(.*)\}$/, '$1')}}`) + ' ' + arg; }
    case 'm': {
      const rows = kids(el).filter(c => local(c) === 'mr').map(r => kids(r).filter(c => local(c) === 'e').map(L).join(' & '));
      return `\\begin{matrix} ${rows.join(' \\\\ ')} \\end{matrix}`;
    }
    case 'eqArr': {
      const rows = kids(el).filter(c => local(c) === 'e').map(L).map(r => r.replace(/\\&/g, ' & '));
      const hasAmp = rows.some(r => r.includes('&'));
      return `\\begin{${hasAmp ? 'aligned' : 'gathered'}} ${rows.join(' \\\\ ')} \\end{${hasAmp ? 'aligned' : 'gathered'}}`;
    }
    case 'phant': return `\\phantom{${E(el)}}`;
    case 'ctrlPr': case 'rPr': case 'fPr': case 'radPr': case 'dPr': case 'naryPr': case 'accPr': case 'barPr': case 'mPr': case 'eqArrPr': case 'sSupPr': case 'sSubPr': case 'sSubSupPr': case 'groupChrPr': case 'limLowPr': case 'limUppPr': case 'funcPr': case 'boxPr': case 'borderBoxPr': case 'oMathParaPr': case 'argPr': case 'sPrePr':
      return '';
    default: return kids(el).map(L).join('');
  }
}
function textToLatex(s) {
  let out = '';
  for (const ch of s) {
    if (UNICODE_LATEX.has(ch)) out += UNICODE_LATEX.get(ch) + ' ';
    else if (ch === '\u2003') out += '\\quad ';
    else if (ch === '\u2002') out += '\\enspace ';
    else if (ch === '\u2006' || ch === '\u2009') out += '\\, ';
    else if (ch === '\u2005') out += '\\: ';
    else if (ch === '\u2004') out += '\\; ';
    else if (ch === ' ' || ch === '\u00a0') out += '\\ ';
    else if (/[\u2000-\u200b]/.test(ch)) out += '\\ ';
    else if ('{}$&#%_^~\\'.includes(ch)) out += '\\' + ch;
    else out += ch;
  }
  // (x)(y) stays as is; collapse "\\pi x" spacing issues handled by join
  return out.replace(/\\quad \\quad /g, '\\qquad ');
}

// cleanup of nested fences produced by Word: \left( \begin{matrix} ... matrix in parens -> pmatrix
export function tidyLatexFromOmml(s) {
  return s
    .replace(/\\left\( \\begin\{matrix\}(.*?)\\end\{matrix\} \\right\)/g, '\\begin{pmatrix}$1\\end{pmatrix}')
    .replace(/\\left\[ \\begin\{matrix\}(.*?)\\end\{matrix\} \\right\]/g, '\\begin{bmatrix}$1\\end{bmatrix}')
    .replace(/\\left\| \\begin\{matrix\}(.*?)\\end\{matrix\} \\right\|/g, '\\begin{vmatrix}$1\\end{vmatrix}')
    .replace(/\\left\\\{ \\begin\{(aligned|gathered|matrix)\}(.*?)\\end\{\1\} \\right\./g, '\\begin{cases}$2\\end{cases}')
    .replace(/\{(\\(?:lim|max|min|sup|inf)) \}_/g, '$1_')
    .replace(/\{\}\^/g, '^').replace(/\{\}_/g, '_')
    .replace(/\{([^{}\\])\}([_^])/g, '$1$2')
    .replace(/\s+/g, ' ').trim();
}
