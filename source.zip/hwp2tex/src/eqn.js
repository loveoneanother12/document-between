// Hancom equation script (HWP/HWPX <hp:script>) -> LaTeX
// Recursive-descent parser. Entry: hwpEqToLatex(script) -> { latex, warnings }

// ---------- symbol tables ----------
const SYM = {
  // operators / relations
  times: '\\times', cdot: '\\cdot', div: '\\div', divide: '\\div', pm: '\\pm', mp: '\\mp',
  '+-': '\\pm', '-+': '\\mp', '±': '\\pm', '÷': '\\div', '×': '\\times', '·': '\\cdot', '∙': '\\cdot',
  leq: '\\leq', le: '\\leq', geq: '\\geq', ge: '\\geq', neq: '\\neq', ne: '\\neq', '<=': '\\leq', '>=': '\\geq', '!=': '\\neq',
  '≤': '\\leq', '≥': '\\geq', '≠': '\\neq', '≒': '\\fallingdotseq', '≡': '\\equiv', '==': '\\equiv', '≈': '\\approx',
  '<<': '\\ll', '>>': '\\gg', '<<<': '\\lll', '>>>': '\\ggg',
  sim: '\\sim', approx: '\\approx', simeq: '\\simeq', cong: '\\cong', equiv: '\\equiv', propto: '\\propto', '∝': '\\propto',
  prec: '\\prec', succ: '\\succ', asymp: '\\asymp', doteq: '\\doteq', image: '\\fallingdotseq', reimage: '\\risingdotseq',
  iso: '\\Bumpeq', dsum: '\\dotplus', xor: '\\veebar',
  // sets / logic
  in: '\\in', notin: '\\notin', owns: '\\ni', ni: '\\ni', '∈': '\\in', '∉': '\\notin', '∋': '\\ni',
  subset: '\\subset', superset: '\\supset', supset: '\\supset', subseteq: '\\subseteq', supseteq: '\\supseteq', supsetEq: '\\supseteq',
  nsubset: '\\not\\subset', '⊂': '\\subset', '⊃': '\\supset', '⊆': '\\subseteq', '⊇': '\\supseteq',
  cup: '\\cup', cap: '\\cap', smallinter: '\\cap', smallunion: '\\cup', '∪': '\\cup', '∩': '\\cap',
  inter: '\\bigcap', union: '\\bigcup', bigcap: '\\bigcap', bigcup: '\\bigcup',
  sqcup: '\\sqcup', sqcap: '\\sqcap', sqsubset: '\\sqsubset', sqsubseteq: '\\sqsubseteq', bigsqcup: '\\bigsqcup',
  uplus: '\\uplus', emptyset: '\\emptyset', '∅': '\\emptyset', '∞': '\\infty',
  forall: '\\forall', exist: '\\exists', exists: '\\exists', '∀': '\\forall', '∃': '\\exists',
  lor: '\\lor', land: '\\land', lnot: '\\lnot', neg: '\\neg', vdash: '\\vdash', dashv: '\\dashv', models: '\\models',
  therefore: '\\therefore', because: '\\because', '∴': '\\therefore', '∵': '\\because',
  oplus: '\\oplus', ominus: '\\ominus', otimes: '\\otimes', odiv: '\\oslash', odot: '\\odot', '⊕': '\\oplus', '⊗': '\\otimes',
  bigoplus: '\\bigoplus', bigotimes: '\\bigotimes', bigodot: '\\bigodot', biguplus: '\\biguplus',
  bigominus: '{\\Large\\ominus}', bigodiv: '{\\Large\\oslash}',
  // misc symbols
  inf: '\\infty', infty: '\\infty', infinity: '\\infty', partial: '\\partial', nabla: '\\nabla', '∂': '\\partial', '∇': '\\nabla',
  angle: '\\angle', msangle: '\\measuredangle', sangle: '\\sphericalangle', '∠': '\\angle',
  triangle: '\\triangle', '△': '\\triangle', '▲': '\\blacktriangle', square: '\\square', '□': '\\square', '■': '\\blacksquare',
  bot: '\\perp', perp: '\\perp', '⊥': '\\perp', parallel: '\\parallel', '∥': '\\parallel', '//': '\\parallel',
  circ: '\\circ', bullet: '\\bullet', ast: '\\ast', star: '\\star', bigcirc: '\\bigcirc', '°': '^{\\circ}', '∘': '\\circ', '○': '\\bigcirc', '●': '\\bullet',
  deg: '^{\\circ}', degree: '^{\\circ}', centigrade: '^{\\circ}\\mathrm{C}', fahrenheit: '^{\\circ}\\mathrm{F}',
  cdots: '\\cdots', ldots: '\\ldots', vdots: '\\vdots', ddots: '\\ddots', dots: '\\cdots', '…': '\\cdots', '⋯': '\\cdots', '⋮': '\\vdots', '⋱': '\\ddots',
  dagger: '\\dagger', ddagger: '\\ddagger', diamond: '\\diamond', hbar: '\\hbar', aleph: '\\aleph',
  laplace: '\\mathcal{L}', lslant: '\\diagup', rslant: '\\diagdown',
  pver: '\\|', mapsto: '\\mapsto', '→': '\\rightarrow', '←': '\\leftarrow', '↔': '\\leftrightarrow', '⇒': '\\Rightarrow', '⇐': '\\Leftarrow', '⇔': '\\Leftrightarrow', '↑': '\\uparrow', '↓': '\\downarrow',
  rarrow: '\\rightarrow', larrow: '\\leftarrow', rightarrow: '\\rightarrow', leftarrow: '\\leftarrow', '->': '\\rightarrow', '<-': '\\leftarrow', '<->': '\\leftrightarrow',
  uparrow: '\\uparrow', downarrow: '\\downarrow', udarrow: '\\updownarrow', lrarrow: '\\leftrightarrow',
  RARROW: '\\Rightarrow', LARROW: '\\Leftarrow', UPARROW: '\\Uparrow', DOWNARROW: '\\Downarrow', UDARROW: '\\Updownarrow', LRARROW: '\\Leftrightarrow',
  nwarrow: '\\nwarrow', nearrow: '\\nearrow', swarrow: '\\swarrow', searrow: '\\searrow', hookleft: '\\hookleftarrow', hookright: '\\hookrightarrow',
  // big operators
  sum: '\\sum', smallsum: '\\sum', prod: '\\prod', smallprod: '\\prod', coprod: '\\coprod', smcoprod: '\\coprod',
  int: '\\int', dint: '\\iint', tint: '\\iiint', oint: '\\oint', odint: '\\oiint', otint: '\\oiiint', smallint: '\\smallint', '∫': '\\int', '∑': '\\sum', '∏': '\\prod',
  // greek
  alpha: '\\alpha', beta: '\\beta', gamma: '\\gamma', delta: '\\delta', epsilon: '\\epsilon', varepsilon: '\\varepsilon', zeta: '\\zeta', eta: '\\eta', theta: '\\theta', vartheta: '\\vartheta',
  iota: '\\iota', kappa: '\\kappa', lambda: '\\lambda', mu: '\\mu', nu: '\\nu', xi: '\\xi', omicron: 'o', pi: '\\pi', varpi: '\\varpi', rho: '\\rho', varrho: '\\varrho',
  sigma: '\\sigma', varsigma: '\\varsigma', tau: '\\tau', upsilon: '\\upsilon', phi: '\\phi', varphi: '\\varphi', chi: '\\chi', psi: '\\psi', omega: '\\omega',
  ALPHA: 'A', BETA: 'B', GAMMA: '\\Gamma', DELTA: '\\Delta', EPSILON: 'E', ZETA: 'Z', ETA: 'H', THETA: '\\Theta', IOTA: 'I', KAPPA: 'K', LAMBDA: '\\Lambda', MU: 'M',
  NU: 'N', XI: '\\Xi', OMICRON: 'O', PI: '\\Pi', RHO: 'P', SIGMA: '\\Sigma', TAU: 'T', UPSILON: '\\Upsilon', PHI: '\\Phi', CHI: 'X', PSI: '\\Psi', OMEGA: '\\Omega',
  'α': '\\alpha', 'β': '\\beta', 'γ': '\\gamma', 'δ': '\\delta', 'ε': '\\varepsilon', 'ζ': '\\zeta', 'η': '\\eta', 'θ': '\\theta', 'ι': '\\iota', 'κ': '\\kappa', 'λ': '\\lambda', 'μ': '\\mu',
  'ν': '\\nu', 'ξ': '\\xi', 'π': '\\pi', 'ρ': '\\rho', 'σ': '\\sigma', 'τ': '\\tau', 'υ': '\\upsilon', 'φ': '\\varphi', 'χ': '\\chi', 'ψ': '\\psi', 'ω': '\\omega',
  'Γ': '\\Gamma', 'Δ': '\\Delta', 'Θ': '\\Theta', 'Λ': '\\Lambda', 'Ξ': '\\Xi', 'Π': '\\Pi', 'Σ': '\\Sigma', 'Φ': '\\Phi', 'Ψ': '\\Psi', 'Ω': '\\Omega',
  // functions (operator names)
  sin: '\\sin', cos: '\\cos', tan: '\\tan', sec: '\\sec', csc: '\\csc', cot: '\\cot', cosec: '\\csc',
  arcsin: '\\arcsin', arccos: '\\arccos', arctan: '\\arctan', sinh: '\\sinh', cosh: '\\cosh', tanh: '\\tanh', coth: '\\coth',
  log: '\\log', ln: '\\ln', lg: '\\lg', exp: '\\exp', lim: '\\lim', Lim: '\\lim', max: '\\max', min: '\\min', 
  gcd: '\\gcd', det: '\\det', Pr: '\\Pr', mod: '\\bmod', pmod: '\\pmod',
  limsup: '\\limsup', liminf: '\\liminf',
  // brackets as symbols
  '⌈': '\\lceil', '⌉': '\\rceil', '⌊': '\\lfloor', '⌋': '\\rfloor', lceil: '\\lceil', rceil: '\\rceil', lfloor: '\\lfloor', rfloor: '\\rfloor',
  langle: '\\langle', rangle: '\\rangle', lbrace: '\\{', rbrace: '\\}', vert: '|', Vert: '\\|', '〈': '\\langle', '〉': '\\rangle',
  // hancom PUA (supplementary) symbols seen in the wild
  '\u{F0040}': '\\equiv',
  // misc
  prime: "'", '′': "'", '″': "''", '%': '\\%', '‰': '\\permil', '$': '\\$', '&amp;': '\\&', '#': '\\#',
  hund: '\\permil', att: '\\text{※}', '※': '\\text{※}',
  rtangle: '\\mathrm{⊾}', benzene: '\\mathrm{⌬}',
};

// structural keywords (case-insensitive)
const STRUCT = new Set(['over', 'atop', 'sqrt', 'root', 'of', 'left', 'right', 'from', 'to', 'rm', 'it', 'bold', 'sans', 'bf',
  'binom', 'choose', 'matrix', 'pmatrix', 'bmatrix', 'dmatrix', 'vmatrix', 'cases', 'eqalign', 'pile', 'lpile', 'rpile', 'cpile', 'col', 'ccol', 'lcol', 'rcol',
  'vec', 'dyad', 'acute', 'grave', 'dot', 'ddot', 'dddot', 'bar', 'hat', 'check', 'arch', 'tilde', 'under', 'underline', 'overline', 'box', 'overbrace', 'underbrace', 'not', 'frac', 'underover',
  'rel', 'bin', 'ord', 'opr', 'big', 'small', 'size', 'color', 'phantom', 'hleft', 'hright']);

const ACCENT = { vec: '\\overrightarrow', dyad: '\\overleftrightarrow', acute: '\\acute', grave: '\\grave', dot: '\\dot', ddot: '\\ddot', dddot: '\\dddot', bar: '\\overline', hat: '\\hat', check: '\\check', arch: '\\overset{\\frown}', tilde: '\\tilde', under: '\\underline', underline: '\\underline', overline: '\\overline', box: '\\boxed', not: '\\not' };
const WIDE = { hat: '\\widehat', tilde: '\\widetilde' };
const MATRIX = { matrix: 'matrix', pmatrix: 'pmatrix', bmatrix: 'bmatrix', dmatrix: 'vmatrix', vmatrix: 'vmatrix', cases: 'cases', eqalign: 'aligned', pile: 'gathered', cpile: 'gathered', lpile: 'aligned', rpile: 'aligned', col: 'gathered', ccol: 'gathered', lcol: 'aligned', rcol: 'aligned' };
const BIGOP_LIMITS = new Set(['\\sum', '\\prod', '\\coprod', '\\bigcap', '\\bigcup', '\\bigsqcup', '\\bigoplus', '\\bigotimes', '\\bigodot', '\\biguplus']);
const OPNAMES = new Set(['\\lim', '\\max', '\\min', '\\sup', '\\inf', '\\limsup', '\\liminf', '\\gcd', '\\det', '\\Pr']);
const DELIM = { '(': '(', ')': ')', '[': '[', ']': ']', '{': '\\{', '}': '\\}', '|': '|', '||': '\\|', '<': '\\langle', '>': '\\rangle', '.': '.', '⌈': '\\lceil', '⌉': '\\rceil', '⌊': '\\lfloor', '⌋': '\\rfloor', '〈': '\\langle', '〉': '\\rangle', '/': '/' };
const DELIM_WORDS = { lbrace: '\\{', rbrace: '\\}', langle: '\\langle', rangle: '\\rangle', lfloor: '\\lfloor', rfloor: '\\rfloor', lceil: '\\lceil', rceil: '\\rceil', vert: '|', Vert: '\\|', none: '.' };

function lookupSym(w) {
  if (Object.hasOwn(SYM, w)) return SYM[w];
  const lw = w.toLowerCase();
  if (lw !== w && Object.hasOwn(SYM, lw) && !/^[A-Z]+$/.test(w)) return SYM[lw];
  // all-caps Hancom spellings: TIMES, LEQ, SMALLINTER, THEREFORE ... (but not uppercase Greek, handled above)
  if (/^[A-Z]+$/.test(w) && w.length >= 2 && Object.hasOwn(SYM, lw)) return SYM[lw];
  return null;
}
const isStruct = (w) => STRUCT.has(w.toLowerCase());
const isHangul = (ch) => /[ᄀ-ᇿ㄰-㆏가-힯]/.test(ch);
const isLetter = (ch) => /[A-Za-z]/.test(ch);
const isDigit = (ch) => /[0-9]/.test(ch);

// ---------- tokenizer ----------
function tokenize(src) {
  const toks = [];
  let i = 0;
  const n = src.length;
  const push = (type, value) => toks.push({ type, value });
  while (i < n) {
    const ch = src[i];
    if (/\s/.test(ch)) { i++; continue; }
    if (ch === '"') {
      let j = i + 1, s = '';
      while (j < n && src[j] !== '"') { s += src[j]; j++; }
      push('text', s); i = j + 1; continue;
    }
    if (isLetter(ch)) {
      let j = i; while (j < n && isLetter(src[j])) j++;
      push('word', src.slice(i, j)); i = j; continue;
    }
    if (isDigit(ch)) {
      let j = i; while (j < n && isDigit(src[j])) j++;
      if (src[j] === '.' && isDigit(src[j + 1] || '')) { j++; while (j < n && isDigit(src[j])) j++; }
      push('num', src.slice(i, j)); i = j; continue;
    }
    if (isHangul(ch)) {
      let j = i; while (j < n && (isHangul(src[j]) || src[j] === ' ' && j + 1 < n && isHangul(src[j + 1]))) j++;
      push('text', src.slice(i, j)); i = j; continue;
    }
    // multi-char operators
    const three = src.substr(i, 3), two = src.substr(i, 2);
    if (['<->', '<<<', '>>>', '...'].includes(three)) { push('op', three); i += 3; continue; }
    if (['+-', '-+', '<=', '>=', '!=', '->', '<-', '==', '<<', '>>', '||', '//'].includes(two)) { push('op', two); i += 2; continue; }
    if ('{}^_&#~`'.includes(ch)) { push(ch, ch); i++; continue; }
    // surrogate pairs (Hancom PUA-A symbols)
    const cp = src.codePointAt(i);
    if (cp > 0xffff) { push('sym', String.fromCodePoint(cp)); i += 2; continue; }
    push('op', ch); i++;
  }
  return toks;
}

// ---------- parser ----------
class P {
  constructor(toks, warnings) { this.t = toks; this.i = 0; this.w = warnings; this.leftDepth = 0; }
  peek(k = 0) { return this.t[this.i + k] || { type: 'eof', value: '' }; }
  next() { return this.t[this.i++] || { type: 'eof', value: '' }; }
  isWord(tok, ...names) { return tok.type === 'word' && names.includes(tok.value.toLowerCase()); }

  // Parse a sequence until '}' (consumed by caller) / RIGHT / eof. Returns rows: [[cellStr,...],...]
  parseSeq(stopAtRight = false) {
    const rows = [[]];
    let cell = [];          // output tokens of current cell
    let mode = null;        // 'rm' | 'bold' | null
    let modeBuf = null;     // tokens collected in rm/bold mode
    const endCell = () => { if (modeBuf) { flushMode(); } rows[rows.length - 1].push(cell.join(' ')); cell = []; };
    const flushMode = () => {
      if (modeBuf && modeBuf.length) cell.push((mode === 'bold' ? '\\mathbf{' : '\\mathrm{') + modeBuf.join(' ') + '}');
      modeBuf = null;
    };
    const emit = (s) => { if (modeBuf) modeBuf.push(s); else cell.push(s); };
    const popLast = () => {
      const src = (modeBuf && modeBuf.length) ? modeBuf : cell;
      if (modeBuf && !modeBuf.length) modeBuf = null;
      if (!src.length) return '';
      let out = src.pop();
      // n! , f' : postfix marks belong to the preceding item
      while (/^(!|'+)$/.test(out) && src.length) out = src.pop() + out;
      return out;
    };

    for (;;) {
      const tok = this.peek();
      if (tok.type === 'eof') break;
      if (tok.type === '}') break;
      if (stopAtRight && this.isWord(tok, 'right')) break;
      if (!stopAtRight && this.isWord(tok, 'right') && this.leftDepth === 0) {
        // stray RIGHT without LEFT: treat the delimiter as a plain symbol
        this.next();
        const d = this.readDelim();
        emit(d === '.' ? '' : d);
        continue;
      }
      if (tok.type === '&') { this.next(); endCell(); continue; }
      if (tok.type === '#') { this.next(); endCell(); rows.push([]); continue; }
      if (tok.type === 'word') {
        const lw = tok.value.toLowerCase();
        if (lw === 'over' || lw === 'atop' || lw === 'choose') {
          this.next();
          const num = popLast();
          const den = this.parseItem();
          const a = stripBraces(num), b = stripBraces(den);
          emit(lw === 'over' ? `\\frac{${a}}{${b}}` : lw === 'atop' ? `\\genfrac{}{}{0pt}{}{${a}}{${b}}` : `\\binom{${a}}{${b}}`);
          continue;
        }
        if (lw === 'rm' || lw === 'bold' || lw === 'bf') {
          this.next();
          if (this.peek().type === '{') { // rm{...}: applies to that group only
            const g = stripBraces(this.parseItem());
            emit((lw === 'rm' ? '\\mathrm{' : '\\mathbf{') + g + '}');
            continue;
          }
          flushMode(); mode = lw === 'rm' ? 'rm' : 'bold'; modeBuf = []; continue;
        }
        if (lw === 'it' || lw === 'sans') { this.next(); flushMode(); mode = null; continue; }
      }
      emit(this.parseItem());
    }
    endCell();
    return rows;
  }

  // item := term postfix*
  parseItem() {
    let base = this.parseTerm();
    let sub = null, sup = null, limits = false;
    for (;;) {
      const tok = this.peek();
      if (tok.type === '^') { this.next(); sup = this.parseArg(); continue; }
      if (tok.type === '_') { this.next(); sub = this.parseArg(); continue; }
      if (this.isWord(tok, 'from')) { this.next(); sub = this.parseArg(); limits = true; continue; }
      if (this.isWord(tok, 'to')) { this.next(); sup = this.parseArg(); limits = true; continue; }
      break;
    }
    if (sub === null && sup === null) return base;
    if (base === '') base = '{}';
    else if (/^(\\[,;! ]|\\q?quad)$/.test(base)) base = base + '{}';
    let out = base;
    if (limits && BIGOP_LIMITS.has(base)) out += '\\limits';
    else if (limits && !BIGOP_LIMITS.has(base) && !OPNAMES.has(base) && base !== '\\int' && !/^\\(iint|iiint|oint)/.test(base)) {
      // from/to on an ordinary symbol: stack under/over it
      if (sub !== null) out = `\\underset{${stripBraces(sub)}}{${out}}`;
      if (sup !== null) out = `\\overset{${stripBraces(sup)}}{${out}}`;
      return out;
    }
    if (sub !== null) out += `_{${stripBraces(sub)}}`;
    if (sup !== null) out += `^{${stripBraces(sup)}}`;
    return out;
  }

  parseArg() {
    const tok = this.peek();
    if (tok.type === '{') return this.parseGroup();
    if (tok.type === 'num') { this.next(); return tok.value; }
    return this.parseTerm();
  }

  parseGroup() {
    this.next(); // '{'
    const rows = this.parseSeq(false);
    if (this.peek().type === '}') this.next(); else this.w.push('닫는 중괄호가 없습니다');
    return '{' + joinRows(rows, null) + '}';
  }

  readDelim() {
    const tok = this.peek();
    if (tok.type === 'op' || tok.type === '{' || tok.type === '}') {
      if (Object.hasOwn(DELIM, tok.value)) { this.next(); return DELIM[tok.value]; }
    }
    if (tok.type === 'word' && Object.hasOwn(DELIM_WORDS, tok.value)) { this.next(); return DELIM_WORDS[tok.value]; }
    if (tok.type === 'sym' && Object.hasOwn(DELIM, tok.value)) { this.next(); return DELIM[tok.value]; }
    return '.';
  }

  parseTerm() {
    const tok = this.next();
    switch (tok.type) {
      case 'eof': return '';
      case '{': { this.i--; return this.parseGroup(); }
      case '}': return '';
      case 'num': return tok.value;
      case 'text': return `\\text{${escText(tok.value)}}`;
      case '~': { let k = 1; while (this.peek().type === '~') { this.next(); k++; } return k === 1 ? '\\ ' : k === 2 ? '\\quad' : '\\qquad'; }
      case '`': return '\\,';
      case '^': case '_': { this.i--; return ''; }
      case '&': case '#': return '';
      case 'sym': return lookupSym(tok.value) ?? (this.w.push(`알 수 없는 기호 U+${tok.value.codePointAt(0).toString(16).toUpperCase()}`), '\\text{?}');
      case 'op': return this.opToLatex(tok.value);
      case 'word': return this.wordToLatex(tok.value);
    }
    return '';
  }

  opToLatex(v) {
    if (Object.hasOwn(SYM, v)) return SYM[v];
    switch (v) {
      case '{': return '\\{'; case '}': return '\\}';
      case "'": return "'";
      case '...': return '\\cdots';
      case '\\': return '\\backslash';
      default: {
        const cp = v.codePointAt(0);
        if (cp >= 0xe000 && cp <= 0xf8ff) { this.w.push(`알 수 없는 기호 U+${cp.toString(16).toUpperCase()}`); return '\\text{?}'; }
        if (cp > 0x7f) {
          const m = lookupSym(v);
          if (m) return m;
          return `\\text{${v}}`;
        }
        return v;
      }
    }
  }

  wordToLatex(w) {
    const lw = w.toLowerCase();
    if (isStruct(w)) {
      switch (lw) {
        case 'sqrt': return `\\sqrt{${stripBraces(this.parseItemNoPost())}}`;
        case 'root': {
          const idx = this.parseItemNoPost();
          if (this.isWord(this.peek(), 'of')) this.next();
          const body = this.parseItemNoPost();
          return `\\sqrt[${stripBraces(idx)}]{${stripBraces(body)}}`;
        }
        case 'of': return '';
        case 'frac': { const a = this.parseItemNoPost(); const b = this.parseItemNoPost(); return `\\frac{${stripBraces(a)}}{${stripBraces(b)}}`; }
        case 'binom': { const a = this.parseItemNoPost(); const b = this.parseItemNoPost(); return `\\binom{${stripBraces(a)}}{${stripBraces(b)}}`; }
        case 'left': {
          const d = this.readDelim();
          this.leftDepth++;
          const rows = this.parseSeq(true);
          this.leftDepth--;
          let rd = '.';
          if (this.isWord(this.peek(), 'right')) { this.next(); rd = this.readDelim(); }
          else this.w.push('LEFT에 대응하는 RIGHT가 없습니다');
          return `\\left${d} ${joinRows(rows, null)} \\right${rd}`;
        }
        case 'right': { const d = this.readDelim(); return d === '.' ? '' : d; }
        case 'over': case 'atop': case 'choose': case 'from': case 'to': case 'rm': case 'it': case 'bold': case 'bf': case 'sans': return '';
        case 'overbrace': case 'underbrace': {
          const body = this.parseItemNoPost();
          const label = this.parseItemNoPost();
          return `\\${lw}{${stripBraces(body)}}${lw === 'overbrace' ? '^' : '_'}{${stripBraces(label)}}`;
        }
        case 'underover': return '';
        case 'phantom': return `\\phantom{${stripBraces(this.parseItemNoPost())}}`;
        case 'color': case 'size': { this.parseItemNoPost(); return ''; }
        case 'big': case 'small': case 'rel': case 'bin': case 'ord': case 'opr': case 'hleft': case 'hright': return '';
        default: {
          if (Object.hasOwn(MATRIX, lw)) {
            if (this.peek().type !== '{') return '';
            this.next();
            const rows = this.parseSeq(false);
            if (this.peek().type === '}') this.next();
            const env = MATRIX[lw];
            const body = rows.map(r => r.join(' & ')).join(' \\\\ ');
            return `\\begin{${env}} ${body} \\end{${env}}`;
          }
          if (Object.hasOwn(ACCENT, lw)) {
            const arg = stripBraces(this.parseItemNoPost());
            const cmd = (WIDE[lw] && arg.replace(/\\[a-z]+/g, 'x').length > 1) ? WIDE[lw] : ACCENT[lw];
            return `${cmd}{${arg}}`;
          }
          return '';
        }
      }
    }
    const m = lookupSym(w);
    if (m !== null) {
      // DEG written after a number: 45 DEG -> 45^{\circ}
      return m;
    }
    // plain identifier(s)
    return w;
  }

  // a single term with its own ^ _ scripts but not consumed by over
  parseItemNoPost() { return this.parseItem(); }
}

function escText(s) { return s.replace(/[\\{}$&#%_^~]/g, (c) => c === '\\' ? '\\textbackslash{}' : c === '~' ? '\\textasciitilde{}' : c === '^' ? '\\textasciicircum{}' : '\\' + c); }
function stripBraces(s) {
  s = (s || '').trim();
  if (s.startsWith('{') && s.endsWith('}')) {
    // ensure the outer braces match each other
    let d = 0;
    for (let i = 0; i < s.length; i++) {
      if (s[i] === '{') d++; else if (s[i] === '}') { d--; if (d === 0 && i < s.length - 1) return s; }
    }
    return s.slice(1, -1).trim();
  }
  return s;
}
function joinRows(rows, envIfMulti) {
  const nonEmptyRows = rows.filter((r, i) => i === 0 || r.some(c => c.trim()));
  const hasAmp = nonEmptyRows.some(r => r.length > 1);
  if (nonEmptyRows.length === 1 && !hasAmp) return nonEmptyRows[0][0] || '';
  const env = envIfMulti || (hasAmp ? 'aligned' : 'gathered');
  const body = nonEmptyRows.map(r => r.join(' & ')).join(' \\\\ ');
  return `\\begin{${env}} ${body} \\end{${env}}`;
}

function tidy(s) {
  return s
    .replace(/\s+/g, ' ')
    .replace(/\{ /g, '{').replace(/ \}/g, '}')
    .replace(/ ([_^])/g, '$1').replace(/([_^]) /g, '$1')
    .replace(/\( /g, '(').replace(/ \)/g, ')').replace(/\[ /g, '[').replace(/ \]/g, ']')
    .replace(/ ,/g, ',').replace(/ \./g, '.')
    .replace(/(?:(?:\\[,;!]|\\ |\\quad|\\qquad) +)+'/g, "'")
    .replace(/\\left\s*\\\{/g, '\\left\\{').replace(/\\right\s*\\\}/g, '\\right\\}')
    .replace(/\\(left|right)\s+([(\[|.)\]])/g, '\\$1$2')
    .replace(/\{\}/g, '{}')
    .trim();
}

export function hwpEqToLatex(script) {
  const warnings = [];
  const src = (script || '').replace(/\r?\n/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
  if (!src.trim()) return { latex: '', warnings };
  let latex;
  try {
    const p = new P(tokenize(src), warnings);
    const rows = p.parseSeq(false);
    if (p.peek().type === '}') warnings.push('짝이 맞지 않는 중괄호');
    latex = joinRows(rows, null);
  } catch (e) {
    warnings.push('수식 변환 실패: ' + e.message);
    latex = `\\text{${escText(src)}}`;
  }
  return { latex: tidy(latex), warnings };
}

export { tokenize as _tokenize };
