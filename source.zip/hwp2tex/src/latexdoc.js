// LaTeX document (subset) -> document model
// parseLatexDoc(texString, files: Map<path, Uint8Array>) -> { blocks, images, warnings }

const SKIP_CMDS = new Set(['documentclass', 'usepackage', 'geometry', 'setlength', 'renewcommand', 'newcommand', 'pagestyle', 'thispagestyle', 'label', 'vspace', 'hspace', 'vskip', 'hskip', 'noindent', 'indent', 'newpage', 'clearpage', 'pagebreak', 'linebreak', 'nopagebreak', 'bigskip', 'medskip', 'smallskip', 'theendnotes', 'maketitle', 'tableofcontents', 'centering', 'raggedright', 'raggedleft', 'hfill', 'vfill', 'hline', 'cline', 'toprule', 'midrule', 'bottomrule', 'arraybackslash', 'setcounter', 'addtocounter', 'protect', 'relax', 'linewidth', 'textwidth', 'columnwidth', 'baselineskip', 'strut', 'rule', 'date', 'author', 'selectfont', 'fontsize', 'setmainfont', 'setsansfont', 'setmonofont', 'input', 'include', 'bibliography', 'bibliographystyle', 'hyphenation', 'par', 'enlargethispage', 'phantom', 'hphantom', 'vphantom', 'nocite', 'index', 'footnotemark', 'footnotetext']);
const SIZE_CMDS = new Set(['tiny', 'scriptsize', 'footnotesize', 'small', 'normalsize', 'large', 'Large', 'LARGE', 'huge', 'Huge']);
const SIZE_PT = { tiny: 6, scriptsize: 7, footnotesize: 8, small: 9, normalsize: 10, large: 12, Large: 14, LARGE: 17, huge: 20, Huge: 25 };
const TEXT_SYMBOLS = { ldots: '…', dots: '…', textellipsis: '…', textbackslash: '\\', textasciitilde: '~', textasciicircum: '^', textbar: '|', textless: '<', textgreater: '>', textquoteleft: '‘', textquoteright: '’', textquotedblleft: '“', textquotedblright: '”', S: '§', P: '¶', dag: '†', ddag: '‡', copyright: '©', pounds: '£', textdegree: '°', textbullet: '•', textendash: '–', textemdash: '—', LaTeX: 'LaTeX', TeX: 'TeX', textregistered: '®', texttrademark: '™', textperiodcentered: '·', textrightarrow: '→', textleftarrow: '←', checkmark: '✓', textcircled: '' };

export function parseLatexDoc(src, files = new Map()) {
  const warnings = [];
  const images = new Map();
  let text = src.replace(/\r\n?/g, '\n');
  // strip comments (not escaped \%)
  text = text.replace(/(^|[^\\])%[^\n]*/g, '$1');
  const docM = /\\begin\{document\}([\s\S]*?)(\\end\{document\}|$)/.exec(text);
  let titleBlocks = [];
  if (docM) {
    const pre = text.slice(0, docM.index);
    const t = /\\title\{((?:[^{}]|\{[^{}]*\})*)\}/.exec(pre);
    if (t) titleBlocks.push({ type: 'heading', level: 1, inlines: [{ type: 'text', text: cleanInline(t[1]) }], align: 'center' });
    text = docM[1];
  }
  const out = new Parser(text, files, images, warnings).parseDocument();
  return { blocks: [...titleBlocks, ...out], images, warnings, source: 'latex' };
}
function cleanInline(s) { return s.replace(/\\\\/g, ' ').replace(/\\[A-Za-z]+\s*/g, '').replace(/[{}]/g, '').trim(); }

class Parser {
  constructor(text, files, images, warnings) { this.s = text; this.i = 0; this.files = files; this.images = images; this.warnings = warnings; this.imgN = 0; }
  eof() { return this.i >= this.s.length; }
  peek(n = 1) { return this.s.substr(this.i, n); }
  startsWith(str) { return this.s.startsWith(str, this.i); }
  readGroup() { // assumes at '{'
    if (this.peek() !== '{') return '';
    let d = 0, j = this.i;
    for (; j < this.s.length; j++) {
      const c = this.s[j];
      if (c === '\\') { j++; continue; }
      if (c === '{') d++; else if (c === '}') { d--; if (d === 0) break; }
    }
    const inner = this.s.slice(this.i + 1, j);
    this.i = j + 1;
    return inner;
  }
  readOpt() { // optional [..]
    this.skipSpaces();
    if (this.peek() !== '[') return null;
    let d = 0, j = this.i;
    for (; j < this.s.length; j++) { const c = this.s[j]; if (c === '[') d++; else if (c === ']') { d--; if (d === 0) break; } }
    const inner = this.s.slice(this.i + 1, j); this.i = j + 1; return inner;
  }
  skipSpaces() { while (!this.eof() && (this.peek() === ' ' || this.peek() === '\t')) this.i++; }
  readCmdName() { // at '\'
    let j = this.i + 1;
    if (/[A-Za-z]/.test(this.s[j] || '')) { while (j < this.s.length && /[A-Za-z]/.test(this.s[j])) j++; const name = this.s.slice(this.i + 1, j); this.i = j; if (this.s[j] === '*') this.i++; return name; }
    const ch = this.s[j] || ''; this.i = j + 1; return ch;
  }
  readUntil(str) { const k = this.s.indexOf(str, this.i); const out = k < 0 ? this.s.slice(this.i) : this.s.slice(this.i, k); this.i = k < 0 ? this.s.length : k + str.length; return out; }
  readEnvBody(name) { // after \begin{name}; returns body text up to matching \end{name}
    const open = new RegExp(`\\\\begin\\{${esc(name)}\\*?\\}`, 'g'), close = new RegExp(`\\\\end\\{${esc(name)}\\*?\\}`, 'g');
    let depth = 1, pos = this.i;
    for (;;) {
      close.lastIndex = pos; open.lastIndex = pos;
      const c = close.exec(this.s), o = open.exec(this.s);
      if (!c) { const body = this.s.slice(this.i); this.i = this.s.length; this.warnings.push(`\\end{${name}} 가 없습니다`); return body; }
      if (o && o.index < c.index) { depth++; pos = o.index + o[0].length; continue; }
      depth--;
      if (depth === 0) { const body = this.s.slice(this.i, c.index); this.i = c.index + c[0].length; return body; }
      pos = c.index + c[0].length;
    }
  }

  // ---- block level ----
  parseDocument() {
    const blocks = [];
    let para = null; // current inline list
    const flushPara = () => { if (para && para.inlines.some(x => x.type !== 'text' || x.text.trim())) blocks.push(para); para = null; };
    const ensurePara = () => { if (!para) para = { type: 'p', inlines: [], align: this.align || 'justify' }; return para; };
    if (!this.align) this.align = 'justify';
    if (!this.style) this.style = { bold: false, italic: false, underline: false, sup: false, sub: false, size: 0 };
    const pushInlines = (items) => { const p = ensurePara(); p.inlines.push(...items); };

    while (!this.eof()) {
      const ch = this.peek();
      if (ch === '\n') {
        this.i++;
        let blank = false;
        while (!this.eof() && /[ \t\n]/.test(this.peek())) { if (this.peek() === '\n') blank = true; this.i++; }
        if (blank) flushPara(); else if (para) pushInlines([{ type: 'text', text: ' ', ...this.style }]);
        continue;
      }
      if (ch === '\\') {
        const save = this.i;
        const name = this.readCmdName();
        if (name === 'begin') {
          const env = this.readGroup();
          const handled = this.parseEnv(env, blocks, () => { flushPara(); }, pushInlines);
          if (handled) continue;
          continue;
        }
        if (name === 'end') { this.readGroup(); continue; }
        if (name === 'par') { flushPara(); continue; }
        if (name === 'section' || name === 'subsection' || name === 'subsubsection' || name === 'chapter' || name === 'paragraph') {
          flushPara();
          this.readOpt();
          const title = this.readGroup();
          const level = { chapter: 1, section: 1, subsection: 2, subsubsection: 3, paragraph: 3 }[name];
          blocks.push({ type: 'heading', level, inlines: this.inlineOf(title) });
          continue;
        }
        if (name === '[') { flushPara(); const body = this.readUntil('\\]'); blocks.push({ type: 'display', latex: body.trim() }); continue; }
        if (name === 'item') { // stray item outside list
          this.readOpt(); continue;
        }
        if (name === 'includegraphics') { const img = this.parseIncludeGraphics(); if (img) { if (para) pushInlines([img]); else { flushPara(); blocks.push({ ...img, caption: null }); } } continue; }
        if (name === 'caption') { const cap = this.readGroup(); flushPara(); blocks.push({ type: 'p', inlines: this.inlineOf(cap), align: 'center' }); continue; }
        this.i = save;
        pushInlines(this.parseInlineChunk());
        continue;
      }
      if (ch === '$' && this.peek(2) === '$') { flushPara(); this.i += 2; const body = this.readUntil('$$'); blocks.push({ type: 'display', latex: body.trim() }); continue; }
      pushInlines(this.parseInlineChunk());
    }
    flushPara();
    return blocks;
  }

  parseEnv(env, blocks, flush, pushInlines) {
    const e = env.replace('*', '');
    switch (e) {
      case 'center': case 'flushright': case 'flushleft': {
        flush();
        const body = this.readEnvBody(env);
        const sub = new Parser(body, this.files, this.images, this.warnings); sub.imgN = this.imgN;
        sub.align = e === 'center' ? 'center' : e === 'flushright' ? 'right' : 'left';
        const bs = sub.parseDocument(); this.imgN = sub.imgN;
        for (const b of bs) if (b.type === 'p' || b.type === 'image') b.align = sub.align;
        blocks.push(...bs);
        return true;
      }
      case 'equation': case 'displaymath': case 'align': case 'gather': case 'multline': case 'eqnarray': case 'alignat': case 'flalign': {
        flush();
        let body = this.readEnvBody(env).trim();
        if (e !== 'equation' && e !== 'displaymath') body = `\\begin{${e === 'align' || e === 'eqnarray' || e === 'alignat' || e === 'flalign' ? 'aligned' : 'gathered'}} ${body} \\end{${e === 'align' || e === 'eqnarray' || e === 'alignat' || e === 'flalign' ? 'aligned' : 'gathered'}}`;
        blocks.push({ type: 'display', latex: body.replace(/\\(label|tag)\{[^}]*\}/g, '').replace(/\\(nonumber|notag)/g, '') });
        return true;
      }
      case 'enumerate': case 'itemize': case 'description': {
        flush();
        this.readOpt();
        const body = this.readEnvBody(env);
        const items = splitItems(body);
        this.listDepth = (this.listDepth || 0) + 1;
        let n = 0;
        for (const it of items) {
          n++;
          const label = it.label != null ? it.label : e === 'enumerate' ? (this.listDepth === 1 ? `${n}.` : this.listDepth === 2 ? `(${String.fromCharCode(96 + n)})` : `${toRoman(n)}.`) : e === 'itemize' ? '•' : '';
          const sub = new Parser(it.body, this.files, this.images, this.warnings); sub.imgN = this.imgN; sub.listDepth = this.listDepth;
          const bs = sub.parseDocument(); this.imgN = sub.imgN;
          if (!bs.length) bs.push({ type: 'p', inlines: [], align: 'justify' });
          const first = bs.find(b => b.type === 'p');
          if (first) first.inlines.unshift({ type: 'text', text: label ? label + ' ' : '', bold: false, italic: false, underline: false, sup: false, sub: false, size: 0 });
          for (const b of bs) if (b.type === 'p') b.level = Math.max(b.level || 0, this.listDepth - 1);
          blocks.push(...bs);
        }
        this.listDepth--;
        return true;
      }
      case 'tabular': case 'tabularx': case 'longtable': case 'array': {
        flush();
        if (e === 'tabularx') this.readGroup();
        this.readOpt();
        const spec = this.readGroup();
        const body = this.readEnvBody(env);
        blocks.push(this.parseTabular(spec, body));
        return true;
      }
      case 'table': case 'figure': case 'minipage': case 'wrapfigure': case 'wraptable': {
        flush();
        this.readOpt();
        if (e === 'minipage') { this.readOpt(); this.readGroup(); }
        if (e === 'wrapfigure' || e === 'wraptable') { this.readGroup(); this.readGroup(); }
        const body = this.readEnvBody(env);
        const sub = new Parser(body, this.files, this.images, this.warnings); sub.imgN = this.imgN;
        const bs = sub.parseDocument(); this.imgN = sub.imgN;
        // attach caption paragraph to image/table
        const capIdx = bs.findIndex(b => b.type === 'p' && b.isCaption);
        blocks.push(...bs.map(b => (b.type === 'image' || b.type === 'table') && e !== 'minipage' ? { ...b, align: 'center' } : b));
        return true;
      }
      case 'tcolorbox': case 'mdframed': case 'framed': case 'tcbox': case 'quote': case 'quotation': case 'abstract': {
        flush();
        this.readOpt();
        const body = this.readEnvBody(env);
        const sub = new Parser(body, this.files, this.images, this.warnings); sub.imgN = this.imgN;
        const bs = sub.parseDocument(); this.imgN = sub.imgN;
        blocks.push({ type: 'textbox', blocks: bs });
        return true;
      }
      case 'tikzpicture': case 'pgfpicture': {
        flush(); this.readOpt(); this.readEnvBody(env);
        this.warnings.push(`${env} 그림은 자동 변환하지 못했습니다. PNG 그림을 직접 삽입해 주세요.`);
        blocks.push({ type: 'shape', desc: `${env} 그림`, widthPt: 200, heightPt: 120 });
        return true;
      }
      case 'document': return true;
      case 'verbatim': case 'lstlisting': case 'comment': {
        flush();
        const body = this.readEnvBody(env);
        if (e !== 'comment') blocks.push({ type: 'p', inlines: [{ type: 'text', text: body.trim(), ...this.style }], align: 'left' });
        return true;
      }
      default: {
        // unknown environment: parse its body inline
        const body = this.readEnvBody(env);
        this.warnings.push(`알 수 없는 환경 ${env} — 내용만 옮깁니다`);
        const sub = new Parser(body, this.files, this.images, this.warnings); sub.imgN = this.imgN;
        const bs = sub.parseDocument(); this.imgN = sub.imgN;
        blocks.push(...bs);
        return true;
      }
    }
  }

  parseTabular(spec, body) {
    const specClean = spec.replace(/[>@!<]\{(?:[^{}]|\{[^{}]*\})*\}/g, '').replace(/\*\{\d+\}\{[^}]*\}/g, (m) => { const n = +m.match(/\{(\d+)\}/)[1]; return m.replace(/^\*\{\d+\}\{|\}$/g, '').repeat(n); });
    const colList = specClean.match(/[lcrX]|[pmb]\{[^}]*\}/g) || ['c'];
    const cols = colList.length;
    const colW = colList.map(c => /^[pmb]/.test(c) ? toHwpUnit(c.replace(/^[pmb]\{|\}$/g, '')) : 0);
    const rowsRaw = splitTopLevel(body.replace(/\\hline|\\toprule|\\midrule|\\bottomrule|\\cline\{[^}]*\}/g, ''), '\\\\').map(r => r.trim()).filter(r => r.length);
    const cells = [];
    const occupied = new Set();
    let r = 0;
    for (const row of rowsRaw) {
      const parts = splitTopLevel(row, '&');
      let c = 0;
      for (let raw of parts) {
        while (occupied.has(`${r},${c}`)) c++;
        raw = raw.trim();
        let colspan = 1, rowspan = 1;
        for (;;) {
          let m;
          if ((m = /^\\multicolumn\s*/.exec(raw))) {
            const a = takeGroup(raw, m[0].length); if (!a) break;
            const b = takeGroup(raw, a.end); if (!b) break;
            const c = takeGroup(raw, b.end); if (!c) break;
            colspan = parseInt(a.content, 10) || 1; raw = c.content.trim(); continue;
          }
          if ((m = /^\\multirow\s*/.exec(raw))) {
            const a = takeGroup(raw, m[0].length); if (!a) break;
            const b = takeGroup(raw, a.end); if (!b) break;
            let pos = b.end; const sp = /^\s*\[[^\]]*\]/.exec(raw.slice(pos)); if (sp) pos += sp[0].length;
            const c = takeGroup(raw, pos); if (!c) break;
            rowspan = parseInt(a.content, 10) || 1; raw = c.content.trim(); continue;
          }
          break;
        }
        if (rowspan > 1) for (let k = 1; k < rowspan; k++) for (let j = 0; j < colspan; j++) occupied.add(`${r + k},${c + j}`);
        const sub = new Parser(raw.replace(/\\newline/g, '\\\\'), this.files, this.images, this.warnings); sub.imgN = this.imgN;
        const bs = sub.parseDocument(); this.imgN = sub.imgN;
        cells.push({ row: r, col: c, colspan, rowspan, width: colW[c] ? colW[c] + 1020 : 0, height: 0, blocks: bs });
        c += colspan;
      }
      r++;
    }
    return { type: 'table', rows: r, cols, cells, caption: null };
  }

  parseIncludeGraphics() {
    const opt = this.readOpt() || '';
    const path = this.readGroup().trim();
    let widthPt = 0, heightPt = 0;
    const wm = /width\s*=\s*([^,\]]+)/.exec(opt); if (wm) widthPt = toPt(wm[1]);
    const hm = /height\s*=\s*([^,\]]+)/.exec(opt); if (hm) heightPt = toPt(hm[1]);
    const sm = /scale\s*=\s*([0-9.]+)/.exec(opt);
    const data = findFile(this.files, path);
    if (!data) { this.warnings.push(`그림 파일을 찾지 못했습니다: ${path} (ZIP에 그림을 함께 넣어 주세요)`); return { type: 'shape', desc: `그림 ${path}`, widthPt: widthPt || 200, heightPt: heightPt || 120 }; }
    const ref = `img${++this.imgN}`;
    const ext = (path.match(/\.([A-Za-z0-9]+)$/) || [, 'png'])[1].toLowerCase();
    this.images.set(ref, { ext, data: data.bytes, scale: sm ? +sm[1] : 1 });
    return { type: 'image', ref, widthPt, heightPt };
  }

  inlineOf(text) { const sub = new Parser(text, this.files, this.images, this.warnings); sub.style = { ...this.style }; const bs = sub.parseDocument(); return bs.flatMap(b => b.type === 'p' ? b.inlines : []); }

  // ---- inline level: parse one chunk (text run, command, group, math) ----
  parseInlineChunk() {
    const ch = this.peek();
    const st = () => ({ ...this.style });
    if (ch === '$') {
      this.i++;
      const body = this.readUntil('$');
      return [{ type: 'eq', latex: body.trim() }];
    }
    if (ch === '{') {
      const inner = this.readGroup();
      const sub = new Parser(inner, this.files, this.images, this.warnings); sub.style = { ...this.style }; sub.imgN = this.imgN;
      const bs = sub.parseDocument(); this.imgN = sub.imgN;
      return bs.flatMap(b => b.type === 'p' ? b.inlines : b.type === 'display' ? [{ type: 'eq', latex: b.latex }] : b.type === 'image' ? [b] : []);
    }
    if (ch === '}') { this.i++; return []; }
    if (ch === '~') { this.i++; return [{ type: 'text', text: '\u00a0', ...st() }]; }
    if (ch === '\\') {
      const name = this.readCmdName();
      switch (name) {
        case '(': { const body = this.readUntil('\\)'); return [{ type: 'eq', latex: body.trim() }]; }
        case '\\': { this.readOpt(); return [{ type: 'br' }]; }
        case 'newline': return [{ type: 'br' }];
        case 'textbf': case 'bf': case 'textit': case 'emph': case 'underline': case 'uline': case 'textsuperscript': case 'textsubscript': case 'textrm': case 'textsf': case 'texttt': case 'textsc': case 'textnormal': case 'textmd': case 'textup': case 'textsl': case 'mbox': case 'text': case 'fbox': case 'framebox': case 'uppercase': case 'lowercase': case 'textcolor': case 'colorbox': case 'hl': case 'sout': {
          if (name === 'textcolor' || name === 'colorbox') this.readGroup();
          if (name === 'framebox') { this.readOpt(); this.readOpt(); }
          this.skipSpaces();
          const inner = this.readGroup();
          const saved = { ...this.style };
          if (name === 'textbf' || name === 'bf') this.style.bold = true;
          if (name === 'textit' || name === 'emph' || name === 'textsl') this.style.italic = !this.style.italic;
          if (name === 'underline' || name === 'uline') this.style.underline = true;
          if (name === 'textsuperscript') this.style.sup = true;
          if (name === 'textsubscript') this.style.sub = true;
          const items = this.inlineOf(inner);
          this.style = saved;
          return items;
        }
        case 'footnote': case 'endnote': {
          this.readOpt();
          const inner = this.readGroup();
          const sub = new Parser(inner, this.files, this.images, this.warnings); sub.imgN = this.imgN;
          const bs = sub.parseDocument(); this.imgN = sub.imgN;
          return [{ type: 'note', kind: name === 'endnote' ? 'en' : 'fn', blocks: bs }];
        }
        case 'includegraphics': { const img = this.parseIncludeGraphics(); return img ? [img] : []; }
        case 'quad': return [{ type: 'text', text: '\u2003', ...st() }];
        case 'qquad': return [{ type: 'text', text: '\u2003\u2003', ...st() }];
        case ',': case ';': case ' ': case '!': case ':': return [{ type: 'text', text: ' ', ...st() }];
        case 'verb': { const d = this.peek(); this.i++; const body = this.readUntil(d); return [{ type: 'text', text: body, ...st() }]; }
        case 'url': case 'href': { const a = this.readGroup(); const b = name === 'href' ? this.readGroup() : a; return [{ type: 'text', text: b || a, ...st() }]; }
        case 'ref': case 'eqref': case 'pageref': case 'cite': { this.readGroup(); return [{ type: 'text', text: '?', ...st() }]; }
        case 'bfseries': case 'textbf ': this.style.bold = true; return [];
        case 'itshape': case 'em': case 'slshape': this.style.italic = true; return [];
        case 'rmfamily': case 'sffamily': case 'ttfamily': case 'upshape': case 'mdseries': case 'normalfont': this.style.bold = false; this.style.italic = false; return [];
        case 'item': { this.readOpt(); return [{ type: 'br' }]; }
        case 'textcircled': { const g = this.readGroup(); const n = parseInt(g, 10); return [{ type: 'text', text: n >= 1 && n <= 20 ? String.fromCharCode(0x2460 + n - 1) : g, ...st() }]; }
        default: break;
      }
      if (SIZE_CMDS.has(name)) { this.style.size = SIZE_PT[name]; return []; }
      if (Object.hasOwn(TEXT_SYMBOLS, name)) return [{ type: 'text', text: TEXT_SYMBOLS[name], ...st() }];
      if (name.length === 1 && !/[A-Za-z]/.test(name)) {
        if (name === '\n') return [{ type: 'text', text: ' ', ...st() }];
        return [{ type: 'text', text: name, ...st() }];
      }
      if (SKIP_CMDS.has(name)) { this.skipArgs(); return []; }
      // unknown command: keep its last brace argument text
      this.warnings.push(`알 수 없는 명령 \\${name} — 인수만 옮깁니다`);
      let items = [];
      for (;;) { this.readOpt(); this.skipSpaces(); if (this.peek() !== '{') break; items = this.inlineOf(this.readGroup()); }
      return [{ type: 'text', text: `[미지원 명령: \\${name}]`, ...st() }, ...items];
    }
    // plain text run
    let j = this.i;
    while (j < this.s.length && !'\\{}$~\n'.includes(this.s[j])) j++;
    if (j === this.i) { this.i++; return []; }
    let t = this.s.slice(this.i, j); this.i = j;
    t = t.replace(/---/g, '—').replace(/--/g, '–').replace(/``/g, '“').replace(/''/g, '”').replace(/\s+/g, ' ');
    return [{ type: 'text', text: t, ...st() }];
  }
  skipArgs() { for (;;) { const save = this.i; this.readOpt(); this.skipSpaces(); if (this.peek() === '{') { this.readGroup(); continue; } if (this.peek() === '[') { this.readOpt(); continue; } this.i = save; break; } }
}

function esc(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function takeGroup(str, pos) {
  while (pos < str.length && /\s/.test(str[pos])) pos++;
  if (str[pos] !== '{') return null;
  let d = 0;
  for (let j = pos; j < str.length; j++) {
    const c = str[j];
    if (c === '\\') { j++; continue; }
    if (c === '{') d++; else if (c === '}') { d--; if (d === 0) return { content: str.slice(pos + 1, j), end: j + 1 }; }
  }
  return null;
}
function splitTopLevel(s, sep) {
  const out = []; let d = 0, env = 0, cur = '', i = 0;
  while (i < s.length) {
    const c = s[i];
    if (c === '\\' && s.startsWith('\\begin{', i)) { env++; cur += '\\begin'; i += 6; continue; }
    if (c === '\\' && s.startsWith('\\end{', i)) { env--; cur += '\\end'; i += 4; continue; }
    if (c === '\\' && sep === '&' && s[i + 1] === '&') { cur += '\\&'; i += 2; continue; }
    if (c === '\\' && sep !== '&' && s.startsWith(sep, i)) { if (d === 0 && env === 0) { out.push(cur); cur = ''; i += sep.length; continue; } }
    if (c === '\\' && s[i + 1] && !/[A-Za-z]/.test(s[i + 1])) { cur += c + s[i + 1]; i += 2; continue; }
    if (c === '{') d++; else if (c === '}') d--;
    if (d === 0 && env === 0 && s.startsWith(sep, i) && sep === '&') { out.push(cur); cur = ''; i += 1; continue; }
    cur += c; i++;
  }
  out.push(cur);
  return out;
}
function splitItems(body) {
  const items = [];
  const re = /\\item\b(\s*\[((?:[^\[\]]|\[[^\]]*\])*)\])?/g;
  let m, last = null;
  while ((m = re.exec(body))) {
    if (last) items.push({ label: last.label, body: body.slice(last.end, m.index) });
    last = { label: m[2] != null ? m[2] : null, end: m.index + m[0].length };
  }
  if (last) items.push({ label: last.label, body: body.slice(last.end) });
  return items;
}
function toRoman(n) { const v = [10, 9, 5, 4, 1], s = ['x', 'ix', 'v', 'iv', 'i']; let out = ''; for (let i = 0; i < v.length; i++) while (n >= v[i]) { out += s[i]; n -= v[i]; } return out; }
function toPt(expr) {
  expr = expr.trim();
  let m;
  if ((m = /^([0-9.]*)\s*\\(linewidth|textwidth|columnwidth|hsize)/.exec(expr))) return (m[1] === '' ? 1 : +m[1]) * 440;
  if ((m = /^([0-9.]+)\s*(pt|cm|mm|in|em|ex|px|bp)$/.exec(expr))) { const v = +m[1]; return { pt: v, cm: v * 28.45, mm: v * 2.845, in: v * 72, em: v * 10, ex: v * 4.5, px: v * 0.75, bp: v }[m[2]]; }
  if ((m = /^([0-9.]+)$/.exec(expr))) return +m[1];
  return 0;
}
function toHwpUnit(expr) { return Math.round(toPt(expr) * 100); }
function findFile(files, path) {
  if (!files || !files.size) return null;
  const norm = (p) => p.replace(/^\.\//, '').toLowerCase();
  const want = norm(path);
  const cands = [want, want + '.png', want + '.jpg', want + '.jpeg', want + '.pdf'];
  for (const [p, bytes] of files) {
    const np = norm(p);
    for (const w of cands) if (np === w || np.endsWith('/' + w)) return { path: p, bytes };
  }
  const base = want.split('/').pop();
  for (const [p, bytes] of files) if (norm(p).split('/').pop() === base) return { path: p, bytes };
  return null;
}
