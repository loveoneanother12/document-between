import fs from 'node:fs';
import {DOMParser} from '@xmldom/xmldom';
import {setDOMParser,parseLatexDoc,docToHwpx,docToDocx,latexToHancom} from '../src/index.js';
setDOMParser(DOMParser);
const tex=String.raw`\documentclass{article}
\begin{document}
\section{변환 검증: 수식, 표, 각주}
1. 분수와 근호: $\frac{a+b}{c} + \sqrt{x^2+1}$ 입니다.\footnote{각주 해설: $x=2$를 대입합니다.}

2. 합과 간격: $\sum_{k=1}^{n} k = \frac{n(n+1)}{2} \quad x=1$ 입니다.\endnote{미주 해설: 합 공식을 적용합니다.}
\[\begin{pmatrix}1&2\\3&4\end{pmatrix}\]
\begin{tabular}{cc}
항목 & 값 \\
분수 & $\frac{1}{2}$ \\
근호 & $\sqrt{3}$ \\
\end{tabular}

\textbf{굵게} / \textit{기울임} / \underline{밑줄} / 한글과 Latin 123.
\end{document}`;
const dir=process.argv[2]||'../outputs'; fs.mkdirSync(dir,{recursive:true});
fs.writeFileSync(`${dir}/compatibility.tex`,tex);
const doc=parseLatexDoc(tex);
fs.writeFileSync(`${dir}/compatibility.hwpx`,docToHwpx(doc,{eqToScript:latexToHancom}).hwpx);
fs.writeFileSync(`${dir}/compatibility.docx`,docToDocx(doc).docx);
console.log('Compatibility fixtures written:',dir);
