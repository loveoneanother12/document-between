import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DOMParser} from '@xmldom/xmldom';
import {unzipSync} from 'fflate';
import {setDOMParser,parseDocument,parseDocx,docToHwpx,docToDocx,latexToHancom,parseLatexDoc,hwpEqToLatex} from '../src/index.js';
import {latexToOmml,ommlToLatex,tidyLatexFromOmml} from '../src/mathast.js';
import {runMode} from '../src/app.js';
setDOMParser(DOMParser);
const xml = s => new DOMParser().parseFromString(`<root xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">${s}</root>`,'application/xml').documentElement.firstChild;
const back = s => tidyLatexFromOmml(ommlToLatex(xml(latexToOmml(s).omml)));
const fixture = name => fs.readFileSync(new URL(`fixtures/${name}.hwpx`,import.meta.url));
test('47 supplied Hancom equations parse without warnings',()=>{
 for(const s of fs.readFileSync(new URL('eq_cases.txt',import.meta.url),'utf8').split('\n').filter(Boolean)) assert.deepEqual(hwpEqToLatex(s).warnings,[],s);
});
test('Hancom Office resave retains the parsed model',()=>{
 assert.deepEqual(parseDocument(fixture('hancom-saved')),parseDocument(fixture('generated')));
});
test('Word sums and functions own their operands, without empty placeholders',()=>{
 for(const input of [String.raw`\sum_{k=1}^n k`,String.raw`\sin x`,String.raw`\sum_i \sum_j x`,String.raw`\int_0^1 x^2`]) {
  const root=xml(latexToOmml(input).omml);
  for(const name of ['nary','func']) for(const el of Array.from(root.getElementsByTagName(`m:${name}`))) {
   const e=Array.from(el.childNodes).find(n=>n.nodeName==='m:e'); assert.ok(e?.textContent.trim(),input);
  }
 }
 assert.match(back(String.raw`\sum_{k=1}^n k=5`),/k=5/);
 assert.doesNotMatch(latexToOmml(String.raw`\sin + x`).omml,/<m:func>/);
});
test('Word roundtrip preserves explicit mathematical spaces',()=>{
 for(const command of ['quad','qquad','enspace',',',':',';',' ']) {
  assert.ok(back(`a\\${command} b`).includes(`\\${command}`),command);
 }
 assert.ok(latexToOmml(String.raw`a\!b`).warnings.length);
});
test('non-growing Word delimiters remain ordinary parentheses',()=>{
 const s='<m:d><m:dPr><m:grow m:val="0"/></m:dPr><m:e><m:r><m:t>x</m:t></m:r></m:e></m:d>';
 assert.equal(ommlToLatex(xml(s)),'(x)');
});
test('TikZ and unknown commands leave visible placeholders and warnings',()=>{
 const doc=parseLatexDoc(String.raw`\begin{document}\begin{tikzpicture}\draw (0,0)--(1,1);\end{tikzpicture}끝 \custom{내용}\end{document}`);
 assert.ok(doc.blocks.some(b=>b.type==='shape'));
 assert.ok(JSON.stringify(doc.blocks).includes('미지원 명령'));
 assert.equal(doc.warnings.length,2);
});
test('explicit fonts survive HWPX and DOCX roundtrips including XML metacharacters',()=>{
 const doc={blocks:[{type:'p',inlines:[{type:'text',text:'글꼴',font:'Test & "Font"',size:12}]}],images:new Map(),warnings:[]};
 for(const parsed of [parseDocument(docToHwpx(doc).hwpx),parseDocx(docToDocx(doc).docx)]) {
  assert.equal(parsed.blocks[0].inlines[0].font,'Test & "Font"');
 }
});
test('all five conversion modes retain tables and both note kinds',()=>{
 const hwpx=fixture('hancom-saved');
 const docx=runMode('hwp2docx',hwpx,'sample.hwpx').data;
 const tex=String.raw`\documentclass{article}\begin{document}수식 $x^2$\footnote{각주}\endnote{미주}\begin{tabular}{cc}A&B\\C&D\end{tabular}\end{document}`;
 const cases=[['hwp2tex',hwpx],['hwp2docx',hwpx],['tex2hwpx',new TextEncoder().encode(tex)],['docx2hwpx',docx],['docx2tex',docx]];
 for(const [mode,bytes] of cases){const r=runMode(mode,bytes,'sample'); assert.equal(r.stats.tables,1,mode); assert.equal(r.stats.notes,2,mode); assert.ok(r.stats.eqs>0,mode); if(r.data){assert.ok(Object.keys(unzipSync(r.data)).length>3);}}
});

test('standalone equations survive HWPX to Word and back',()=>{
 const tex=String.raw`\documentclass{article}\begin{document}Example\[x=\frac{1}{2}\]\[\sum_{k=1}^n k\]\end{document}`;
 const hwpx=runMode('tex2hwpx',new TextEncoder().encode(tex),'example.tex').data;
 const docx=runMode('hwp2docx',hwpx,'example.hwpx').data;
 for(const mode of ['docx2tex','docx2hwpx']) assert.equal(runMode(mode,docx,'example.docx').stats.eqs,2);
});

// Synthetic fixture: contains no uploaded private document content.
import {zipSync,strToU8,strFromU8} from 'fflate';
const formattedFixture = () => {
 const cell=(row,col,span=1)=>`<hp:tc borderFillIDRef="1" hasMargin="1"><hp:subList vertAlign="TOP"><hp:p paraPrIDRef="0"><hp:run><hp:t>cell ${row} ${col}</hp:t></hp:run></hp:p></hp:subList><hp:cellAddr colAddr="${col}" rowAddr="${row}"/><hp:cellSpan colSpan="1" rowSpan="${span}"/><hp:cellSz width="15000" height="3000"/><hp:cellMargin left="300" right="400" top="100" bottom="200"/></hp:tc>`;
 const table=`<hp:tbl rowCnt="2" colCnt="2" pageBreak="NONE"><hp:sz width="30000"/><hp:tr>${cell(0,0,2)}${cell(0,1)}</hp:tr><hp:tr>${cell(1,1)}</hp:tr></hp:tbl>`;
 const header=`<hh:head xmlns:hh="urn:header" xmlns:hp="urn:paragraph"><hh:paraPr id="0"><hh:align horizontal="LEFT"/><hh:heading type="NONE"/><hp:switch><hp:case><hp:margin><hp:left value="9999"/></hp:margin></hp:case><hp:default><hp:margin><hp:left value="500"/><hp:intent value="-250"/><hp:next value="300"/></hp:margin><hp:lineSpacing type="PERCENT" value="150"/></hp:default></hp:switch></hh:paraPr><hh:paraPr id="1"><hh:heading type="NUMBER" idRef="1" level="0"/></hh:paraPr><hh:paraPr id="2"><hh:heading type="BULLET" idRef="1" level="0"/></hh:paraPr><hh:numbering id="1"><hh:paraHead level="1" numFormat="DIGIT" start="3">문제 ^1.</hh:paraHead></hh:numbering><hh:bullet id="1" char="•"/><hh:borderFill id="1"><hh:leftBorder type="NONE"/><hh:rightBorder type="SOLID" width="0.5 mm" color="#123456"/><hh:topBorder type="DOUBLE_SLIM" width="0.5 mm"/><hh:bottomBorder type="SOLID" width="0.12 mm"/><hh:fillBrush><hh:winBrush faceColor="#FFF0AA"/></hh:fillBrush></hh:borderFill></hh:head>`;
 const section=`<hp:sec xmlns:hp="urn:paragraph"><hp:p paraPrIDRef="0"><hp:run><hp:secPr><hp:pagePr width="60000" height="84000"><hp:margin left="3000" right="3000" top="2000" bottom="2000" header="4000" footer="2000"/></hp:pagePr></hp:secPr><hp:ctrl><hp:header applyPageType="BOTH"><hp:subList><hp:p><hp:run>${table}</hp:run></hp:p></hp:subList></hp:header></hp:ctrl><hp:t>body</hp:t>${table}</hp:run></hp:p><hp:p paraPrIDRef="1"><hp:run><hp:t>first</hp:t></hp:run></hp:p><hp:p paraPrIDRef="1"><hp:run><hp:t>second</hp:t></hp:run></hp:p><hp:p paraPrIDRef="2"><hp:run><hp:t>bullet</hp:t></hp:run></hp:p></hp:sec>`;
 return zipSync({'mimetype':strToU8('application/hwp+zip'),'Contents/header.xml':strToU8(header),'Contents/section0.xml':strToU8(section)});
};
test('HWPX preserves header tables and fallback paragraph units',()=>{
 const d=parseDocument(formattedFixture());
 assert.equal(d.headers[0].blocks[0].type,'table');
 assert.equal(d.blocks[0].layout.margins.left,500);
 assert.equal(d.blocks[0].layout.lineSpacing.value,150);
 assert.equal(runMode('hwp2docx',formattedFixture(),'test').stats.tables,2);
});
test('Word writes native numbering without duplicating visible prefixes',()=>{
 const z=unzipSync(runMode('hwp2docx',formattedFixture(),'test').data);
 const doc=strFromU8(z['word/document.xml']), nums=strFromU8(z['word/numbering.xml']);
 assert.equal((doc.match(/<w:numPr>/g)||[]).length,3);
 assert.doesNotMatch(doc,/문제 3\./);
 assert.match(nums,/w:start w:val="3"/); assert.match(nums,/문제 %1\./); assert.match(nums,/w:numFmt w:val="bullet"/);
});
test('Word keeps cell borders, fill, margins, merge and header relationship',()=>{
 const z=unzipSync(runMode('hwp2docx',formattedFixture(),'test').data);
 const d=strFromU8(z['word/document.xml']);
 for(const pattern of [/w:vMerge w:val="restart"/,/w:left w:val="nil"/,/w:top w:val="double"/,/w:fill="FFF0AA"/,/w:left w:w="60"/,/w:vAlign w:val="top"/,/w:headerReference/,/w:left="600"/,/w:line="360"/]) assert.match(d,pattern);
 assert.match(strFromU8(z['word/header1.xml']),/<w:tbl>/);
 assert.match(strFromU8(z['[Content_Types].xml']),/word\/header1.xml/);
 assert.match(strFromU8(z['word/_rels/document.xml.rels']),/Target="header1.xml"/);
});
test('LaTeX keeps header and fill, and does not draw across a merged cell',()=>{
 const r=runMode('hwp2tex',formattedFixture(),'test');
 assert.match(r.tex,/\\fancyhead/); assert.match(r.tex,/\\cellcolor\[HTML\]\{FFF0AA\}/);
 assert.match(r.tex,/\\cline\{2-2\}/); assert.match(r.tex,/\\multirow\[t\]\{2\}\{=\}/);
 assert.equal(r.stats.tables,2);
});
