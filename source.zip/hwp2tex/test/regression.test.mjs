import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DOMParser} from '@xmldom/xmldom';
import {unzipSync} from 'fflate';
import {setDOMParser,parseDocument,parseDocx,docToHwpx,docToDocx,latexToHancom,parseLatexDoc,hwpEqToLatex} from '../src/index.js';
import {latexToOmml,ommlToLatex,tidyLatexFromOmml} from '../src/mathast.js';
import {runMode} from '../src/app.js';
setDOMParser(DOMParser);
const xml = s => new DOMParser().parseFromString(`<root xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">${s}</root>`,'application/xml').documentElement.firstChild;
const back = s => tidyLatexFromOmml(ommlToLatex(xml(latexToOmml(s).omml)));
const fixture = name => fs.readFileSync(new URL(`fixtures/${name}.hwpx`,import.meta.url));
test('47 supplied Hancom equations parse without warnings',()=>{
 for(const s of fs.readFileSync(new URL('eq_cases.txt',import.meta.url),'utf8').split('\n').filter(Boolean)) assert.deepEqual(hwpEqToLatex(s).warnings,[],s);
});
test('Hancom Office resave retains the parsed model',()=>{
 assert.deepEqual(parseDocument(fixture('hancom-saved')),parseDocument(fixture('generated')));
});
test('Word sums and functions own their operands, without empty placeholders',()=>{
 for(const input of [String.raw`\sum_{k=1}^n k`,String.raw`\sin x`,String.raw`\sum_i \sum_j x`,String.raw`\int_0^1 x^2`]) {
  const root=xml(latexToOmml(input).omml);
  for(const name of ['nary','func']) for(const el of Array.from(root.getElementsByTagName(`m:${name}`))) {
   const e=Array.from(el.childNodes).find(n=>n.nodeName==='m:e'); assert.ok(e?.textContent.trim(),input);
  }
 }
 assert.match(back(String.raw`\sum_{k=1}^n k=5`),/k=5/);
 assert.doesNotMatch(latexToOmml(String.raw`\sin + x`).omml,/<m:func>/);
});
test('Word roundtrip preserves explicit mathematical spaces',()=>{
 for(const command of ['quad','qquad','enspace',',',':',';',' ']) {
  assert.ok(back(`a\\${command} b`).includes(`\\${command}`),command);
 }
 assert.ok(latexToOmml(String.raw`a\!b`).warnings.length);
});
test('non-growing Word delimiters remain ordinary parentheses',()=>{
 const s='<m:d><m:dPr><m:grow m:val="0"/></m:dPr><m:e><m:r><m:t>x</m:t></m:r></m:e></m:d>';
 assert.equal(ommlToLatex(xml(s)),'(x)');
});
test('TikZ and unknown commands leave visible placeholders and warnings',()=>{
 const doc=parseLatexDoc(String.raw`\begin{document}\begin{tikzpicture}\draw (0,0)--(1,1);\end{tikzpicture}끝 \custom{내용}\end{document}`);
 assert.ok(doc.blocks.some(b=>b.type==='shape'));
 assert.ok(JSON.stringify(doc.blocks).includes('미지원 명령'));
 assert.equal(doc.warnings.length,2);
});
test('explicit fonts survive HWPX and DOCX roundtrips including XML metacharacters',()=>{
 const doc={blocks:[{type:'p',inlines:[{type:'text',text:'글꼴',font:'Test & "Font"',size:12}]}],images:new Map(),warnings:[]};
 for(const parsed of [parseDocument(docToHwpx(doc).hwpx),parseDocx(docToDocx(doc).docx)]) {
  assert.equal(parsed.blocks[0].inlines[0].font,'Test & "Font"');
 }
});
test('all five conversion modes retain tables and both note kinds',()=>{
 const hwpx=fixture('hancom-saved');
 const docx=runMode('hwp2docx',hwpx,'sample.hwpx').data;
 const tex=String.raw`\documentclass{article}\begin{document}수식 $x^2$\footnote{각주}\endnote{미주}\begin{tabular}{cc}A&B\\C&D\end{tabular}\end{document}`;
 const cases=[['hwp2tex',hwpx],['hwp2docx',hwpx],['tex2hwpx',new TextEncoder().encode(tex)],['docx2hwpx',docx],['docx2tex',docx]];
 for(const [mode,bytes] of cases){const r=runMode(mode,bytes,'sample'); assert.equal(r.stats.tables,1,mode); assert.equal(r.stats.notes,2,mode); assert.ok(r.stats.eqs>0,mode); if(r.data){assert.ok(Object.keys(unzipSync(r.data)).length>3);}}
});

test('standalone equations survive HWPX to Word and back',()=>{
 const tex=String.raw`\documentclass{article}\begin{document}Example\[x=\frac{1}{2}\]\[\sum_{k=1}^n k\]\end{document}`;
 const hwpx=runMode('tex2hwpx',new TextEncoder().encode(tex),'example.tex').data;
 const docx=runMode('hwp2docx',hwpx,'example.hwpx').data;
 for(const mode of ['docx2tex','docx2hwpx']) assert.equal(runMode(mode,docx,'example.docx').stats.eqs,2);
});
