import fs from 'node:fs';
import { hwpEqToLatex } from '../src/eqn.js';
const lines = fs.readFileSync(process.argv[2],'utf8').split('\n').filter(Boolean);
let warn=0;
for (const l of lines) { const r = hwpEqToLatex(l); if (r.warnings.length) warn++; console.log(l, '\n   => ', r.latex, r.warnings.length? '  !! '+r.warnings.join('; '):''); }
console.error('total', lines.length, 'with warnings', warn);
