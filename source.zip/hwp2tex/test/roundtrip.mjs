import fs from 'node:fs';
import { DOMParser } from '@xmldom/xmldom';
import { hwpEqToLatex } from '../src/eqn.js';
import { latexToHancom, latexToOmml, ommlToLatex, tidyLatexFromOmml } from '../src/mathast.js';
const lines = fs.readFileSync(process.argv[2], 'utf8').split('\n').filter(Boolean);
let diffH = 0, diffO = 0, bad = 0;
const norm = (s) => s.replace(/\s+/g, '').replace(/\{([A-Za-z0-9])\}/g, '$1').replace(/\\left\./g,'').replace(/\\right\./g,'');
for (const script of lines) {
  const l1 = hwpEqToLatex(script).latex;
  const h = latexToHancom(l1);
  const l2 = hwpEqToLatex(h.script).latex;
  const o = latexToOmml(l1);
  let l3 = '';
  try {
    const doc = new DOMParser().parseFromString(`<root xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">${o.omml}</root>`, 'application/xml');
    l3 = tidyLatexFromOmml(ommlToLatex(doc.documentElement.firstChild));
  } catch (e) { bad++; console.log('XML ERR', e.message, o.omml.slice(0, 200)); }
  if (norm(l1) !== norm(l2)) { diffH++; if (diffH <= 12) console.log('H:', script, '\n   L1', l1, '\n   HW', h.script, '\n   L2', l2, h.warnings.join(';')); }
  if (norm(l1) !== norm(l3)) { diffO++; if (diffO <= 12) console.log('O:', l1, '\n   L3', l3, o.warnings.join(';')); }
}
console.log('total', lines.length, 'hancom-roundtrip diffs', diffH, 'omml-roundtrip diffs', diffO, 'xml errors', bad);
