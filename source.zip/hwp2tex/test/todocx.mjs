import fs from 'node:fs';
import { DOMParser } from '@xmldom/xmldom';
import { toDocx, setDOMParser } from '../src/index.js';
setDOMParser(DOMParser);
const [,, input, output] = process.argv;
const { docx, warnings } = toDocx(new Uint8Array(fs.readFileSync(input)), { title: 'test' });
fs.writeFileSync(output, docx);
console.log('wrote', output, docx.length, 'warnings', warnings.length, warnings.slice(0, 5));
