import fs from 'node:fs';
import { parseCFB } from '../src/cfb.js';
import { inflateSync } from 'fflate';
const cfb = parseCFB(new Uint8Array(fs.readFileSync(process.argv[2])));
const d = inflateSync(cfb.read('DocInfo'));
let o=0, i=0;
while (o+4<=d.length) { const h = d[o]|(d[o+1]<<8)|(d[o+2]<<16)|(d[o+3]<<24); o+=4; const tag=h&0x3ff; let size=(h>>>20)&0xfff; if(size===0xfff){size=d[o]|(d[o+1]<<8)|(d[o+2]<<16)|(d[o+3]<<24); o+=4;}
  if (tag===0x15) { const dv=new DataView(d.buffer,d.byteOffset+o,size); console.log('charshape',i++, 'len',size,'size',dv.getUint32(42,true),'attr',dv.getUint32(46,true).toString(2).padStart(20,'0')); }
  if (tag===0x17) { console.log('numbering rec len', size); }
  o+=size; }
