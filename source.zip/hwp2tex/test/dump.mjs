import fs from 'node:fs';
import { parseHwp5 } from '../src/hwp5.js';
const doc = parseHwp5(new Uint8Array(fs.readFileSync(process.argv[2])));
console.log('blocks', doc.blocks.length, 'images', [...doc.images.entries()].map(([k,v])=>k+':'+v.ext+':'+v.data.length).join(' '));
console.log('warnings', doc.warnings);
const eqs = [];
const walk = (blocks, d=0) => { for (const b of blocks) {
  if (b.type==='p') { for (const il of b.inlines) { if (il.type==='eq') eqs.push(il.script); if (il.type==='note') walk(il.blocks, d+1); if (il.type==='table') walk(il.cells.flatMap(c=>c.blocks), d+1);} }
  else if (b.type==='table') walk(b.cells.flatMap(c=>c.blocks), d+1);
  else if (b.type==='textbox') walk(b.blocks, d+1);
}};
walk(doc.blocks);
console.log('equations', eqs.length);
fs.writeFileSync(process.argv[3], eqs.join('\n'));
fs.writeFileSync(process.argv[3]+'.json', JSON.stringify(doc.blocks, (k,v)=> v instanceof Uint8Array? '<bytes>': v, 1));
