import fs from 'node:fs';
import { DOMParser } from '@xmldom/xmldom';
import { parseDocument, setDOMParser } from '../src/index.js';
import { docToHwpx } from '../src/hwpxwrite.js';
setDOMParser(DOMParser);
const [,, input, output] = process.argv;
const doc = parseDocument(new Uint8Array(fs.readFileSync(input)));
const { hwpx, warnings } = docToHwpx(doc, { title: 'test' });
fs.writeFileSync(output, hwpx);
console.log('wrote', output, hwpx.length, 'warnings', warnings.slice(0, 5));
// parse back
const back = parseDocument(new Uint8Array(fs.readFileSync(output)));
console.log('parsed back: blocks', back.blocks.length, 'images', back.images.size, 'warnings', back.warnings.slice(0, 3));
